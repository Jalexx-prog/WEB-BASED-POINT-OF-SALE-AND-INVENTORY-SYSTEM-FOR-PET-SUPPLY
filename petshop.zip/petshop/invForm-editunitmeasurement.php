<?php
try{
session_start();
include("./includes/connection.php");
include('./includes/log_check.php');
include ('./includes/checkRole.php');
    
date_default_timezone_set('Asia/Manila');


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["edited"])) {
    $edited_unit_name = $_POST["edited"]; 
    $id = $_POST["id"];
  
    // Update category name in the database
    $Sql = "UPDATE unit_of_measurement SET unit_name = '$edited_unit_name' WHERE unit_id = $id";
    $Result = $conn->query($Sql);
  
    if (!$Result) {
        die("Unit name update failed: " . $conn->error);
    }
  }


    $_SESSION["message"] = "unit-edited";
    header("location: ./inv-unitofmeasurement.php");
    exit();

} catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    echo $e;
    header("location: ./inv-unitofmeasurement.php");
    exit();
}
?>