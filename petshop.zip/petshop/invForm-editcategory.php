<?php
try{
session_start();
include("./includes/connection.php");
include('./includes/log_check.php');
include ('./includes/checkRole.php');
    
date_default_timezone_set('Asia/Manila');


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["edited"])) {
    $editedCategoryName = $_POST["edited"]; 
    $id = $_POST["id"];
  
    // Update category name in the database
    $categorySql = "UPDATE category SET category_name = '$editedCategoryName' WHERE category_id = $id";
    $categoryResult = $conn->query($categorySql);
  
    if (!$categoryResult) {
        die("Category update failed: " . $conn->error);
    }
  }


    $_SESSION["message"] = "category-edited";
    header("location: ./inv-category.php");
    exit();

} catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    echo $e;
    header("location: ./inv-category.php");
    exit();
}
?>