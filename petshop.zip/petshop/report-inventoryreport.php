<?php
session_start();
include('includes/connection.php');
include('includes/log_check.php');
include('./includes/checkRole.php');

$logo = $conn->query("SELECT `logo` FROM `system`")->fetch_assoc()["logo"];

//product items
$stock_sql = "SELECT 
    products.product_id,
    products.product_name,
    SUM(batch.unpacked_quantity + batch.quantity) AS total_stocks,
    products.stock_status,
    products.price,
    batch.archive_status,
    (SELECT unit_name FROM unit_of_measurement WHERE products.retail_unit = unit_id) AS retail_unit
    FROM batch
        INNER JOIN products ON batch.product_id = products.product_id
    WHERE products.archive_status = 0 AND batch.archive_status = 0
    GROUP BY products.product_id
    ORDER BY products.product_name ASC
    ";
$stock_res = $conn->query($stock_sql);


//repackable_batch
$repackable_sql = "SELECT 
products.product_id,
products.product_name,
batch.unpacked_quantity,
batch.quantity,
batch.prepared_by,
products.stock_status,
products.price,
products.repackable,
user.username AS preparedby,
(SELECT unit_name FROM unit_of_measurement WHERE products.retail_unit = unit_id) AS retail_unit,
SUM(batch.quantity) AS total_batch,
batch.batch_id,
batch.expiration_status
FROM batch
INNER JOIN products ON batch.product_id = products.product_id
INNER JOIN `user` ON `batch`.`prepared_by` = `user`.`user_id`
WHERE `batch`.`archive_status` = 0 AND products.repackable = 1 AND `products`.`archive_status` = 0 AND (`batch`.`quantity`) != 0 AND `batch`.`quantity` >= 1
GROUP BY batch.batch_id
ORDER BY batch.expiration_status DESC
";
$repackable_res = $conn->query($repackable_sql);

//Unpacked_batch
$unpacked_sql = "SELECT 
products.product_id,
products.product_name,
batch.cost,
batch.unpacked_quantity,
batch.expiration_date,
products.stock_status,
products.price,
products.repackable,
(SELECT unit_name FROM unit_of_measurement WHERE products.retail_unit = unit_id) AS retail_unit,
SUM(batch.unpacked_quantity) AS total_unpacked_batch,
batch.batch_id,
batch.expiration_status
FROM batch
INNER JOIN products ON batch.product_id = products.product_id
WHERE `batch`.`archive_status` = 0 AND `products`.`repackable` = 1 AND `products`.`archive_status` = 0 AND (`batch`.`unpacked_quantity`) != 0 AND `batch`.`unpacked_quantity` >= 1
GROUP BY batch.batch_id
ORDER BY batch.expiration_status DESC
";
$unpacked_res = $conn->query($unpacked_sql);

//Top selling
$transact_sql = "SELECT
products.product_id,
products.product_name,
SUM(transaction_items.quantity) AS total_sold_qty,
transaction_items.unit
FROM transaction_items
INNER JOIN products ON transaction_items.product_id = products.product_id
INNER JOIN transactions ON transaction_items.transaction_id = transactions.transaction_id
WHERE 1
GROUP BY products.product_id
ORDER BY total_sold_qty DESC
limit 10
";
$transact_res = $conn->query($transact_sql);

//expire
$exp_sql = "SELECT
products.product_id,
products.product_name,
batch.cost,
batch.quantity,
batch.unpacked_quantity,
batch.expiration_date,
products.stock_status,
products.price,
products.repackable,
(SELECT unit_name FROM unit_of_measurement WHERE products.retail_unit = unit_id) AS retail_unit,
SUM(batch.unpacked_quantity + batch.quantity) AS total_stocks,
batch.batch_id,
batch.expiration_status
FROM
batch
INNER JOIN
products ON batch.product_id = products.product_id
WHERE
`batch`.`archive_status` = 0
AND `products`.`archive_status` = 0
AND (`batch`.`unpacked_quantity` + `batch`.`quantity`) != 0
AND (batch.expiration_status = 1 OR batch.expiration_status = 2 OR batch.expiration_status = 3)
GROUP BY
batch.batch_id
ORDER BY
batch.expiration_status DESC;
";
$exp_res = $conn->query($exp_sql);

//loss
$loss_sql = "SELECT
`batch`.`batch_id`,
`batch_loss`.`id`,
`batch_loss`.`unpacked_loss`,
`batch_loss`.`quantity_loss`,
`batch`.`cost`,
`batch_loss`.`promo`,
`products`.`product_name`,
`batch_loss`.`remarks`,
`batch_loss`.`archived_date`,
`batch_loss`.`archive_by`,
SUM( `batch_loss`.`unpacked_loss` + `batch_loss`.`quantity_loss`) AS total_batch,
(SELECT unit_name FROM unit_of_measurement WHERE products.retail_unit = unit_id) AS retail_unit,
`batch_loss`.`status`,
`user`.`username` AS `archived_by`
FROM `batch_loss`
INNER JOIN `user` ON `batch_loss`.`archive_by` = `user`.`user_id`
INNER JOIN `products` ON `batch_loss`.`product_id` = `products`.`product_id`
INNER JOIN `batch` ON `batch_loss`.`batch_id` = `batch`.`batch_id`
WHERE `batch_loss`.`status` = 1
GROUP BY `batch_loss`.`id`
ORDER BY `products`.`product_name` ASC
";
$loss_res = $conn->query($loss_sql);



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--Bootstrap-->
    <link rel="stylesheet" href="./bootstrap/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <script src="./bootstrap/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

    <!--Jquery-->
    <script src="./js/jquery_3.6.4_jquery.min.js"></script>

    <script src="./bootstrap//popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip();
        })
    </script>

    <!--Fontawesome-->
    <link rel="stylesheet" href="./fontawesome/css/all.min.css">

    <!--CSS-->
    <link rel="stylesheet" href="./css/styles.css">
    <link rel="stylesheet" href="./css/inventory_report.css">

    <link rel="icon" type="image/png" href="./assets/<?php echo $logo ?>" />
    <title>Inventory Report</title>
    <style>
        body {
            font-family: Arial;
        }

        /* Style the tab */
        .tab {
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
        }

        /* Style the buttons inside the tab */
        .tab button {
            background-color: inherit;
            float: left;
            border: none;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            font-size: 17px;
        }

        /* Change background color of buttons on hover */
        .tab button:hover {
            background-color: #ddd;
        }

        /* Create an active/current tablink class */
        .tab button.active {
            background-color: #ccc;
        }

        /* Style the tab content */
        .tabcontent {
            display: none;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }
    </style>
</head>

<body>
    <?php

    include("./includes/navbar.php");
    ?>

    <div class="container main-div py-4" id="main-div">
        <h3>Inventory Report</h3>
        <div class="col d-flex justify-content-end">
            <a href="./print-inventoryreport.php" class="btn btn-primary mb-2"><i class="fa-solid fa-print"></i> Print</a>
        </div>

        <div class="tab">
            <button class="tablinks active" onclick="openCity(event, 'product')">Product Items</button>
            <button class="tablinks" onclick="openCity(event, 'repacked')">Repacked</button>
            <button class="tablinks" onclick="openCity(event, 'unpacked')">Unpacked</button>
            <button class="tablinks" onclick="openCity(event, 'top')">Top Selling</button>
            <button class="tablinks" onclick="openCity(event, 'expire')">Expire Batches</button>
            <button class="tablinks" onclick="openCity(event, 'loss')">Batch Loss</button>
        </div>

        <!--1st tabs-->
        <div id="product" class="tabcontent" style="display: block;">
            <h5 class="mt-3 mb-4">Product Items</h5>
            <div class="container col">
                <div class="div_products row" style="height: 550px; overflow-y:scroll;">
                    <table class="table productTable" id="productTable">
                        <thead>
                            <th>#</th>
                            <th style="width: 30%;">PRODUCT NAME</th>
                            <th>STOCKS</th>
                            <th>(₱) UNIT PRICE</th>
                            <th>STOCK STATUS</th>
                        </thead>
                        <tbody>
                            <?php
                            $rowCount = 1;
                            while ($row = $stock_res->fetch_assoc()) {
                                $TOTAL = $row["price"] * $row["total_stocks"];
                                $stockStatus = $row["stock_status"];

                                if ($stockStatus == 1) {
                                    $statusBadge = '<a href="#" class="badge badge-light">In Stock</a>';
                                } elseif ($stockStatus == 2) {
                                    $statusBadge = '<a href="#" class="badge badge-danger">Critical</a>';
                                } elseif ($stockStatus == 3) {
                                    $statusBadge = '<a href="#" class="badge badge-dark">Out of Stock</a>';
                                }

                                echo "
                                    <tr>
                                        <td class='text-center'>$rowCount</td>
                                        <td>$row[product_name]</td>
                                        <td class='text-center'>$row[total_stocks] $row[retail_unit]</td>
                                        <td class='text-center'>" . number_format($row["price"], 2) . "</td>
                                        <td class='text-center'> $statusBadge</td>
                                    </tr>
                                    ";
                                $rowCount++;
                            }
                            ?>
                        </tbody>
                    </table>
                    <?php
                    if ($stock_res->num_rows > 0) {
                    } else {
                        echo '
                <div class="container-fluid">
                <p class="text-center">No Result</p>
                  </div>';
                    }
                    ?>
                </div>
            </div>
        </div>

        <!--2nd tabs-->
        <div id="repacked" class="tabcontent">
            <h5 class="mt-3 mb-4">Repacked Batches</h5>
            <div class="div_stocks row" style="height: 400px; overflow-y: auto;">
                <table class="table productTable" id="productTable">
                    <thead>
                        <th>#</th>
                        <th>BATCH ID</th>
                        <th>PRODUCT NAME</th>
                        <th>STOCKS</th>
                        <th>(₱) UNIT PRICE</th>
                        <th>EXPIRY STATUS</th>
                        <th>PREPARED BY</th>
                    </thead>
                    <tbody>
                        <?php

                        $rowCounts = 1;
                        while ($rows = $repackable_res->fetch_assoc()) {
                            $expStatus = $rows["expiration_status"];
                            $stock_value = $rows["price"] * $rows["total_batch"];


                            if ($expStatus == 1) {
                                $expbadge = '<a href="#" class="badge badge-light">Good</a>';
                            } elseif ($expStatus == 2) {
                                $expbadge = '<a href="#" class="badge badge-warning">Nearly Expire</a>';
                            } elseif ($expStatus == 3) {
                                $expbadge = '<a href="#" class="badge badge-danger">Expire</a>';
                            }

                            echo "
          <tr>
          <td class='text-center'>$rowCounts</td>
          <td class='text-center'>$rows[batch_id]</td>
          <td>$rows[product_name]</td>
          <td class='text-center'>$rows[quantity] $rows[retail_unit]</td>
          <td class='text-center'>" . number_format($rows["price"], 2) . "</td>
          <td class='text-center'>$expbadge</td>
          <td class='text-center'>$rows[preparedby]</td>
      
          </tr>
          ";
                            $rowCounts++;
                        }
                        ?>
                    </tbody>
                </table>
                <?php
                if ($repackable_res->num_rows > 0) {
                } else {
                    echo '
                <div class="container-fluid">
                <p class="text-center">No Result</p>
                  </div>';
                }
                ?>
            </div>
        </div>

        <!--3rd tabs-->
        <div id="unpacked" class="tabcontent">
            <h5 class="mt-3 mb-4">Unpacked Batches</h5>
            <div class="div_stocks row" style="height: 400px; overflow-y: auto;">
                <table class="table productTable" id="productTable">
                    <thead>
                        <th>#</th>
                        <th>BATCH ID</th>
                        <th>PRODUCT NAME</th>
                        <th>STOCKS</th>
                        <th>EXPIRE DATE</th>
                        <th>EXPIRY STATUS</th>
                    </thead>
                    <tbody>
                        <?php
                        $unpacked_counts = 1;
                        while ($unpacked_rows = $unpacked_res->fetch_assoc()) {
                            $EXPstatus = $unpacked_rows["expiration_status"];
                            $date = date_create($unpacked_rows["expiration_date"]);
                            $date_format = date_format($date, "F d, Y");



                            if ($EXPstatus == 1) {
                                $EXPbadge = '<a href="#" class="badge badge-light">Good</a>';
                            } elseif ($EXPstatus == 2) {
                                $EXPbadge = '<a href="#" class="badge badge-warning">Nearly Expire</a>';
                            } elseif ($EXPstatus == 3) {
                                $EXPbadge = '<a href="#" class="badge badge-danger">Expire</a>';
                            }

                            echo "
                            <tr>
                            <td class='text-center'>$unpacked_counts</td>
                            <td class='text-center'>$unpacked_rows[batch_id]</td>
                            <td>$unpacked_rows[product_name]</td>
                            <td class='text-center'>$unpacked_rows[total_unpacked_batch] $unpacked_rows[retail_unit]</td>
                            <td class='text-center'>$date_format</td>
                            <td class='text-center'>$EXPbadge</td>
                            
                            </tr>
                            
                            ";
                            $unpacked_counts++;
                        }
                        ?>
                    </tbody>
                </table>
                <?php
                if ($unpacked_res->num_rows > 0) {
                } else {
                    echo '
                <div class="container-fluid">
                <p class="text-center">No Result</p>
                  </div>';
                }
                ?>
            </div>
        </div>

        <!--4th tabs-->
        <div id="top" class="tabcontent">
            <h5 class="mt-3 mb-4">Top Selling Product</h5>
            <div class="div_stocks row" style="height: 400px; overflow-y: auto;">
                <table class="table productTable" id="productTable">
                    <thead>
                        <th>#</th>
                        <th>PRODUCT NAME</th>
                        <TH>SOLD QUANTITY</TH>
                    </thead>
                    <tbody>
                        <?php

                        $rowcount = 1;
                        while ($rowss = $transact_res->fetch_assoc()) {


                            echo "
                    <tr>
                    <td class='text-center'>$rowcount</td>
                    <td>$rowss[product_name]</td>
                    <td class='text-center'>$rowss[total_sold_qty]</td>
                    
                    </tr>
                    
                    ";

                            $rowcount++;
                        }
                        ?>
                    </tbody>
                </table>
                <?php
                if ($transact_res->num_rows > 0) {
                } else {
                    echo '
                <div class="container-fluid">
                <p class="text-center">No Result</p>
                  </div>';
                }
                ?>
            </div>
        </div>

        <!--5th tabs-->
        <div id="expire" class="tabcontent">
            <h5 class="mt-3 mb-4">Expire Batches</h5>
            <div class="div_stocks row" style="height: 400px; overflow-y: auto;">
                <table class="table productTable" id="productTable">
                    <thead>
                        <th>#</th>
                        <th>BATCH ID</th>
                        <th>PRODUCT NAME</th>
                        <th>STOCKS</th>
                        <th>EXPIRE DATE</th>
                        <th>EXPIRY STATUS</th>
                    </thead>
                    <tbody>
                        <?php
                        $exp_count = 1;

                        while ($exp_row = $exp_res->fetch_assoc()) {
                            $expstatus = $exp_row["expiration_status"];
                            $dates = date_create($exp_row["expiration_date"]);
                            $dates_format = date_format($dates, "F d, Y");

                            if ($expstatus == 1) {
                                $expbadge = '<a href="#" class="badge badge-light">Good</a>';
                            } elseif ($expstatus == 2) {
                                $expbadge = '<a href="#" class="badge badge-warning">Nearly Expire</a>';
                            } elseif ($expstatus == 3) {
                                $expbadge = '<a href="#" class="badge badge-danger">Expire</a>';
                            }

                            echo "
                    <tr>
                        <td class='text-center'>$exp_count</td>
                        <td class='text-center'>$exp_row[batch_id]</td>
                        <td>$exp_row[product_name]</td>
                        <td class='text-center'>$exp_row[total_stocks] $exp_row[retail_unit]</td>
                        <td class='text-center'>$dates_format</td>
                        <td class='text-center'>$expbadge</td>
                    </tr>
                    ";
                            $exp_count++;
                        }
                        ?>
                    </tbody>
                </table>
                <?php
                if ($exp_res->num_rows > 0) {
                } else {
                    echo '
                <div class="container-fluid">
                <p class="text-center">No Result</p>
                  </div>';
                }
                ?>
            </div>
        </div>

            <!--6th tabs-->
            <div id="loss" class="tabcontent">
            <h5 class="mt-3 mb-4">Expire Batches</h5>
            <div class="div_stocks row" style="height: 400px; overflow-y: auto;">
                <table class="table productTable" id="productTable">
                    <thead>
                        <th>#</th>
                        <th>BATCH ID</th>
                        <th>PRODUCT NAME</th>
                        <th>STOCKS</th>
                        <th>(₱) UNIT COST</th>
                        <th>(₱) TOTAL LOSS</th>
                        <th>ARCHIVE DATE</th>
                        <th>ARCHIVE BY</th>
                        <th>ARCHIVE REMARKS</th>
                    </thead>
                    <tbody>
                        <?php
                        $countss = 1;
                        while ($loss_row = $loss_res->fetch_assoc()) {
                            $total_loss = $loss_row["total_batch"] * $loss_row["cost"];
                            $dt = date_create($loss_row["archived_date"]);
                            $new_date = date_format($dt, "F d, Y");

                               echo "
                    <tr>
                        <td class='text-center'>$countss</td>
                        <td class='text-center'>$loss_row[batch_id]</td>
                        <td>$loss_row[product_name]</td>
                        <td class='text-center'>$loss_row[total_batch] $loss_row[retail_unit]</td>
                        <td class='text-center'>" . number_format($loss_row["cost"], 2) . "</td>
                        <td class='text-center'>" . number_format($total_loss, 2) . "</td>
                        <td class='text-center'>$new_date</td>
                        <td class='text-center'>$loss_row[archived_by]</td>
                        <td class='text-center'>$loss_row[remarks]</td>
                    </tr>
                    
                    ";
                            $countss++;
                        }




                        ?>
                    </tbody>
                </table>
                <?php
                if ($loss_res->num_rows > 0) {
                } else {
                    echo '
                <div class="container-fluid">
                <p class="text-center">No Result</p>
                  </div>';
                }
                ?>
            </div>
        </div>


        <script>
            function openCity(evt, cityName) {
                var i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("tabcontent");
                for (i = 0; i < tabcontent.length; i++) {
                    tabcontent[i].style.display = "none";
                }
                tablinks = document.getElementsByClassName("tablinks");
                for (i = 0; i < tablinks.length; i++) {
                    tablinks[i].className = tablinks[i].className.replace(" active", "");
                }
                document.getElementById(cityName).style.display = "block";
                evt.currentTarget.className += " active";
            }
        </script>

        <script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
</body>

</html>