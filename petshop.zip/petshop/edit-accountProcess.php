<?php
session_start(); 

include('includes/connection.php');
include('./includes/log_check.php');
include ('./includes/checkRole.php');


$_SESSION["first_name"];
$_SESSION["last_name"];
$_SESSION["role"];
$_SESSION["username"];
$id = $_SESSION["user_id"];



if ($_SERVER['REQUEST_METHOD'] == 'POST') {
      $f_name = $_POST["f_name"];
      $l_name = $_POST["l_name"];
      $user = $_POST["user"];
      $target_file = isset($_POST["pp"]) ? $_POST["pp"] : "";
      
  
    // Check if a file was uploaded
    if (!empty($_FILES["pp"]["name"])) {
      $target_dir = "uploads/";
      $pp_image = basename($_FILES["pp"]["name"]);
      $target_file = $target_dir . $pp_image;
      
      // Check if the file is an image
      $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
      $allowedExtensions = array("jpg", "jpeg", "png", "gif");
  
      if (in_array($imageFileType, $allowedExtensions)) {
        if (is_uploaded_file($_FILES["pp"]["tmp_name"]) && move_uploaded_file($_FILES["pp"]["tmp_name"], __DIR__ . '/' . $target_file)) {

            $query = "UPDATE user SET profile_picture = '$pp_image' WHERE user_id = $id";
            $result = $conn->query($query);
  
            $_SESSION["profile_pic"] = $pp_image;
        } else {
            echo "<script>document.getElementById('failedUploadAlert').style.display = 'block';</script>";
            }
        } else {
            echo "error";
        }
      }
    //}
      // Update user information
      $passQuery = "";
      if(!empty($_POST["confirm_password"])){
        $old_pass = $_POST["old_password"];
        $new_password = $_POST["new_password"];
        $confirm_password = $_POST["confirm_password"];
  
        $get_password_query = "SELECT password FROM user WHERE user_id = $id";
        $get_password_result = $conn->query($get_password_query);
        $row = $get_password_result->fetch_assoc();
        $stored_password = $row["password"];
  
        // Check if the old password matches the one in the database
        if (password_verify($old_pass, $stored_password)) {
            // Hash the new password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
  
            // Update the password in the database
            $passQuery = ", password = '$hashed_password'";
        }
      }
  
  
      $query = "UPDATE user SET  username = '$user', first_name = '$f_name', last_name = '$l_name' $passQuery WHERE user_id = $id";
      $result = $conn->query($query);
  
         // Update the session variables with the new name values
         $_SESSION["first_name"] = $f_name;
         $_SESSION["last_name"] = $l_name;
         $_SESSION["username"] = $user;

         $_SESSION["message"] = "personal-detail";
         header("location: ./edit-account.php");
         exit();

         
  }


   if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST["new_password"]) && !empty($_POST["confirm_password"])) {
      $old_pass = $_POST["old_password"];
      $new_password = $_POST["new_password"];
      $confirm_password = $_POST["confirm_password"];
  
      $get_password_query = "SELECT password FROM user WHERE user_id = $id";
      $get_password_result = $conn->query($get_password_query);
      $row = $get_password_result->fetch_assoc();
      $stored_password = $row["password"];
  
      // Check if the old password matches the one in the database
      if (password_verify($old_pass, $stored_password)) {
          // Hash the new password
          $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
  
          // Update the password in the database
          $update_password_query = "UPDATE user SET password = '$hashed_password' WHERE user_id = $id";
          $update_password_result = $conn->query($update_password_query);


          $_SESSION["message"] = "password-change";
          header("location: ./edit-account.php");
          exit();
      }
  }
?>