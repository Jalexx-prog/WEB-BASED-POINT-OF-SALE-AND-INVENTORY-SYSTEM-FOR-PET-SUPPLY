<?php
try{
    session_start();
    include("./includes/connection.php");
    include('./includes/log_check.php');
    include ('./includes/checkRole.php');
    
    date_default_timezone_set('Asia/Manila');
    $user = $_SESSION["user_id"];
    $date = date("Y-m-d H-i-s");


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $promo_name = $_POST["newpromoname"];   
    $promo_qty = $_POST["stocks"];
    $promo_exp = $_POST["expirationDate"];

        // Calculate expiration status
        $exp_status = ''; // initialize exp_status

        $exp_diff = strtotime($promo_exp) - strtotime(date("Y-m-d")); // calculate difference in seconds
        $exp_days = $exp_diff / (60 * 60 * 24); // convert difference to days

        if ($exp_days > 30) {
            $exp_status = 1;
        } elseif ($exp_days <= 30 && $exp_days > 0) {
            $exp_status = 2;
        } elseif ($exp_days <= 0) {
            $exp_status = 3;
        }

    $promoSql = "INSERT INTO `promo_products`(`batch_id`,`product_id`,`remarks`,`quantity_promo`,`nameP`,`exp`,`exp_stats`)
                                VALUES ('','','','$promo_qty','$promo_name','$promo_exp ','$exp_status')";
    $promoResult = $conn->query($promoSql);

    if (!$promoResult) {
        die("Discount insertion failed: " . $conn->error);
    }

    $promoID= $conn->insert_id;

    
    $_SESSION["message"] = "promo-added";
    header("location: ./promo_page.php");
    exit();


}  else{   //runs if there are no POST method
        $_SESSION["message"] = "error";
  
        exit();

}

}
catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";

    exit();
}
?>