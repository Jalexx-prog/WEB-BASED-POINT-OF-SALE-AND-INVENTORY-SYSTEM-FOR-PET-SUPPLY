<?php
session_start();
include('includes/connection.php');
include('includes/log_check.php');
include('./includes/checkRole.php');

$logo = $conn->query("SELECT `logo` FROM `system`")->fetch_assoc()["logo"];



$search = isset($_GET["search"]) ? $_GET["search"] : '';
$condition = "1";

if (isset($_GET["search"]) and $_GET["search"] !== "") {
    $condition .= " AND (`first_name` = '$search' OR `last_name` = '$search' OR `username` LIKE '%$search%')";
}
$sql = "SELECT * FROM user WHERE $condition";
$result = $conn->query($sql);



if (!$result) {
    die("Invalid query: " . $conn->connect_error);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--Bootstrap-->
    <link rel="stylesheet" href="./bootstrap/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <script src="./bootstrap/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

    <!--Jquery-->
    <script src="./js/jquery_3.6.4_jquery.min.js"></script>
    <script src="./bootstrap//popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>

    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip();
        })
    </script>

    <!--Fontawesome-->
    <link rel="stylesheet" href="./fontawesome/css/all.min.css">

    <!--CSS-->
    <link rel="stylesheet" href="./css/styles.css">
    <link rel="stylesheet" href="./css/inventory.css">

    <link rel="icon" type="image/png" href="./assets/<?php echo $logo ?>" />
    <title>Manage Account</title>
</head>

<body>
    <?php
    $module = "manage-account";
    include("./includes/navbar.php");

    ?>

    <div class="container main-div py-4" id="main-div">
        <h3 class="col ms-5">Manage Users (<?= $result->num_rows ?>)</h3>

        <section class="productTableSection mt-5" id="productTableSection">
            <div class="row mb-3 d-flex flex-row-reverse">
                <!--buttons-->
                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#myModal"><i class="fa-solid fa-plus"></i>&emsp;Add User</button>
                <?= (isset($_GET["search"]) or (isset($_GET["orderColumn"]) and isset($_GET["orderDirection"]))) ? '
                    &emsp;
                    <a href="./manage-account.php" class="btn btn-outline-secondary"><i class="fa-solid fa-rotate-left"></i></a>
                ' :
                    '' ?>
            </div>
            <table class="table productTable" id="productTable">

                <thead>
                    <th>#</th>
                    <th>PROFILE</th>
                    <th>USERNAME</th>
                    <th>ROLE</th>
                    <th>ACTION</th>
                </thead>
                <tbody>
                    <?php

                    $rowCount = 1;

                    while ($row = $result->fetch_assoc()) {
                        echo "
                        <tr>
                            <td>$rowCount</td>
                            <td><img src='uploads/$row[profile_picture]' id='pp' class='img-fluid rounded-circle'>&nbsp;&nbsp; $row[first_name] $row[last_name]</td>
                            <td>$row[username]</td>
                            <td>" . ($row['role'] == 1 ? '<span class="badge badge-primary">Admin</span>' : '<span class="badge badge-warning">Staff</span>') . " </td>
                            <td>
                                <button class='btn btn-warning btn-sm change_role'
                                data-current-role='" . $row["role"] . "'
                                data-user-id='" . $row["user_id"] . "'
                                 data-toggle='modal'
                                 data-target='#changerole'> 
                                 <i class='fas fa-exchange-alt'></i></button>


                                <button class='btn btn-danger btn-sm deleteAcct'
                                data-delete-account='" . $row["user_id"] . "'
                                data-toggle='modal'
                                data-target='#deleteaccount'>
                                 <i class='fa-solid fa-trash'></i></button>    
                            </td>
                        <tr>
                            ";
                        $rowCount++;
                    }

                    ?>
                </tbody>
            </table>
        </section>

    </div>


    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add New User</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="newaccount.php" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col">
                                <label for="addProduct-quantity">First Name <span style="color: red;">*</span></label>
                                <input type="text" class="form-control" id="f_name" name="f_name" required>
                            </div>
                            <div class="col">
                                <label for="addProduct-quantity">Last Name <span style="color: red;">*</span></label>
                                <input type="text" class="form-control" id="l_name" name="l_name" required>
                            </div>
                            <div class="col">
                                <label for="addProduct-quantity">Profile Picture</label>
                                <input type="file" class="form-control" id="profile_picture" name="profile_picture">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="addProduct-quantity">Username <span style="color: red;">*</span></label>
                                <input type="text" class="form-control" id="username" name="username" required>
                            </div>
                            <div class="col">
                                <input type="hidden" name="status" id="status" value="1">
                                <label for="addProduct-quantity">Role <span style="color: red;">*</span></label>
                                <select class="form-control" name="role" id="role" required>
                                    <option value="3" selected disabled>Select Role for New Account</option>
                                    <option value="1">Admin</option>
                                    <option value="0">Staff</option>
                                </select>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col">
                                <label for="addProduct-quantity">New Password <span style="color: red;">*</span></label>
                                <input type="password" class="form-control" id="new_pass" name="new_pass" required>
                            </div>
                            <div class="col">
                                <label for="addProduct-quantity">Security Question 1</label>
                                <select class="form-control" name="security_question1" id="security_question1" required>
                                    <option value="0" selected disabled>-Select One-</option>

                                    <!--sql of questions-->
                                    <?php
                                    $question_sql = "SELECT `id`, `questions` FROM `security_question` WHERE 1 LIMIT 5";
                                    $question_result = $conn->query($question_sql);

                                    while ($rows = $question_result->fetch_assoc()) {
                                        echo '
                                <option value="' . $rows["id"] . '">' . $rows["questions"] . '</option>
                                ';
                                    }
                                    ?>

                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="addProduct-quantity">Confirm Password <span style="color: red;">*</span></label>
                                <input type="password" class="form-control" id="Confirm_pass" name="Confirm_pass" required>
                            </div>
                            <div class="col">
                                <label for="addProduct-quantity">Answer Question 1</label>
                                <input type="text" class="form-control" id="Answer1" name="Answer1" autocomplete="off">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">

                            </div>
                            <div class="col">
                                <label for="addProduct-quantity">Security Question 2 </label>
                                <select class="form-control" name="security_question2" id="security_question2" required>
                                    <option value="0" selected disabled>-Select One-</option>

                                    <!--sql of questions-->
                                    <?php
                                    $question2_sql = "SELECT `id`, `questions` FROM `security_question` WHERE `id` >= 6 LIMIT 5";
                                    $question2_result = $conn->query($question2_sql);

                                    while ($rowss = $question2_result->fetch_assoc()) {
                                        echo '
                                <option value="' . $rowss["id"] . '">' . $rowss["questions"] . '</option>
                                ';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">

                            </div>
                            <div class="col">
                                <label for="addProduct-quantity">Answer Question 2</label>
                                <input type="text" class="form-control" id="Answer2" name="Answer2" autocomplete="off">
                            </div>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal change role-->
    <div class="modal fade" id="changerole" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Change Role</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="manage-change_role.php" method="post">
                        <center>
                            <b>Are you sure you want to change the role ?</b>
                            <input type="hidden" name="change_role" id="change_role">
                            <input type="hidden" name="id" id="role_id">
                        </center>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Change</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Delete-->
    <div class="modal fade" id="deleteaccount" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Remove Account</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="manage-delete_account.php" method="post">
                        <center>
                            <b>Are you sure you want to delete this account ?</b>
                            <input type="hidden" name="id" id="delete_acct">
                        </center>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>





    <script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
    <script src="./js/preventKeydown.js"></script>
    <script>
        $(document).ready(function() {
            $(".change_role").tooltip({
                title: "Change Role",
                trigger: "hover",
                placement: "top"
            });
            $(".deleteAcct").tooltip({
                title: "Delete",
                trigger: "hover",
                placement: "top"
            });

            $(".change_role").click(function() {
                // Handle modal functionality
                var roleID = $(this).data("user-id");
                var currentRole = $(this).data("current-role");
                $("#role_id").val(roleID);
                $("#change_role").val(currentRole);
            });

            $(".deleteAcct").click(function() {
                // Handle modal functionality
                var delete_Account = $(this).data("delete-account");
                $("#delete_acct").val(delete_Account);
            });
        });
    </script>
</body>

</html>