<?php
session_start();

include("./includes/connection.php");

date_default_timezone_set('Asia/Manila');

$sql = "SELECT
`batch`.`batch_id`,
`batch`.`expiration_status`,
`batch`.`expiration_date`,
`promo_product`.`prd_promo_id`,
`promo_product`.`quantity_promo`,
`promo_product`.`remarks`,
`products`.`product_name`,
`promo_product`.`archive_status`,
`promo_product`.`archive_date`,
SUM(`promo_product`.`quantity_promo`) AS total_batch,
(SELECT unit_name FROM unit_of_measurement WHERE products.retail_unit = unit_id) AS retail_unit,
`user`.`username` AS `archived_by`
FROM `promo_product`
INNER JOIN `user` ON `promo_product`.`archive_by` = `user`.`user_id`
INNER JOIN `products` ON `promo_product`.`product_id` = `products`.`product_id`
INNER JOIN `batch` ON `promo_product`.`batch_id` = `batch`.`batch_id`
WHERE `promo_product`.`archive_status` = 0
GROUP BY `promo_product`.`prd_promo_id`
ORDER BY `products`.`product_name` ASC
";
$result = $conn->query($sql);

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!--Bootstrap-->
  <link rel="stylesheet" href="./bootstrap/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
  <script src="./bootstrap/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

  <!--Jquery-->
  <script src="./js/jquery_3.6.4_jquery.min.js"></script>

  <script src="./bootstrap//popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
  <script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>

  <script>
    $(function() {
      $('[data-toggle="tooltip"]').tooltip();
    })
  </script>

  <!--Fontawesome-->
  <link rel="stylesheet" href="./fontawesome/css/all.min.css">

  <!--CSS-->
  <link rel="stylesheet" href="./css/styles.css">
  <link rel="stylesheet" href="./css/inventory.css">

  <link rel="icon" type="image/png" href="./assets/logo.png" />
  <title>Promotional</title>
</head>

<body>
  <?php

  include("./includes/navbar.php");
  ?>

  <div class="container main-div py-4" id="main-div">
    <h3>Promo Setting</h3>
    <section class="productTableSection mt-5" id="productTableSection">
      <div class="row mb-3 d-flex flex-row-reverse">
        <!--<button type="button" class="btn btn-success" data-toggle="modal" data-target="#addItemsModal"><i class="fa-solid fa-plus"></i>&emsp;Add Items</button>-->
        <?= (isset($_GET["search"]) or (isset($_GET["orderColumn"]) and isset($_GET["orderDirection"]))) ? '
                    &emsp;
                    <a href="./inv-category.php" class="btn btn-outline-secondary"><i class="fa-solid fa-rotate-left"></i></a>
                ' :
          '' ?>
      </div>
      <div class="row productTableRow mt-5">
        <table class="table productTable" id="productTable">
          <thead>
            <th class='text-center'>#</th>
            <th class='text-center'>BATCH ID</th>
            <th class='text-center'>PRODUCT NAME</th>
            <th class='text-center'>STOCKS</th>
            <th class='text-center'>EXPIRE DATE</th>
            <th class='text-center'>REMARKS</th>
            <th class='text-center'>ACTION</th>
          </thead>
          <tbody>
            <?php

            $count = 1;
            while ($row = $result->fetch_assoc()) {

              $expirationStatus = $row["expiration_status"];
              $expirationDate = $row["expiration_date"];

              $statusBadge = "";
              if ($expirationStatus == 0) {
                $statusBadge = '<a href="#" class="badge badge-light">N/A</a>';
              } elseif ($expirationStatus == 1) {
                $statusBadge = '<a href="#" class="badge badge-success" data-toggle="tooltip" title="Good">' . $expirationDate . '</a>';
              } elseif ($expirationStatus == 2) {
                $statusBadge = '<a href="#" class="badge badge-warning" data-toggle="tooltip" title="Neary Expired">' . $expirationDate . '</a>';
              } elseif ($expirationStatus == 3) {
                $statusBadge = '<a href="#" class="badge badge-danger" data-toggle="tooltip" title="Expired">' . $expirationDate . '</a>';
              }

              //$remarks = $row["remarks"] == "" ? '<a href="#" class="badge badge-light" data-toggle="tooltip" title="Not Applicable">N/A</a>' : $row["remarks"];

              if ($row["remarks"] == "") {
                $badge = '<a href="#" class="badge badge-light" data-toggle="tooltip" title="Not Applicable">N/A</a>';
              } else {
                $badge = $row["remarks"];
              }

              echo "
            <tr>
            <td class='text-center'>$count</td>
            <td class='text-center'>$row[batch_id]</td>
            <td>$row[product_name]</td>
            <td class='text-center'>$row[total_batch] $row[retail_unit]</td>
            <td class='text-center'>$statusBadge</td>
            <td class='text-center'>$badge</td>
            <td class='text-center'>

              
              <button type='button' class='btn btn-warning btn-sm archive'
              data-promo-id='" . $row["prd_promo_id"] . "'
              data-archive-status='".$row["archive_status"]."'
              data-toggle='modal'
              data-target='#changestatus'>
              <i class='fa-solid fa-box-archive'></i>
              </button>

              <button type='button' class='btn btn-danger btn-sm DeletePromo'
              data-promo-delete-id='" . $row["prd_promo_id"] . "'
              data-toggle='modal'
              data-target='#deleteModal'
              >
              <i class='fa-solid fa-trash'></i></a>
              </button>


            
             </td>
            </tr>
            
            ";
              $count++;
            }
            ?>
          </tbody>
        </table>
        <?php
        if ($result->num_rows > 0) {
        } else {
          echo '
                <div class="container-fluid">
                <p class="text-center mt-5">No Result</p>
                  </div>';
        }
        ?>
    </section>

  </div>


  <!-- Modal here-->
  <!-- Change Status Modal-->
  <div class="modal fade" id="changestatus" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Change Status</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="promo_changestatus.php" method="post">
            <center>
              <b>Are you sure you want to Archive this Promo Product ?</b>
              <input type="hidden" name="archive_status" id="archive_status">
              <input type="hidden" name="id" id="id">
            </center>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save changes</button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!--delete-->
  <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Delete Promo</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="prd_promo_delete.php" method="post">
            <center>
              <b>Are you sure you want to delete this Promo Product ?</b>
              <input type="hidden" name="del_id" id="del_id">
            </center>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-danger">Delete</button>
          </form>
        </div>
      </div>
    </div>
  </div>


  <!-- Add Item Modal -->
  <div class="modal fade" id="addItemsModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Add Promotional Item</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="add_Item-promo.php" method="post">

            <label class="form-label">Product Name</label>
            <input type="text" class="form-control" name="newpromoname" required>
            <label class="form-label">Stocks</label>
            <input type="number" min=0 class="form-control" name="stocks" required>
            <br>

            <div class="form-group">
              <label for="addBatch-quantity">Expiration Date</label>
              <input type="date" class="form-control" id="addBatch-expirationDate" name="expirationDate" required>
              <input type="checkbox" id="addBatch-noExpiration" name="noExpiration" value="1">
              <label for="noExpiration">Check if not applicable</label>
            </div>

        

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save changes</button>
          </form>
        </div>
      </div>
    </div>
  </div>


  <script>
    $(document).ready(function() {
      $(".archive").tooltip({
        title: "Archive",
        trigger: "hover",
        placement: "top"
      });
      $(".DeletePromo").tooltip({
        title: "Delete",
        trigger: "hover",
        placement: "top"
      });
    })

    $(".archive").click(function() {
      // Handle modal functionality
      var promoID = $(this).data("promo-id");
      var archiveStatus = $(this).data("archive-status");
      $("#id").val(promoID);
      $("#archive_status").val(archiveStatus);
    });

    $(".DeletePromo").click(function() {
      // Handle modal functionality
      var promo_Del_ID = $(this).data("promo-delete-id");
      $("#del_id").val(promo_Del_ID);
    });
  </script>

</body>

</html>