<?php
session_start();

include('./includes/connection.php');
include('./includes/log_check.php');


$logo = $conn->query("SELECT `logo` FROM `system`")->fetch_assoc()["logo"];


date_default_timezone_set('Asia/Manila');

$last7days = isset($_GET["last7days"]) ? $_GET["last7days"] : "current";

$totalArray = "";
$dateArray  = "";

if ($last7days == "current") {
  for ($x = 7; $x >= 1; $x--) {
    $dateLabels = date("Y-m-d", strtotime("-" . ($x - 1) . " days"));
    $sql = "SELECT SUM(`total`) AS `total`, transactions.date_created
    FROM transaction_items
    INNER JOIN transactions ON transaction_items.transaction_id = transactions.transaction_id
    WHERE YEAR(transactions.`date_created`) = YEAR('$dateLabels') AND MONTH(transactions.`date_created`) = MONTH('$dateLabels') AND DAY(transactions.`date_created`) = DAY('$dateLabels')";
    $result = $conn->query($sql);

    if (!$result) {
      die("Invalid query: " . $conn->connect_error);
    }

    $date = date("M d Y", strtotime($dateLabels));
    $total = 0;
    while ($row = $result->fetch_assoc()) {
      $total += $row["total"];
    }

    $totalArray .= $total;
    $dateArray .= "'" . $date . "'";

    if ($x >= 1) {
      $totalArray .= ", ";
      $dateArray .= ", ";
    }
  }

  $totalArray = "[$totalArray]";
  $dateArray = "[$dateArray]";
}


$basis = isset($_GET["basis"]) ? $_GET["basis"] : "TopSelling";

$table = "";
if ($basis == "TopSelling") {
  $sql = "SELECT
  products.product_id,
  products.product_name,
  SUM(transaction_items.quantity) AS total_sold_qty,
  transaction_items.unit
  FROM transaction_items
  INNER JOIN products ON transaction_items.product_id = products.product_id
  INNER JOIN transactions ON transaction_items.transaction_id = transactions.transaction_id
  WHERE 1
  GROUP BY products.product_id
  ORDER BY total_sold_qty DESC
  limit 5
  ";
  $result = $conn->query($sql);

  $tr = "";
  while ($row = $result->fetch_assoc()) {
    $tr .= "
      <tr>
        <td>$row[product_name]</td>
        <td>$row[total_sold_qty]</td>
      </tr>
    ";
  }
  $table = '
    <table class="table productTable" id="productTable1"">
      <thead id="List">
        <th style="text-align: center;">PRODUCT NAME</th>
        <th style="text-align: center;">SOLD QUANTITY</th>
      </thead>
      <tbody style="text-align: center;">
        ' . $tr . '
      </tbody>
    </table>
  ';
} elseif ($basis == "FastMoving") {
  $sql = " SELECT `Product_Name`, SUM(`quantity`) AS `productSold`,  (SUM(`Quantity`) / 30) AS `averageDay` 
   FROM `transaction_items`
    INNER JOIN products ON transaction_items.product_id = products.product_id
    INNER JOIN transactions ON transaction_items.transaction_id = transactions.transaction_id
    WHERE transactions.`date_created` BETWEEN CURDATE() - INTERVAL 30 DAY AND CURDATE() 
    GROUP BY `Product_Name`  
    ORDER BY `averageDay` DESC
    LIMIT 5;
  ";
  $result = $conn->query($sql);

  $tr = "";
  while ($row = $result->fetch_assoc()) {
    $tr .= "
      <tr>
        <td style='text-align: center;'>$row[Product_Name]</td>
        <td style='text-align: center;'>$row[productSold]</td>
        <td style='text-align: center;'>$row[averageDay]</td>
      </tr>
    ";
  }
  $table = '
    <table class="table">
      <thead id="List">
        <th style="text-align: center;">PRODUCT NAME</th>
        <th style="text-align: center;">SOLD QUANTITY</th>
        <th style="text-align: center;">AVG. SOLD PER DAY</th>
      </thead>
      <tbody style="text-align: center;">
        ' . $tr . '
      </tbody>
    </table>
  ';
} elseif ($basis == "FastMoving") {
  $sql = " SELECT `Product_Name`, SUM(`quantity`) AS `productSold`,  (SUM(`Quantity`) / 30) AS `averageDay` 
   FROM `transaction_items`
    INNER JOIN products ON transaction_items.product_id = products.product_id
    INNER JOIN transactions ON transaction_items.transaction_id = transactions.transaction_id
    WHERE transactions.`date_created` BETWEEN CURDATE() - INTERVAL 30 DAY AND CURDATE() 
    GROUP BY `Product_Name`  
    ORDER BY `averageDay` DESC
    LIMIT 5;
  ";
  $result = $conn->query($sql);

  $tr = "";
  while ($row = $result->fetch_assoc()) {
    $tr .= "
      <tr>
        <td style='text-align: center;'>$row[Product_Name]</td>
        <td style='text-align: center;'>$row[productSold]</td>
        <td style='text-align: center;'>$row[averageDay]</td>
      </tr>
    ";
  }
  $table = '
    <table class="table">
      <thead id="List">
        <th style="text-align: center;">PRODUCT NAME</th>
        <th style="text-align: center;">SOLD QUANTITY</th>
        <th style="text-align: center;">AVG. SOLD PER DAY</th>
      </thead>
      <tbody style="text-align: center;">
        ' . $tr . '
      </tbody>
    </table>
  ';
} elseif ($basis == "SlowMoving") {
  $sql = " SELECT `Product_Name`, SUM(`quantity`) AS `productSold`,  (SUM(`Quantity`) / 30) AS `averageDay` 
   FROM `transaction_items`
    INNER JOIN products ON transaction_items.product_id = products.product_id
    INNER JOIN transactions ON transaction_items.transaction_id = transactions.transaction_id
    WHERE transactions.`date_created` BETWEEN CURDATE() - INTERVAL 30 DAY AND CURDATE() 
    GROUP BY `Product_Name`  
    ORDER BY `averageDay` ASC
    LIMIT 5;
  ";
  $result = $conn->query($sql);

  $tr = "";
  while ($row = $result->fetch_assoc()) {
    $tr .= "
      <tr>
        <td style='text-align: center;'>$row[Product_Name]</td>
        <td style='text-align: center;'>$row[productSold]</td>
        <td style='text-align: center;'>$row[averageDay]</td>
      </tr>
    ";
  }
  $table = '
    <table class="table">
      <thead id="List">
        <th style="text-align: center;">PRODUCT NAME</th>
        <th style="text-align: center;">SOLD QUANTITY</th>
        <th style="text-align: center;">AVG. SOLD PER DAY</th>
      </thead>
      <tbody style="text-align: center;">
        ' . $tr . '
      </tbody>
    </table>
  ';
}

$crit = isset($_GET["crit"]) ? $_GET["crit"] : "CritLvl";

if ($crit == "CritLvl") {
  $sql = "SELECT 
  `products`.`product_name`,
  `products`.`product_id`,
  `products`.`stock_status`,
  `products`.`warning_level`,
  `products`.`archive_status`,
  `batch`.`archive_status`,
  SUM(`batch`.`unpacked_quantity` + `batch`.`quantity`) AS `stocks`,
  (SELECT unit_name FROM unit_of_measurement WHERE unit_id = products.retail_unit) AS retail_unit,
  IF(SUM(`batch`.`unpacked_quantity` + `batch`.`quantity`) = 0, 'Out of Stocks', 
     IF(SUM(`batch`.`unpacked_quantity` + `batch`.`quantity`) <= `products`.`warning_level`, 'Critical', 'In stock')) AS critical
FROM products
INNER JOIN `batch` ON `products`.`product_id` = `batch`.`product_id`
WHERE `products`.`archive_status` = 0 AND `batch`.`archive_status` = 0 AND `products`.`stock_status` > 1
GROUP BY `products`.`product_name`, `products`.`product_id`, `products`.`stock_status`, `products`.`warning_level`, `products`.`archive_status`, `batch`.`archive_status`, `products`.`retail_unit`;
";
  $result = $conn->query($sql);

  $tr = "";
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

      $tr .= "
      <tr>
        <td style='text-align: center;'>$row[product_name]</td>
      </tr>
    ";
    }
  } else {
    $tr = "<tr><td colspan='3' style='height: 250px; text-align: center; vertical-align: middle;'><div class='container-fluid'><p class='text-center ms-5'>No Result</p></td></tr>";
  }

  $tables = '
  <table class="table">
    <thead id="List">
      <th style="text-align: center;">PRODUCT NAME</th>
    </thead>
    <tbody style="text-align: center;">
      ' . $tr . '
    </tbody>
  </table>
';
}

//total transaction made today
$card_sql = "SELECT COUNT(*) AS transaction_count
FROM transactions
WHERE DATE(date_created) = CURDATE();";
$card_result = $conn->query($card_sql);
$rows = mysqli_fetch_assoc($card_result);
$transaction_count = $rows['transaction_count'];

//total earning today
$earn_sql = "SELECT SUM(total) AS earnings
FROM transactions
WHERE DATE(date_created) = CURDATE();";
$earn_result = $conn->query($earn_sql);
$earn_row = mysqli_fetch_assoc($earn_result);
$earn_count = number_format($earn_row["earnings"], 2);

//total earning this month
$earning_month_sql = "SELECT SUM(total) AS earning_month 
FROM transactions 
WHERE MONTH(date_created) = MONTH(CURDATE()) AND YEAR(date_created) = YEAR(CURDATE())";
$month_result = $conn->query($earning_month_sql);
$month_row = mysqli_fetch_assoc($month_result);
$month_count = number_format($month_row["earning_month"], 2);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!--Bootstrap-->
  <link rel="stylesheet" href="./bootstrap/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
  <script src="./bootstrap/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

  <!--Jquery-->
  <script src="./js/jquery_3.6.4_jquery.min.js"></script>
  <script src="./js/chart.js"></script>
  <script src="./bootstrap//popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
  <script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>

  <script>
    $(function() {
      $('[data-toggle="tooltip"]').tooltip();
    })
  </script>

  <!--Fontawesome-->
  <link rel="stylesheet" href="./fontawesome/css/all.min.css">

  <!--CSS-->
  <link rel="stylesheet" href="./css/styles.css">
  <link rel="stylesheet" href="./css/card.css">


  <link rel="icon" type="image/png" href="./assets/<?php echo $logo ?>" />
  <title>Dashboard</title>
</head>

<body>
  <?php
  include("./includes/navbar.php");
  ?>

  <!--main page-->
  <!--cards-->
  <div class="container-fluid main-div py-4" id="main-div">
    <h2 class="ml-5">Dashboard</h2>
    <div class="row">
      <div class="col-md-3">
        <div class="card bg-c-first order-card">
          <div class="card-block">
            <h6 class="m-b-20" style="float: right;">Total Transaction Today</h6>
            <h2 class="text-right"><img src="./assets/transaction.png" alt="" width="90" height="90" style="float: left;"></br><span><?php echo $transaction_count; ?></span></h2>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card bg-c-second order-card">
          <div class="card-block">
            <h6 class="m-b-20" style="float: right;">Total Earnings Today</h6>
            <h2 class="text-right"><img src="./assets/peso.png" alt="" width="90" height="90" style="float: left;"></br><span><?= $earn_count?></span></h2>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card bg-c-third order-card">
          <div class="card-block">
            <h6 class="m-b-20" style="float: right;">Total Earnings This Month</h6>
            <h2 class="text-right"><img src="./assets/earning.png" alt="" width="90" height="90" style="float: left;"></br><span><?= $month_count?></span></h2>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-4">
          <div class="shadow p-3" style="height: 450px; width: 480px; overflow-y: auto;">
            <form action="" method="get">
              <select class="form-control" name="basis" id="basis" style="float: right; width: 40%;" onchange="this.form.submit()">
                <option value="TopSelling" <?= $basis == "TopSelling" ? "selected" : "" ?>>Top Selling</option>
                <option value="FastMoving" <?= $basis == "FastMoving" ? "selected" : "" ?>>Fast Moving</option>
                <option value="SlowMoving" <?= $basis == "SlowMoving" ? "selected" : "" ?>>Slow Moving</option>
              </select>
        </form>
        <div class="col mt-4">
          <br>
          <br>    
          <?= $table ?>
        </div>
      </div>
    </div>

    <div class="col-md-5  ">
      <div class="shadow p-3" style="height: 450px; overflow-y: auto;">
        <h4>Sales Last 7 days</h4>
        <form action="" method="get">
          <select hidden="hidden" name="last7days" id="last7days"></select>
          <option value="current"></option>
          <div class="canvas-container mx-auto justify-content-center align-items-center mt-3" style="width: 100%; height: 300px;">
            <canvas id="SalesChart" class="canvas-center"></canvas>
          </div>
        </form>
      </div>
    </div>
    <div class="col-md-3">
      <div class="shadow p-3" style="height: 620px; width: 300px; overflow-y: auto; margin-top: -170px">
        <form action="" method="get"><h6 class="text-center p-3" style="background-color: #7c2c25; color: white; margin-bottom: -66px;"> Critical Level Items </h6>
           <select hidden="hidden" class="form-control mt-4" name="crit" id="crit" style="float: right; width: 40%;" onchange="this.form.submit()">
            <option value="Critlvl" <?= $crit == "Critlvl" ? "selected" : "" ?>>Critical Level</option>
          </select>
        </form>
        <div class="col mt-4">
          <br>
          <br>
          <?= $tables ?>
        </div>
      </div>
    </div>
  </div>
  </div>



  <script>
    const ctx = document.getElementById('SalesChart');

    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: <?= $dateArray ?>,
        datasets: [{
          label: 'Sales total',
          data: <?= $totalArray ?>,
          borderWidth: 1,
          backgroundColor: ['blue']
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        },
        maintainAspectRatio: false,
        responsive: true,
      }
    });
  </script>
</body>

</html>