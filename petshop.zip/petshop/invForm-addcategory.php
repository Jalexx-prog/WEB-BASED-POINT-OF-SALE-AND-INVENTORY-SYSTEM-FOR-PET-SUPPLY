<?php
try{
    session_start();
    include("./includes/connection.php");
    include('./includes/log_check.php');
    include ('./includes/checkRole.php');
    
    date_default_timezone_set('Asia/Manila');
    $user = $_SESSION["user_id"];
    $date = date("Y-m-d H-i-s");

$categoryname = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["newcategory"])) {
    $categoryname = $_POST["newcategory"];

    // Insert category into the database
    $categorySql = "INSERT INTO category (category_name) VALUES ('$categoryname')";
    $categoryResult = $conn->query($categorySql);

    if (!$categoryResult) {
        die("Category insertion failed: " . $conn->error);
    }

    $categoryId = $conn->insert_id;

    
    $_SESSION["message"] = "category-added";
    header("location: ./inv-category.php");
    exit();


}  else{   //runs if there are no POST method
        $_SESSION["message"] = "error";
        header("location: ./inv-category.php");
        exit();

}

}
catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    header("location: ./inv-productList.php");
    exit();
}
?>