<?php

session_start();
include('includes/connection.php');

if (isset($_SESSION['username']) && isset($_SESSION['role'])) {
    session_unset();
    session_destroy();
}

header("Location: ./logForm-loginpage.php");
exit();
?>