<?php
try{
session_start();
include("./includes/connection.php");
include('./includes/log_check.php');
include ('./includes/checkRole.php');
    
date_default_timezone_set('Asia/Manila');


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["change_role"])) {

    $change_role = ($_POST["change_role"] == 1) ? 0 : 1;
    $id = $_POST["id"];
    
  
    // Update category name in the database
    $categorySql = "UPDATE user SET role = '$change_role' WHERE user_id = $id";
    $categoryResult = $conn->query($categorySql);
  
    if (!$categoryResult) {
        die("Category update failed: " . $conn->error);
    }
  }


    $_SESSION["message"] = "Account-role";
    header("location: ./manage-account.php");
    exit();

} catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    echo $e;
    header("location: ./manage-account.php");
    exit();
}
?>