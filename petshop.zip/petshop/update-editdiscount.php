<?php
try{
session_start();
include("./includes/connection.php");
include('./includes/log_check.php');
include ('./includes/checkRole.php');
    
date_default_timezone_set('Asia/Manila');


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["edit_dcname"]) && isset($_POST["edit_percent"])) {
    $editDCName = $_POST["edit_dcname"]; 
    $editPercent = $_POST["edit_percent"];
    $id = $_POST["id"];
  
    // Update category name in the database
    $categorySql = "UPDATE `discount` SET `discount_name`='$editDCName',`percent`='$editPercent' WHERE discount_id = $id";
    $editDiscountResult = $conn->query($categorySql);
  
    if (!$editDiscountResult) {
        die("Edit discount update failed: " . $conn->error);
    }
  }


    $_SESSION["message"] = "discount-edited";
    header("location: ./discount-page.php");
    exit();

} catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    echo $e;
    header("location:./discount-page.php");
    exit();
}
?>