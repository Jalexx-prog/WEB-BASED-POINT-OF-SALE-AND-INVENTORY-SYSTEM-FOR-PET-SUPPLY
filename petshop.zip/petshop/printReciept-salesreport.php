<?php
session_start();

include("./includes/connection.php");
include('./includes/log_check.php');
date_default_timezone_set('Asia/Manila');

$id = $_GET["transaction"];

$logo = $conn->query("SELECT `logo` FROM `system`")->fetch_assoc()["logo"];
$surname = $conn->query("SELECT `user`.`last_name` FROM `transactions` INNER JOIN `user` ON `transactions`.`created_by` = `user`.`user_id` WHERE `transaction_id` = '$id'")->fetch_assoc()["last_name"];
$given = $conn->query("SELECT `user`.`first_name` FROM `transactions` INNER JOIN `user` ON `transactions`.`created_by` = `user`.`user_id` WHERE `transaction_id` = '$id'")->fetch_assoc()["first_name"];;
    if($_SESSION["role"] == 0){
      header("Location: ./landingpage-dashboard.php");
    }

    ?>
<head>
<link rel="icon" type="image/png" href="./assets/<?=$logo?>"/>
<!--Jquery-->
<script src="./js/jquery_3.6.4_jquery.min.js"></script>
    <title>Reciept</title>
    <style>
        * {
           margin: 0;
           padding: 0;
     
        }
          h3, p, .product-name, .product-quantity, .product-subtotal, .total-label, .total-value, .footer {
        font-family: Helvetica, sans-serif; /* Replace 'Your Chosen Font' with the desired font family */
    }

        hr{
            border: 1px solid black;
            margin: 5px 0px;
        }
        @media print {
            .print-hide {
                display: none !important;
            }
        }


        .store-logo{
            max-width: 70px;
            margin: 0 auto; 
            display: block; 

        }
        .address {
            font-size: 12px;
            margin: 5px 0;
            text-align: center;

        }

        .receipt-info p {
            font-size: 13px;
            margin: 3px 0;
        }
        
        .product-list {
            font-size: 13px;
            margin: 3px 0;
        }

        .product {
            display: flex;
            justify-content: space-between;
            size: 10px;
        }

        .product-name {
            flex: 1;
            word-wrap: break-word;
        }

        .table{
            font-size: 12px;

        }
        .product-quantity{
            flex: 1;
            white-space: nowrap; /* Prevent line breaks within the quantity */
            overflow: hidden; /* Hide any content that exceeds the container */
            text-overflow: ellipsis; /* Display an ellipsis (...) if the content overflows */
            margin-left: 10px;
            margin-right: 10px;
        }
        .product-subtotal {
            flex: 1;
            word-wrap: break-word;
        }

        .total {
            font-size: 13px;
            margin: 3px 0;
            float: left;
        }

        .total-label {
            text-align: left;
            float: left;
            clear: left;
            width: 50%;
            font-weight: bold;
        }

        .total-value {
        text-align: right;
        float: left;
        width: 44%;
    }

        .footer {
            font-size: 11px;
            margin-top: 50px;
        }
        .product-name{
            float: left;
        }

    </style>
</head>
<?php

$receipt_sql = "SELECT * FROM `system` WHERE 1";
$receipt_res = $conn->query($receipt_sql);

while( $row = $receipt_res->fetch_assoc()){


?>
    <div class="receipt" style="margin: auto; margin-left: auto; width: 57mm;">
            <img class="store-logo" src="assets/<?=$logo ?>" alt="logo">
            <h3 style="text-align: center;"><?php echo "$row[store_name]"?></h3>
            <p class="address"><?php echo "$row[store_address]"?></p>
            <p class="address">Contact#: <?php echo "$row[contact]"?></p>
            <p class="address">TIN number: <?php echo "$row[tin_number]"?></p>
  <?php }  ?>
            <p class="address">Cashier: <?php echo $surname . ', ' . $given; ?></p>
        <div class="receipt-info">
            <p style="text-align: center;">Date: <?php echo date('m/d/Y h:i a'); ?></p>
            <hr>
            <p style="text-align: center;">BRK-<?php echo $id; ?></p>
            <hr>
        </div>
        <div class="product-list">
            <?php
                $result = $conn->query("
                    SELECT *, `products`.`product_name`
                    FROM `transaction_items` 
                        INNER JOIN `products` ON `transaction_items`.`product_id` = `products`.`product_id`
                    WHERE `transaction_id` = '$id'
                ");

                while($row = $result->fetch_assoc()){
                    echo '<div class="product">';
                    echo '<table class="table">';
                    echo '<tr>';
                    echo '<td><p class="product-name">' . $row["product_name"] . '</p></td>';
                    echo '<td><p class="product-quantity">' . $row["quantity"] ." ". $row["unit"]. '</p>';
                    echo '<td><p class="product-subtotal">' . number_format($row["subtotal"], 2) . '</p>';
                    echo '</table>';
                    echo '</div>';
                }
            ?>
        </div>
        <div class="total" style="margin: auto; width: 57mm;">
           <hr>
           <?php
            $total = $conn->query("SELECT `total` FROM `transactions` WHERE `transaction_id` = '$id'")->fetch_assoc()["total"];
            $amountTendered = $conn->query("SELECT `amount_tendered` FROM `transactions` WHERE `transaction_id` = '$id'")->fetch_assoc()["amount_tendered"];
            $change = $conn->query("SELECT `change_amount` FROM `transactions` WHERE `transaction_id` = '$id'")->fetch_assoc()["change_amount"];
            $vatableSales = $conn->query("SELECT `vatable_sales` FROM `transactions` WHERE `transaction_id` = '$id'")->fetch_assoc()["vatable_sales"];
            $vatAmount = $conn->query("SELECT `vat_amount` FROM `transactions` WHERE `transaction_id` = '$id'")->fetch_assoc()["vat_amount"];
            $discount = $conn->query("SELECT `discount` FROM `transactions` WHERE `transaction_id` = '$id'")->fetch_assoc()["discount"];
           ?>
            <p class="total-label">Total Amount:</p> <p class="total-value" > <?php echo number_format($total, 2); ?></p><br>
            <p class="total-label">VAT Sale:</p> <p class="total-value"> <?php echo number_format($vatableSales, 2); ?></p><br>
            <p class="total-label">VAT Amount:</p> <p class="total-value"><?php echo number_format($vatAmount, 2); ?></p><br>
            <p class="total-label">Discount:</p> <p class="total-value"> <?php echo $discount."%"; ?></p><br>
            <p class="total-label">Cash:</p> <p class="total-value"> <?php echo number_format($amountTendered, 2); ?></p><br>
            <p class="total-label">Change:</p> <p class="total-value"> <?php echo number_format($change, 2); ?></p><br>
            <hr>
        </div>
        <div class="footer" style="margin: auto; width: 57mm;">
            <b><p style="text-align: center;">THIS RECIEPT IS NOT <br> OFFICIAL</p>
        </div>
    </div>
    <div id="buttondiv" style="margin: 30px auto; display: flex; justify-content: center;">
    <a href="./report-salesreport.php"><button type="button" class="button-back print-hide">Return</button></a>&nbsp;&nbsp;&nbsp;
    <button type="button" class="button-print print-hide" onclick="printReceipt()">Print</button>
</div>
<script>
    function hidebuttons(){
        $('#buttondiv').css("display", "none");
        window.print();
        $('#buttondiv').css("display", "flex");
    }

    function printReceipt(){
        $(".receipt").css("margin-left", "-1px");
        window.print();
        $(".receipt").css("margin-left", "auto");
    }
    
</script>