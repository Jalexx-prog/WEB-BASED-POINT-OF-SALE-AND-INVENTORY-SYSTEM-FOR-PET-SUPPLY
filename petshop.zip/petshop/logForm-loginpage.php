<?php
session_start();
include('includes/connection.php');

 $logo = $conn->query("SELECT `logo` FROM `system`")->fetch_assoc()["logo"];

if (isset($_POST['login'])) {
    $user = $_POST['user'];
    $password = $_POST['password'];

    // Prepare the SQL statement with placeholders and use prepared statements
    $sql = "SELECT user_id, first_name, last_name, username, password, role, profile_picture FROM user WHERE username = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $user);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION["user_id"] = $row['user_id'];
            $_SESSION["profile_pic"] = $row['profile_picture'];
            $_SESSION["username"] = $user;
            $_SESSION["role"] = $row['role'];
            $_SESSION["first_name"] = $row['first_name'];
            $_SESSION["last_name"] = $row['last_name'];
            $_SESSION["security_question1"] = $row['security_question1'];
            $_SESSION["answer_1"] = $row['answer_1'];
            $_SESSION["security_question2"] = $row['security_question2'];
            $_SESSION["answer_2"] = $row['answer_2'];

            if ($row['role'] == 1) {
                // Admin user
                header('Location: ./landingpage-dashboard.php');
                exit;
            } elseif ($row['role'] == 0) {
                // Regular user
                header('Location: ./landingpage-dashboard.php');
                exit;
            }
        } else {
            // Password is incorrect
            $error_message = "Invalid Username or Password";
        }
    } else {
        // User doesn't exist
        $error_message = "Invalid Username or Password";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <!--Bootstrap-->
      <link rel="stylesheet" href="./bootstrap/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/login.css">
      <script src="./bootstrap/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    
    <!--Jquery-->
    <script src="./js/jquery_3.6.4_jquery.min.js"></script>
    <script src="./bootstrap//popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>

    <script>
        $(function () {
            $('[data-toggle="tooltip"]').tooltip();
        })
    </script>
    <!--Fontawesome-->
    <link rel="stylesheet" href="./fontawesome/css/all.min.css">

    <!--CSS-->
    <link rel="stylesheet" href="./css/login.css">

    <link rel="icon" type="image/png" href="./assets/<?=$logo ?> "/>
    <title>Login </title>
    <style>
      input::-ms-reveal,
      input::-ms-clear {
        display: none;
      }
    </style>
</head>
<body>
<div class="overlay"></div>
<div class="contianer">
      <div class="row">
      <img src="./assets/<?=$logo ?>" id="logo" class="img-fluid" alt="Logo">
          <div class="wrapper">
              <h1>Login</h1>
                <form action="" method="post" >
                    <div class="input-box">
                      <input type="text" name="user" placeholder="Username" autocomplete="off" required><i class="fa-solid fa-user"></i>
                  </div>
                  <div class="input-box">
                  <input type="password" name="password" id="password" placeholder="Password" required>
                  <i class="fa-solid fa-lock"></i>
                  <span id="password-toggle" class="eye-icon" onclick="togglePasswordVisibility()"><i class="fa-solid fa-eye"></i></span>
              </div>
                  <p id="error-message" class="error-message"></p>
                  <div class="text-center">
                    <button type="submit" name="login" class="btn btn-light">Login</button>
                    <br/>
                    <div class="mt-2"> <a href="" data-toggle="modal" data-target="#fpass-usernameCheckModal" >Forgot password?</a> </div>
                  </div>
              </form>
          </div>
      </div> 
    </div> 

<!--modal here forgot password -->
<!-- Modal -->

<!--Modal to check username-->
<div class="modal fade" id="fpass-usernameCheckModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Find your account</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
        <label for="">Please enter your username to search for your account.</label>
        <input type="text" class="form-control" id="fpass-username" placeholder="Username" autocomplete="off">
        <div id="fpass-username-error" class="text-danger"></div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary" id="fpass-submit-username">Submit</button>
        </form>
      </div>
    </div>
  </div>
</div>



<!-- Modal for question -->
<div class="modal fade" id="fpass-securityQuestionModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Security Questions</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
    
        <div class="form-group mb-3">
          <label for="fpass-answer1" id="fpass-question1">...</label>
          <input type="text" class="form-control" id="fpass-answer1" placeholder="Answer" autocomplete="off">
        </div>
        
        
        <div class="form-group mb-3">
          <label for="fpass-answer2" id="fpass-question2">...</label>
          <input type="text" class="form-control" id="fpass-answer2" placeholder="Answer" autocomplete="off">
          <div id="cooldown"></div>
        </div>
        
        <div id="fpass-answer-error" class="text-danger"></div>
        <span id="attemptMsg" style="font-size:10px;"></span>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal" data-toggle="modal" data-target="#fpass-usernameCheckModal">Back</button>
        <button type="button" class="btn btn-primary" id="fpass-submit-answer">Submit</button>
      </div>
    </div>
  </div>
</div>




<!-- Change Password Modal -->
<div class="modal fade" id="fpass-changePasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Change Password</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

        <div class="form-group mb-3">
          <label for="new-password">New Password</label>
          <input type="password" class="form-control" id="new-password">
        </div>
        
        
        <div class="form-group mb-3">
          <label for="confirm-password">Confirm Password</label>
          <input type="password" class="form-control" id="confirm-password">
          <div id="fpass-cpass-error" class="text-danger"></div>
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal" data-toggle="modal" data-target="#fpass-securityQuestionModal">Back</button>
        <button type="button" class="btn btn-primary" id="fpass-update-password">Save changes</button>
      </div>
    </div>
  </div>
</div>



<!-- Success Modal -->
<div class="modal fade" id="fpass-successMessageModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Password Updated Successfully
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>






<div id="scriptDiv"></div>

<script>
    <?php
    if (isset($error_message)) {
        echo "document.getElementById('error-message').textContent = '$error_message';";
    }
    ?>
</script>

<script>

  function getMinutesAndSeconds(date1, date2) {
    // Get the time difference in milliseconds
    const timeDiff = Math.abs(date2.getTime() - date1.getTime());

    // Convert milliseconds to minutes and seconds
    const minutes = Math.floor(timeDiff / 60000); // 1 minute = 60,000 milliseconds
    const seconds = Math.floor((timeDiff % 60000) / 1000); // 1 second = 1,000 milliseconds

    return { minutes, seconds };
  }
  

  function enableAttempt(user){
    clearInterval(window.timeInterval);
    $("#fpass-answer-error").html("");

    $("#fpass-answer1").val("");
    $("#fpass-answer2").val("");
    $("#fpass-answer1").attr("disabled", false);
    $("#fpass-answer2").attr("disabled", false);
    $("#fpass-submit-answer").attr("disabled", false);
    $("#attemptMsg").html("");

    $.post("./ajax/forgotPassword.php", {
            type: "enableAttempt",
            username: user
        },
        function(data){
            //
        });
  }

  function disableAttempt(user, nextAttempt){
    $("#fpass-answer1").attr("disabled", true);
    $("#fpass-answer2").attr("disabled", true);
    $("#fpass-submit-answer").attr("disabled", true);


    window.timeInterval = setInterval(function () {
        // Example usage
        const date1 = new Date();
        const date2 = new Date(nextAttempt);
        const { minutes, seconds } = getMinutesAndSeconds(date1, date2);

        $("#attemptMsg").html(`You have entered wrong Answer many times <br> Try again <br> in ` + (minutes > 10 ? minutes + `:` : '') + `${seconds}`);

        if(minutes <= 0 && seconds <= 0){
            enableAttempt(user);
            clearInterval(window.timeInterval);
        }
    }, 1000);

  
  }




  
  //check if username exist
  $("#fpass-submit-username").click(function(){
    var user = $("#fpass-username").val();
    $.post(
      "./ajax/forgotPassword.php",
      {
        type: "username-check",
        username: user
      },
      function(data) {
        $("#scriptDiv").html(data);
      }
    );
  });

  //check if answers are correct
  $("#fpass-submit-answer").click(function(){
    var user = $("#fpass-username").val();
    var a1 = $("#fpass-answer1").val();
    var a2 = $("#fpass-answer2").val();
    $.post(
      "./ajax/forgotPassword.php",
      {
        type: "answer-check",
        username: user,
        answer1: a1,
        answer2: a2
      },
      function(data) {
        $("#scriptDiv").html(data);
      }
    );
  });


  //check if answers are correct
  $("#fpass-update-password").click(function(){
    var user = $("#fpass-username").val();
    var pass = $("#new-password").val();
    var cpass = $("#confirm-password").val();
    $.post(
      "./ajax/forgotPassword.php",
      {
        type: "update-password",
        username: user,
        new_password: pass,
        confirm_password: cpass
      },
      function(data) {
        $("#scriptDiv").html(data);
      }
    );
  });


function togglePasswordVisibility() {
    var passwordInput = document.getElementById('password');
    var passwordToggle = document.getElementById('password-toggle');

    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        passwordToggle.innerHTML = '<i class="fa-solid fa-eye-slash"></i>';
    } else {
        passwordInput.type = 'password';
        passwordToggle.innerHTML = '<i class="fa-solid fa-eye"></i>';
    }
}

// Function to check if the password field has input
function checkPasswordInput() {
    var passwordInput = document.getElementById('password');
    var passwordToggle = document.getElementById('password-toggle');
    
    if (passwordInput.value.length > 0) {
        passwordToggle.style.display = 'block';
    } else {
        passwordToggle.style.display = 'none';
    }
}

//event listener for see password
var passwordInput = document.getElementById('password');
passwordInput.addEventListener('input', checkPasswordInput);
window.addEventListener('load', checkPasswordInput);
</script>
</body>
</html>