<html>
<head>
    <?php
    session_start();
    include('./includes/log_check.php');
    include ('./includes/checkRole.php');
    ?>
<style>
p.inline {display: inline-block;}
span { font-size: 13px;}
</style>
<style type="text/css" media="print">
    @page 
    {
        size: auto;   /* auto is the initial value */
        margin: 0mm;  /* this affects the margin in the printer settings */

    }
    @media print {
            /* Hide elements with the print-hide class when printing */
            .print-hide {
                display: none !important;
                
            }
              /* Hide the expiration date when printing if the checkbox is checked */
              #expirationDateCheckbox:checked ~ p .expiration-date {
                display: none !important;
              }
              body {
        zoom: 80%; /* Adjust the percentage as needed */
    }
        }
        
</style>
</head>
<body onload="window.print();">
	<div>
        <center>
	   <?php
        date_default_timezone_set('Asia/Manila');
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Get the selected items from the form
            $productId = $_POST['productId'];
            $barcode = $_POST['barcode'];
            $productName = wordwrap($_POST['productName'],20,"<br>\n");
            $price = $_POST['price'];
            $expirationDate = $_POST['expirationDate'] !== "0000-00-00" ? date("m/d/Y", strtotime($_POST['expirationDate'])) : "N/A";
            
            $count = $_POST["count"];

            $date = date("m/d/Y");

            for ($i = 1; $i <= $count; $i++) {

                echo "
                    <p class='inline' style='text-align: center'>
                        <span><b>$productName</b></span>
                        <br>
                        <img src='./barcode/barcode_$productId.png' style='height: 70px'>
                        <br>$barcode<br>
                        <span><b>₱ ".number_format($price, 2)."
                        <br>
                        <span class='expiration-date'>Prod Date: $date </span>
                        <br>
                        <span class='expiration-date'>Exp Date: $expirationDate</span></b></span>
                        
                    </p>
                    &nbsp&nbsp&nbsp&nbsp
                ";
            }
        }
    
        ?>
        </center>
        <div id="buttondiv" style="margin: 30px auto; display: flex; justify-content: center;">
    <input type="checkbox" class="button-print print-hide" id="expirationDateCheckbox" onclick="hideExpirationDate()">
            <label class="button-print print-hide" for="expirationDateCheckbox">Hide Expiration Date</label>
        </div>
         <div id="buttondiv" style="margin: 30px auto; display: flex; justify-content: center;">
    <a href="./inv-productList.php"><button type="button" class="button-back print-hide">Return</button></a>&nbsp;&nbsp;&nbsp;
    <button type="button" class="button-print print-hide" onclick="window.print()">Print</button>
    </div>
</div>

<script>
    function hidebuttons(){
        $('#buttondiv').css("display", "none");
        window.print();
        $('#buttondiv').css("display", "flex");
    }
    function hideExpirationDate() {
                var expirationDateElements = document.getElementsByClassName('expiration-date');
                for (var i = 0; i < expirationDateElements.length; i++) {
                    expirationDateElements[i].style.display = document.getElementById('expirationDateCheckbox').checked ? 'none' : 'inline';
                }
            }
</script>
        
	</div>
</body>
</html>