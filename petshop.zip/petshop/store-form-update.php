<?php
try {
    session_start();

    include('includes/connection.php');
    include('./includes/log_check.php');
    include ('./includes/checkRole.php');


    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        $storeName = $_POST['store_name'];
        $storeAddress = $_POST['store_address'];
        $tinNumber = $_POST['tin_number'];
        $contact = $_POST['contact'];
        $id = $_POST['id'];
        $logoPath = isset($_FILES["logo"]["name"]) ? $_FILES["logo"]["name"] : "";

        // Check if navbar_color and sidebar_color are empty, use the current values from hidden fields
        $navbarColor = empty($_POST['navbar_color']) ? $_POST['current_navbar_color'] : $_POST['navbar_color'];
        $sidebarColor = empty($_POST['sidebar_color']) ? $_POST['current_sidebar_color'] : $_POST['sidebar_color'];
        $hoverColor = empty($_POST['hover_color']) ? $_POST['current_hover_color'] : $_POST['hover_color'];



        if (!empty($_FILES['logo']['name'])) {
            $uploadDir = 'assets/';
            $logoName = basename($_FILES['logo']['name']);
            $logoPath = $uploadDir . $logoName;

            // Check if the file is an image
            $imageFileType = strtolower(pathinfo($logoPath, PATHINFO_EXTENSION));
            $allowedExtensions = array("jpg", "jpeg", "png", "gif");


            if (in_array($imageFileType, $allowedExtensions)) {
                if (is_uploaded_file($_FILES["logo"]["tmp_name"]) && move_uploaded_file($_FILES["logo"]["tmp_name"], __DIR__ . '/' . $logoPath)) {

                    $query = "UPDATE `system` SET `logo` = '$logoName' WHERE `system_id` = '$id'";
                    $result = $conn->query($query);
                }
            }
        }

        // Update the database record
        $updateSql = "UPDATE system SET
        store_name = '$storeName',
        store_address = '$storeAddress',
        tin_number = '$tinNumber',
        contact = '$contact',
        navbar_color = '$navbarColor',
        sidebar_color = '$sidebarColor',
        hover_color = '$hoverColor'
        WHERE system_id = $id";
        $sql_res = $conn->query($updateSql);

        $_SESSION["message"] = "store-details";
        header("location: ./store_setting.php");
        exit();

    } else {   //runs if there are no POST method
        $_SESSION["message"] = "error";
        header("location: ./store_setting.php");
        exit();
    }
} catch (Exception $e) {    //runs if there is an error
    $_SESSION["message"] = "error";
    echo $e;
    header("location: ./store_setting.php");
    exit();
}
