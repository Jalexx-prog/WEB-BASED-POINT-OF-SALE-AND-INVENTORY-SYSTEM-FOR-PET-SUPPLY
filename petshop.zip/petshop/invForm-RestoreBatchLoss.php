<?php
try {
    session_start();
    include("./includes/connection.php");
    include('./includes/log_check.php');
    include('./includes/checkRole.php');

    date_default_timezone_set('Asia/Manila');
    $user = $_SESSION["user_id"];
    $date = date("Y-m-d H-i-s");

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $id = $_POST["id"];
        $batchID = $_POST["batchId"];
        $unpacked = $_POST["unpacked"];
        $quantity = $_POST["quantity"];

        $conn->query("
        UPDATE `batch` SET 
        `unpacked_quantity`= (`unpacked_quantity` + $unpacked),
        `quantity`= (`quantity` + $quantity)
        WHERE batch_id = $batchID
        ");

        $conn->query("
        DELETE FROM `batch_loss` WHERE id = $id
        ");

        $_SESSION["message"] = "batch-loss-restore";
        header("location: ./inv-productArchive.php");
        exit();

    } else {   //runs if there are no POST method
        $_SESSION["message"] = "error";
        header("location: ./inv-productArchive.php");
        exit();
    }
} catch (Exception $e) {    //runs if there is an error
    $_SESSION["message"] = "error";
    echo $e;
    header("location: ./inv-productArchive.php");
    exit();
}
