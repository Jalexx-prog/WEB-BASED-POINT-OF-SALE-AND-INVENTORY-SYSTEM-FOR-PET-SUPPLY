<?php
try{
session_start();
include('./includes/log_check.php');
include ('./includes/checkRole.php');


date_default_timezone_set('Asia/Manila');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST["id"];

    include("./includes/connection.php");


    $sql = "DELETE FROM unit_of_measurement WHERE unit_id = '$id'";
    $conn->query($sql);
    

    $_SESSION["message"] = "unit-deleted";
    header("location: ./inv-unitofmeasurement.php");
    exit;
}

}catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    header("location: ./inv-unitofmeasurement.php");
    exit();
}
?>
