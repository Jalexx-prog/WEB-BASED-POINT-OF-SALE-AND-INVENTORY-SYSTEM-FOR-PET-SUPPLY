<?php
try{
session_start();
include("./includes/connection.php");
include('./includes/log_check.php');
include ('./includes/checkRole.php');
    
date_default_timezone_set('Asia/Manila');


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["status"])) {

    $status = ($_POST["status"] == 1) ? 0 : 1;
    $id = $_POST["id"];
    
    $discountsql = "UPDATE discount SET discount_status = '$status' WHERE discount_id = '$id'";
    $discountResult = $conn->query($discountsql);
  
    if (!$discountResult) {
        die("discount result update failed: " . $conn->error);
    }
  }


    $_SESSION["message"] = "discount-status";
    header("location: ./deals-page.php");
    exit();

} catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    echo $e;
    header("location: ./deals-page.php");
    exit();
}
?>