<?php
try{
    session_start();
    include("./includes/connection.php");
    include('./includes/log_check.php');
    include ('./includes/checkRole.php');
    
    date_default_timezone_set('Asia/Manila');
    $user = $_SESSION["user_id"];
    $date = date("Y-m-d H-i-s");

    if($_SERVER["REQUEST_METHOD"] === "POST"){
        $batchId = $_POST["batchId"];
        $remarks = $_POST["archiveRemarks"];

      
        $conn->query("
            UPDATE `batch` 
            SET 
                `archive_status`= 1,
                `date_archived`='$date',
                `archived_by`='$user',
                `archive_remarks`=' $remarks'
            WHERE `batch_id` = '$batchId'
        ");

        include("./includes/updateProductStatus.php");
        include("./includes/updateExpirationStatus.php");
        
        $_SESSION["message"] = "batch-archived";
        header("location: ./inv-productList.php");
        exit();

        
    }
    else{   //runs if there are no POST method
        $_SESSION["message"] = "error";
        header("location: ./inv-productList.php");
        exit();


    }
}
catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    echo $e;
    header("location: ./inv-productList.php");
    exit();
}
    
?>