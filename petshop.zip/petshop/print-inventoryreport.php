<?php
session_start();
include('includes/connection.php');
include('includes/log_check.php');
include('./includes/checkRole.php');

date_default_timezone_set('Asia/Manila');
$user = $_SESSION["user_id"];
$date = date("M d, Y");
$time = date("h:i a");


$logo = $conn->query("SELECT `logo` FROM `system`")->fetch_assoc()["logo"];
$storeName = $conn->query("SELECT `store_name` FROM `system` WHERE `system_id` = 1")->fetch_assoc()["store_name"];
$storeAddress = $conn->query("SELECT `store_address` FROM `system` WHERE `system_id` = 1")->fetch_assoc()["store_address"];
$storeTin = $conn->query("SELECT `tin_number` FROM `system` WHERE `system_id` = 1")->fetch_assoc()["tin_number"];
$contact = $conn->query("SELECT `contact` FROM `system` WHERE `system_id` = 1")->fetch_assoc()["contact"];
$Last_name = $conn->query("SELECT `last_name` FROM `user` WHERE `user_id` = '$user'")->fetch_assoc()["last_name"];
$first_name = $conn->query("SELECT `first_name` FROM `user` WHERE `user_id` = '$user'")->fetch_assoc()["first_name"];

//product items
$stock_sql = "SELECT 
    products.product_id,
    products.product_name,
    SUM(batch.unpacked_quantity + batch.quantity) AS total_stocks,
    products.stock_status,
    products.price,
    batch.archive_status,
    (SELECT unit_name FROM unit_of_measurement WHERE products.retail_unit = unit_id) AS retail_unit
    FROM batch
        INNER JOIN products ON batch.product_id = products.product_id
    WHERE products.archive_status = 0 AND batch.archive_status = 0
    GROUP BY products.product_id
    ORDER BY products.product_name ASC
    ";
$stock_res = $conn->query($stock_sql);


//repackable_batch
$repackable_sql = "SELECT 
products.product_id,
products.product_name,
batch.unpacked_quantity,
batch.quantity,
products.stock_status,
products.price,
products.repackable,
(SELECT unit_name FROM unit_of_measurement WHERE products.retail_unit = unit_id) AS retail_unit,
SUM(batch.quantity) AS total_batch,
batch.batch_id,
batch.expiration_status
FROM batch
INNER JOIN products ON batch.product_id = products.product_id
WHERE `batch`.`archive_status` = 0 AND products.repackable = 1 AND `products`.`archive_status` = 0 AND (`batch`.`quantity`) != 0 AND `batch`.`quantity` >= 1
GROUP BY batch.batch_id
ORDER BY batch.expiration_status DESC
";
$repackable_res = $conn->query($repackable_sql);

//Unpacked_batch
$unpacked_sql = "SELECT 
products.product_id,
products.product_name,
batch.cost,
batch.unpacked_quantity,
batch.expiration_date,
products.stock_status,
products.price,
products.repackable,
(SELECT unit_name FROM unit_of_measurement WHERE products.retail_unit = unit_id) AS retail_unit,
SUM(batch.unpacked_quantity) AS total_unpacked_batch,
batch.batch_id,
batch.expiration_status
FROM batch
INNER JOIN products ON batch.product_id = products.product_id
WHERE `batch`.`archive_status` = 0 AND `products`.`repackable` = 1 AND `products`.`archive_status` = 0 AND (`batch`.`unpacked_quantity`) != 0 AND `batch`.`unpacked_quantity` >= 1
GROUP BY batch.batch_id
ORDER BY batch.expiration_status DESC
";
$unpacked_res = $conn->query($unpacked_sql);

//Top sellng
$transact_sql = "SELECT
products.product_id,
products.product_name,
SUM(transaction_items.quantity) AS total_sold_qty,
transaction_items.unit
FROM transaction_items
INNER JOIN products ON transaction_items.product_id = products.product_id
INNER JOIN transactions ON transaction_items.transaction_id = transactions.transaction_id
WHERE 1
GROUP BY products.product_id
ORDER BY total_sold_qty DESC
limit 10
";
$transact_res = $conn->query($transact_sql);

//expire
$exp_sql = "SELECT
products.product_id,
products.product_name,
batch.cost,
batch.quantity,
batch.unpacked_quantity,
batch.expiration_date,
products.stock_status,
products.price,
products.repackable,
(SELECT unit_name FROM unit_of_measurement WHERE products.retail_unit = unit_id) AS retail_unit,
SUM(batch.unpacked_quantity + batch.quantity) AS total_stocks,
batch.batch_id,
batch.expiration_status
FROM batch
INNER JOIN
products ON batch.product_id = products.product_id
WHERE
`batch`.`archive_status` = 0
AND `products`.`archive_status` = 0
AND (`batch`.`unpacked_quantity` + `batch`.`quantity`) != 0
AND (batch.expiration_status = 1 OR batch.expiration_status = 2 OR batch.expiration_status = 3)
GROUP BY
batch.batch_id
ORDER BY
batch.expiration_status DESC;
";
$exp_res = $conn->query($exp_sql);


//loss
$loss_sql = "SELECT
`batch`.`batch_id`,
`batch_loss`.`id`,
`batch_loss`.`unpacked_loss`,
`batch_loss`.`quantity_loss`,
`batch`.`cost`,
`products`.`product_name`,
`batch_loss`.`remarks`,
`batch_loss`.`archived_date`,
`batch_loss`.`archive_by`,
SUM( `batch_loss`.`unpacked_loss` + `batch_loss`.`quantity_loss`) AS total_batch,
(SELECT unit_name FROM unit_of_measurement WHERE products.retail_unit = unit_id) AS retail_unit,
`batch_loss`.`status`,
`user`.`username` AS `archived_by`
FROM `batch_loss`
INNER JOIN `user` ON `batch_loss`.`archive_by` = `user`.`user_id`
INNER JOIN `products` ON `batch_loss`.`product_id` = `products`.`product_id`
INNER JOIN `batch` ON `batch_loss`.`batch_id` = `batch`.`batch_id`
WHERE `batch_loss`.`status` = 1
GROUP BY `batch_loss`.`id`
ORDER BY `products`.`product_name` ASC
";
$loss_res = $conn->query($loss_sql);


?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--Bootstrap-->
    <link rel="stylesheet" href="./bootstrap/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <script src="./bootstrap/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

    <!--Jquery-->
    <script src="./js/jquery_3.6.4_jquery.min.js"></script>

    <script src="./bootstrap//popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip();
        })
    </script>

    <!--Fontawesome-->
    <link rel="stylesheet" href="./fontawesome/css/all.min.css">

    <!--CSS-->
    <link rel="stylesheet" href="./css/styles.css">
    <link rel="stylesheet" href="./css/inventory_report.css">

    <link rel="icon" type="image/png" href="./assets/<?php echo $logo ?>" />
    <title>Inventory Report</title>

    <style>
        p {
            padding: 0;
            margin: 0;
        }

        @page {
            size: A4;
            margin: 10.16mm;
        }

        @media print {

            html,
            body {
                width: 210mm;
                height: 297mm;
            }

            .page {
                margin: 0;
                border: initial;
                border-radius: initial;
                width: initial;
                min-height: initial;
                box-shadow: initial;
                background: initial;
                page-break-after: always;
            }
        }

        .table th,
        .table td {
            font-size: 13.5px;
        }
    </style>

</head>

<body>


    <div style="width: 215.9mm; margin: auto">
        <div class="header mb-3">

        <div id="buttonDiv" style="margin: 30px auto; display: flex; justify-content: center">
        <a href="./report-inventoryreport.php"><button type="button" class="btn btn-secondary m-3">Back</button></a>
        <button type="button" class="btn btn-primary m-3" onclick="hideButtons()">Print</button>
    </div>

            <p class="text-center"><img src="./assets/<?= $logo ?>" class="img-fluid rounded-circle" style="max-width: 10%;"></p>
            <h2 class="text-center">Inventory Reports</h2>
            <br>
            <div class="row">
                <div class="col col-6">
                    <h5><?= $storeName ?></h5>
                    <p><?= $storeAddress ?></p>
                    <p><?= $contact ?></p>
                    <p>Prepared by:&emsp;<?= $Last_name . ', ' . $first_name ?></p>
                </div>
                <div class="col col-3"></div>
                <div class="col col-3">
                    <h6>Date:</h6>
                    <p>&emsp;<?= $date ?></p>
                    <p>&emsp;<?= $time ?></p>
                </div>
            </div>

        </div>
        <hr>



        <b>
            <p>Total stock value:
        </b> ₱
        <?= number_format($conn->query("
                  SELECT SUM(`value`) AS `stock_value`
                  FROM (
                      SELECT (
                          SELECT SUM(`batch`.`unpacked_quantity` + `batch`.`quantity` * `batch`.`price`)
                          FROM `batch`
                          WHERE `batch`.`product_id` = `products`.`product_id`  AND `batch`.`archive_status` = 0 AND `products`.`archive_status` = 0
                      ) AS `value`
                      FROM `products`
                      WHERE `archive_status` = 0
                      ORDER BY `product_name` ASC
                  ) AS `tbl`
              ")->fetch_assoc()["stock_value"], 2);
        ?>

        </p>
        <b>
            <p>Batches expired:
        </b>
        <?= $conn->query("
                    SELECT SUM(`batch`.`unpacked_quantity` + `batch`.`quantity`) AS `quantity` 
                    FROM `batch`
                        INNER JOIN `products` ON `batch`.`product_id` = `products`.`product_id`
                        WHERE `batch`.`archive_status` = 0 AND `products`.`archive_status` = 0 AND `batch`.`expiration_status` = 3 AND (`batch`.`unpacked_quantity` + `batch`.`quantity`) != 0
                    ")->fetch_assoc()["quantity"];
        ?> items

        <b><p>Total loss value: </b> ₱
        <?= number_format($conn->query("
             SELECT SUM(totalCost) AS totalCost FROM (
                SELECT ((bl.unpacked_loss + bl.quantity_loss) * p.cost) AS totalCost
                FROM batch_loss bl
                    INNER JOIN batch bt ON bl.batch_id = bt.batch_id
                    INNER JOIN products p ON bt.product_id = p.product_id
                
            ) AS tbl             
              ")->fetch_assoc()["totalCost"], 2);
              ?>
        </p>


        <hr>
        <div class="col">
            <b>Product Items</b>
        </div>

        <div class="container-fluid col">
            <div class="div_products row">
                <table class="table productTable" id="productTable">
                    <thead>
                        <th>#</th>
                        <th style="width: 30%;">PRODUCT NAME</th>
                        <th>STOCKS</th>
                        <th>(₱) UNIT PRICE</th>
                        <th>STOCK STATUS</th>
                    </thead>
                    <tbody>
                        <?php
                        $rowCount = 1;
                        while ($row = $stock_res->fetch_assoc()) {
                            $TOTAL = $row["price"] * $row["total_stocks"];
                            $stockStatus = $row["stock_status"];


                            if ($stockStatus == 1) {
                                $statusBadge = 'In Stock';
                            } elseif ($stockStatus == 2) {
                                $statusBadge = 'Critical';
                            } elseif ($stockStatus == 3) {
                                $statusBadge = 'Out of Stock';
                            }

                            echo "
          <tr>
            <td class='text-center'>$rowCount</td>
            <td>$row[product_name]</td>
            <td class='text-center'>$row[total_stocks] $row[retail_unit]</td>
            <td class='text-center'>" . number_format($row["price"], 2) . "</td>
            <td class='text-center'> $statusBadge</td>
          </tr>
          ";
                            $rowCount++;
                        }
                        ?>
                    </tbody>
                </table>
                <?php
                if ($stock_res->num_rows > 0) {
                } else {
                    echo '
                <div class="container-fluid">
                <p class="text-center mt-5">No Result</p>
                  </div>';
                }
                ?>
            </div>

            <div style="margin-top: 50px;"></div>
            <!--2nd table-->
            <section class="productTableSection mt-5" id="productTableSection">
                <strong>
                    <p>Repackable Batches</p>
                </strong>
            </section>
            <div class="div_stocks row">
                <table class="table productTable" id="productTable">
                    <thead>
                        <th>#</th>
                        <th>BATCH ID</th>
                        <th>PRODUCT NAME</th>
                        <th>STOCKS</th>
                        <th>(₱) UNIT PRICE</th>
                        <th>EXPIRY STATUS</th>
                    </thead>
                    <tbody>
                        <?php

                        $rowCounts = 1;
                        while ($rows = $repackable_res->fetch_assoc()) {
                            $expStatus = $rows["expiration_status"];
                            $stock_value = $rows["price"] * $rows["total_batch"];


                            if ($expStatus == 1) {
                                $expbadge = 'Good';
                            } elseif ($expStatus == 2) {
                                $expbadge = 'Nearly Expire';
                            } elseif ($expStatus == 3) {
                                $expbadge = 'Expire';
                            }

                            echo "
          <tr>
          <td class='text-center'>$rowCounts</td>
          <td class='text-center'>$rows[batch_id]</td>
          <td>$rows[product_name]</td>
          <td class='text-center'>$rows[quantity] $rows[retail_unit]</td>
          <td class='text-center'>" . number_format($rows["price"], 2) . "</td>
          <td class='text-center'>$expbadge</td>
      
          </tr>
          ";
                            $rowCounts++;
                        }
                        ?>
                    </tbody>
                </table>
                <?php
                if ($repackable_res->num_rows > 0) {
                } else {
                    echo '
                <div class="container-fluid">
                <p class="text-center mt-5">No Result</p>
                  </div>';
                }
                ?>
            </div>

            <!--3rd table-->
            <section class="productTableSection mt-5" id="productTableSection">
                <strong>
                    <p>Unpacked Batches</p>
                </strong>
            </section>
            <div class="div_stocks row">
                <table class="table productTable" id="productTable">
                    <thead>
                        <th>#</th>
                        <th>BATCH ID</th>
                        <th>PRODUCT NAME</th>
                        <th>STOCKS</th>
                        <th>EXPIRE DATE</th>
                        <th>EXPIRY STATUS</th>
                    </thead>
                    <tbody>
                        <?php
                        $unpacked_counts = 1;
                        while ($unpacked_rows = $unpacked_res->fetch_assoc()) {
                            $EXPstatus = $unpacked_rows["expiration_status"];
                            $date = date_create($unpacked_rows["expiration_date"]);
                            $date_format = date_format($date, "F d, Y");

                            
                            if ($EXPstatus == 1) {
                                $EXPbadge = 'Good';
                            } elseif ($EXPstatus == 2) {
                                $EXPbadge = 'Nearly Expire';
                            } elseif ($EXPstatus == 3) {
                                $EXPbadge = 'Expire';
                            }

                            echo"
                            <tr>
                            <td class='text-center'>$unpacked_counts</td>
                            <td class='text-center'>$unpacked_rows[batch_id]</td>
                            <td>$unpacked_rows[product_name]</td>
                            <td class='text-center'>$unpacked_rows[total_unpacked_batch] $unpacked_rows[retail_unit]</td>
                            <td class='text-center'>$date_format</td>
                            <td class='text-center'>$EXPbadge</td>
                            
                            </tr>
                            
                            ";
                            $unpacked_counts++;
                        }
                        ?>
                    </tbody>
                </table>
                <?php
                if ($unpacked_res->num_rows > 0) {
                } else {
                    echo '
                <div class="container-fluid">
                <p class="text-center mt-5">No Result</p>
                  </div>';
                }
                ?>
            </div>

            <div style="margin-top: 50px;"></div>
            <!--4th table-->
            <section class="productTableSection mt-5" id="productTableSection">
                <strong>
                    <p>Expire Batches</p>
                </strong>
            </section>
            <div class="div_stocks row">
                <table class="table productTable" id="productTable">
                    <thead>
                        <th>#</th>
                        <th>BATCH ID</th>
                        <th>PRODUCT NAME</th>
                        <th>STOCKS</th>
                        <th>EXPIRE DATE</th>
                        <th>EXPIRY STATUS</th>
                    </thead>
                    <tbody>
                    <?php
                        $exp_count = 1;

                        while ($exp_row = $exp_res->fetch_assoc()) {
                            $expstatus = $exp_row["expiration_status"];
                            $dates = date_create($exp_row["expiration_date"]);
                            $dates_format = date_format($dates, "F d, Y");

                            if ($expstatus == 1) {
                                $expbadge = 'Good';
                            } elseif ($expstatus == 2) {
                                $expbadge = 'Nearly Expire';
                            } elseif ($expstatus == 3) {
                                $expbadge = 'Expire';
                            }

                            echo "
                    <tr>
                        <td class='text-center'>$exp_count</td>
                        <td class='text-center'>$exp_row[batch_id]</td>
                        <td>$exp_row[product_name]</td>
                        <td class='text-center'>$exp_row[total_stocks] $exp_row[retail_unit]</td>
                        <td class='text-center'>$dates_format</td>
                        <td class='text-center'>$expbadge</td>
                    </tr>
                    ";
                            $exp_count++;
                        }
                        ?>
                    </tbody>
                </table>
                <?php
                if ($exp_res->num_rows > 0) {
                } else {
                    echo '
                <div class="container-fluid">
                <p class="text-center mt-5">No Result</p>
                  </div>';
                }
                ?>
            </div>

            <div style="margin-top: 50px;"></div>
            <!--5th table-->
            <section class="productTableSection mt-5" id="productTableSection">
                <strong>
                    <p>Batch Loss</p>
                </strong>
            </section>
            <div class="div_stocks row">
                <table class="table productTable" id="productTable">
                    <thead>
                        <th>#</th>
                        <th>ID</th>
                        <th>PRODUCT NAME</th>
                        <th>STOCKS</th>
                        <th>(₱) UNIT COST</th>
                        <th>(₱) TOTAL LOSS</th>
                        <th>ARCHIVE REMARKS</th>
                    </thead>
                    <tbody>
                        <?php
                        $countss = 1;
                        while ($loss_row = $loss_res->fetch_assoc()) {
                            $total_loss = $loss_row["total_batch"] * $loss_row["cost"];
                            echo "
                    <tr>
                        <td class='text-center'>$countss</td>
                        <td class='text-center'>$loss_row[batch_id]</td>
                        <td>$loss_row[product_name]</td>
                        <td class='text-center'>$loss_row[total_batch] $loss_row[retail_unit]</td>
                        <td class='text-center'>" . number_format($loss_row["cost"], 2) . "</td>
                        <td class='text-center'>" . number_format($total_loss, 2) . "</td>
                        <td class='text-center'>$loss_row[remarks]</td>
                    </tr>
                    
                    ";
                            $countss++;
                        }




                        ?>
                    </tbody>
                </table>
                <?php
                if ($loss_res->num_rows > 0) {
                } else {
                    echo '
                <div class="container-fluid">
                <p class="text-center mt-5">No Result</p>
                  </div>';
                }
                ?>
            </div>
        </div>
    </div>

    <script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>

    <script>
        function hideButtons() {
            $("#buttonDiv").css("display", "none");
            window.print();
            $("#buttonDiv").css("display", "flex");
        }
    </script>

</body>

</html>