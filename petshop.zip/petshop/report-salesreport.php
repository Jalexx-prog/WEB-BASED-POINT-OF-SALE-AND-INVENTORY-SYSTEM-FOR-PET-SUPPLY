<?php
session_start();
include('./includes/connection.php');
include ('./includes/log_check.php');
include ('./includes/checkRole.php');

$logo = $conn->query("SELECT `logo` FROM `system`")->fetch_assoc()["logo"];


date_default_timezone_set('Asia/Manila');

    //Para sa filtering ng date range-->
    $startDate = isset($_GET["start_date"]) ? $_GET["start_date"] : "";
    $endDate = isset($_GET["end_date"]) ? $_GET["end_date"] : "";
  
  
    //iseset condition ng sql if may nakaset na value sa date range
    $trCondition = "";
    if ($startDate !== "" && $endDate !== "") {
        $trCondition = "`date_created` BETWEEN '$startDate' AND '$endDate'";
    } else {
        $trCondition = "1";
    }
  

$limit = 10;
$search = isset($_GET["search"]) ? $_GET["search"] : '';
$page = isset($_GET["page"]) ? $_GET["page"] : '1';

//makes a hidden form for all GET methods
//needed for pagination so that the GET value stays after switching pages
$searchForm = isset($_GET["search"]) ?
  '<input type="hidden" name="search" value="' . $_GET["search"] . '">' :
  "";

$start_date= isset($_GET["start_date"]) ?
  '<input type="hidden" name="start_date" value="' . $_GET["start_date"] . '">' :
  "";
$end_date = isset($_GET["end_date"]) ?
  '<input type="hidden" name="end_date" value="' . $_GET["end_date"] . '">' :
  "";

//concatenate all GET forms
$forms = $searchForm . $start_date . $end_date;

$query = "SELECT transactions.*, user.first_name, user.last_name
FROM transactions
INNER JOIN user ON transactions.created_by = user.user_id
WHERE $trCondition
ORDER BY `date_created` DESC
";


$pageLocation = "./report-salesreport.php";
include("./includes/pagination.php");



$nigger = $conn->query("
    $query
    LIMIT $limit OFFSET $offset;
");


//for graph
$basis = isset($_POST["basis"]) ? $_POST["basis"] : "Daily";

$totalArray = "";
$dateArray = "";

if ($basis == "Daily") {
  $year = date("Y");
  $month = date("m");
  $maxDate = date("d");
  for ($x = 1; $x <= $maxDate; $x++) {
    $sql = "SELECT SUM(`total`) AS `total`, `date_created`
    FROM Transactions
    WHERE YEAR(`date_created`) = YEAR(CURDATE()) AND MONTH(`date_created`) = MONTH(CURDATE()) AND DAY(`date_created`) = $x";
    $result = $conn->query($sql);

    if (!$result) {
      die("Invalid query: " . $connection->connect_error);
    }

    $date = date("M d Y", strtotime("$year-$month-$x"));
    $total = 0;
    while ($row = $result->fetch_assoc()) {
      $total += $row["total"];
    }

    $totalArray .= $total;
    $dateArray .= "'" . $date . "'";

    if ($x <= date("d")) {
      $totalArray .= ", ";
      $dateArray .= ", ";
    }
  }

  $totalArray = "[$totalArray]";
  $dateArray = "[$dateArray]";
} elseif ($basis == "Weekly") {
  $year = date("Y");
  $month = date("m");
  $days = array(0, 7, 14, 21, 28);
  for ($x = 0; $x < 4; $x++) {
    $sql = "SELECT SUM(`total`) AS `total`, `date_created`
    FROM Transactions
    WHERE YEAR(`date_created`) = YEAR(CURDATE()) AND MONTH(`date_created`) = MONTH(CURDATE()) AND DAY(`date_created`) BETWEEN " . ($days[$x] + 1) . " AND " . $days[$x + 1];
    $result = $conn->query($sql);

    if (!$result) {
      die("Invalid query: " . $conn->connect_error);
    }

    $date = "Week " . $x + 1;
    $total = 0;
    while ($row = $result->fetch_assoc()) {
      $total += $row["total"];
    }

    $totalArray .= $total;
    $dateArray .= "'" . $date . "'";

    if ($x <= date("d")) {
      $totalArray .= ", ";
      $dateArray .= ", ";
    }
  }

  $totalArray = "[$totalArray]";
  $dateArray = "[$dateArray]";
} elseif ($basis == "Monthly") {
  $year = date("Y");
  $month = date("m");
  for ($x = 1; $x <= $month; $x++) {
    $sql = "SELECT SUM(`total`) AS `total`, `date_created`
    FROM  Transactions
    WHERE YEAR(`date_created`) = YEAR(CURDATE()) AND MONTH(`date_created`) = $x";
    $result = $conn->query($sql);

    if (!$result) {
      die("Invalid query: " . $conn->connect_error);
    }

    $date = date("M", strtotime("$year-$x"));
    $total = 0;
    while ($row = $result->fetch_assoc()) {
      $total += $row["total"];
    }

    $totalArray .= $total;
    $dateArray .= "'" . $date . "'";

    if ($x <= date("m")) {
      $totalArray .= ", ";
      $dateArray .= ", ";
    }
  }

  $totalArray = "[$totalArray]";
  $dateArray = "[$dateArray]";

} elseif ($basis == "Yearly") {
  $year = date("Y");
  for ($x = 2019; $x <= $year; $x++) {
    $sql = "SELECT SUM(`total`) AS `total`, `date_created`
    FROM  Transactions
    WHERE YEAR(`date_created`) = $x ";
    $result = $conn->query($sql);

    if (!$result) {
      die("Invalid query: " . $connection->connect_error);
    }

    $date = date("Y", strtotime("$x-1"));
    $total = 0;
    while ($row = $result->fetch_assoc()) {
      $total += $row["total"];
    }

    $totalArray .= $total;
    $dateArray .= "'" . $date . "'";

    if ($x <= date("Y")) {
      $totalArray .= ", ";
      $dateArray .= ", ";
    }
  }

  $totalArray = "[$totalArray]";
  $dateArray = "[$dateArray]";
}




?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


  <!--Bootstrap-->
  <link rel="stylesheet" href="./bootstrap/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
  <script src="./bootstrap/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

  <!--Jquery-->
  <script src="./js/jquery_3.6.4_jquery.min.js"></script>
  <script src="./js/chart.js"></script>

  <script src="./bootstrap//popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
  <!--<script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>-->

  <script>
    $(function() {
      $('[data-toggle="tooltip"]').tooltip();
    })
  </script>

  <!--Fontawesome-->
  <link rel="stylesheet" href="./fontawesome/css/all.min.css">

  <!--CSS-->
  <link rel="stylesheet" href="./css/styles.css">
  <link rel="stylesheet" href="./css/tr_history.css">

  <link rel="icon" type="image/png" href="./assets/<?php echo $logo?>" />
  <title>Sales Report</title>
</head>

<body>
  <?php

  include("./includes/navbar.php");
  ?>

  <div class="container-fluid main-div py-4" id="main-div">
    <h3 class="col ms-5">Sales Record</h3>

    <div class="row">
      <div class="container-fluid col-6 border rounded ms-5 mb-5 mr-3 ml-3">
        <!-- Graph div -->
        <div class="form-group row">
          <div class="col" style="width: 100%;">
            <label>Type: </label>
            <div class="input-group">
              <form method="POST">
                <select class="form-control" name="basis" id="basis" style="width: 100%;" onchange="this.form.submit()">
                  <option value="Daily" <?= $basis == "Daily" ? "selected" : "" ?>>Daily</option>
                  <option value="Weekly" <?= $basis == "Weekly" ? "selected" : "" ?>>Weekly</option>
                  <option value="Monthly" <?= $basis == "Monthly" ? "selected" : "" ?>>Monthly</option>
                  <option value="Yearly" <?= $basis == "Yearly" ? "selected" : "" ?>>Yearly</option>
                </select>
              </form>
            </div>
          </div>
        </div>

        <!-- Graph canva -->
        <div class="canvas-container mx-auto justify-content-center align-items-center" style="width: 100%; height: 400px;">
          <canvas id="salesChart" class="canvas-center"></canvas>
        </div>

      </div>

      <div class="col-5 border rounded ms-5 mb-5">
        <div class="container-fluid">
          <h3 class="mt-3">Type of Sale</h3>
            <div class="input-group" style="width: 20%;">
              <form action="" method="get">

                <select hidden="hidden" class="form-select" name="sale_type" id="Sale_type" onchange="this.form.submit()">
                  <option value="All">All</option>
                </select>
              </form>
            </div>

            <div class="canvas-container mx-auto justify-content-center align-items-center" style="width: 60%;">
              <canvas id="donut" class="canvas-center"></canvas>
              <?php
              $sale_type = isset($_GET["sale_type"]) ? $_GET["sale_type"] : "All";

              if ($sale_type == "All") {
                $tr_totalArray = "";
                $wholesale_retail = "['Retail', 'Wholesale']";

                for ($j = 0; $j <= 1; $j++) {
                  $SQL = "SELECT `quantity_type`, SUM(`subtotal`) as Cash
                          FROM `transaction_items`
                          WHERE `quantity_type` = '" . ($j == 0 ? 1 : 2) . "'
                          GROUP BY `quantity_type`";
                  $result = $conn->query($SQL);

                  if (!$result) {
                    die("Invalid query: " . $conn->connect_error);
                  }

                  $tr_total = 0;
                  while ($row = $result->fetch_assoc()) {
                    $tr_total += $row["Cash"];
                  }

                  $tr_totalArray .= $tr_total;

                  if ($j <= 0) {
                    $tr_totalArray .= ", ";
                  }
                }

                $tr_totalArray = "[$tr_totalArray]";
              }
              ?>

            </div>
        </div>
        <?php
        $fetchProfitQuery = "SELECT SUM(cost) as totalCost, 
        SUM(subtotal) as totalPrice, quantity_type 
        FROM transaction_items GROUP BY quantity_type";
        $profitResult = $conn->query($fetchProfitQuery);

        $totalRetailProfit = 0;
        $totalWholesaleProfit = 0;

        while ($rowProfit = $profitResult->fetch_assoc()) {
          // Calculate profit for each quantity_type
          $quantityType = $rowProfit['quantity_type'];
          $totalCost = $rowProfit['totalCost'];
          $totalPrice = $rowProfit['totalPrice'];

          $profit = $totalPrice - $totalCost;
          $overallProfit = $totalRetailProfit + $totalWholesaleProfit;

          // Accumulate total profit based on quantity_type
          if ($quantityType == 1) {
            // Retail
            $totalRetailProfit += $profit;
          } elseif ($quantityType == 2) {
            // Wholesale
            $totalWholesaleProfit += $profit;
          }
        }
        ?>

        <!-- Display overall total profit in your HTML -->
        <div class="col my-4">
          <h5>Overall Total Profit: ₱<?= number_format($totalRetailProfit + $totalWholesaleProfit, 2) ?></h5>
        </div>

        <!-- Display total retail profit in your HTML -->
        <div class="col my-4">
          <h5>Total Retail Profit: ₱<?= number_format($totalRetailProfit, 2) ?></h5>
        </div>

        <!-- Display total wholesale profit in your HTML -->
        <div class="col my-4">
          <h5>Total Wholesale Profit: ₱<?= number_format($totalWholesaleProfit, 2) ?></h5>
        </div>

      </div>
    </div>


    <!-- bottom left div transaction history-->
    <div class="col-12 border rounded ms-3 ms-md-5">
    <h3 class="mt-3">List of Transactions</h3>
      <!-- date range -->
      <form id="filterForm" action="./report-salesreport.php" class="row" method="GET">
      <?= isset($_GET["start_date"]) ? '
                          <input type="hidden" name="start_date" value="' . $startDate . '">
                        ' : ''
                    ?>
                    <?= isset($_GET["end_date"]) ? '
                          <input type="hidden" name="end_date" value="' . $endDate . '">
                        ' : ''
                    ?>
        <div class="col-md-4 my-4" style="width: 100%;">
          <div class="input-group mb-3">
            <div class="input-group-prepend">
              <span class="input-group-text">START DATE</span>
            </div>
            <input type="date" class="form-control" id="start_date" name="start_date" value="<?= $startDate ?>" required>
          </div>
        </div>
        <div class="col-md-4 my-4" style="width: 100%;">
          <div class="input-group mb-3">
            <div class="input-group-prepend">
              <span class="input-group-text">END DATE</span>
            </div>
            <input class="form-control" type="date" id="end_date" name="end_date" value="<?= $endDate ?>" required>
          </div>
        </div>
        <div class="col-md-3 my-4">
          <div class="input-group">
            <button class="btn btn-primary" id="filterButton">Filter</button>
            </form>
            <div class="col">
            <button class="btn btn-danger" id="clearButton">Clear</button>
            </div>
          </div>
        </div>

      <div class="table-responsive">
        <table class="table productTable" id="productTable1">
          <thead>
            <th>TRANSACTION ID</th>
            <th>(₱) TOTAL AMOUNT</th>
            <th>(₱) AMOUNT TENDERED</th>
            <th>(₱) CHANGE</th>
            <th>(₱) VAT SALES</th>
            <th>(₱) VAT AMOUNT</th>
            <th>DISCOUNT</th>
            <th>DATE</th>
            <th>CASHIER</th>
            <th></th>
          </thead>
          <tbody>
            <?php

            if (!$nigger) {
              die("Invalid query: " . $conn->connect_error);
            }

            while ($row = $nigger->fetch_assoc()) {
              $first_name = $row['first_name'];
              $last_name = $row['last_name'];
              $full_name = $first_name . ' ' . $last_name;
              $id = $row['transaction_id'];
              $SQL = "
              SELECT 
                transaction_items.*, 
                products.product_name,
                (SELECT unit_name FROM unit_of_measurement WHERE products.retail_unit = unit_id) AS retail_unit,
                (SELECT unit_name FROM unit_of_measurement WHERE products.wholesale_unit = unit_id) AS wholesale_unit
              FROM transaction_items
                INNER JOIN products ON transaction_items.product_id = products.product_id
              WHERE transaction_items.transaction_id = '$id'
            ";
              $itemresult = $conn->query($SQL);

              if (!$itemresult) {
                die("Invalid query: " . $conn->connect_error);
              }

              $dt = date_create($row["date_created"]);
              $date = date_format($dt, "m/d/Y h:i a");

              $modals = "";
              $modalItems = "";
              if ($itemresult->num_rows > 0) {
                $rowCount = 1;
                while ($row1 = $itemresult->fetch_assoc()) {
                  $transactionId = $row1["transaction_id"];


                  $unit = $row1["quantity_type"] == 1 ? $row1["retail_unit"] : $row1["wholesale_unit"];
                  $qtyType = $row1["quantity_type"] == 1 ? "Retail" : "Wholesale";
                  $promo = $row1["promo_freebie"];
                  


                  $modalItems .= "
            <tr>
            <td>$rowCount</td>
            <td>BRK-$row1[transaction_id]</td>
            <td>$row1[product_name]</td>
            <td>" . $row1["quantity"] . " $unit</td>
            <td> " . number_format($row1['price'], 2) . "</td>
            <td> " . number_format($row1['subtotal'], 2) . "</td>
            <td>$qtyType</td>
            <td>$promo</td>
            </tr>                    
            ";
                  $rowCount++;
                }
              }

              echo
              "
            
                    <tr>
                        <td>BRK-$row[transaction_id]</td>
                        <td> " . number_format($row['total'], 2) . "</td>
                        <td> " . number_format($row['amount_tendered'], 2) . "</td>
                        <td> " . number_format($row['change_amount'], 2) . "</td>
                        <td> " . number_format($row['vatable_sales'], 2) . "</td>
                        <td> " . number_format($row['vat_amount'], 2) . "</td>
                        <td>$row[discount]%</td>
                        <td>$date</td>
                        <td>$full_name</td>
                        <td>
                        <button type='button' 
                        data-toggle='modal' 
                        data-target='#myModal'
                        id='t-items-$id'
                        class='btn btn-warning viewdetail'>
                        <i class='fa-solid fa-circle-info' 
                        style='font-size: 17px;'></i> </button>
                        </td>
                    </tr>
                    
                    ";

              echo '
                    <script>
                    $("#t-items-' . $id . '").click(function(){
                      $("#table-items").html(`
                        ' . $modalItems . '
                      `);
                      $("#receiptPrintBtn").attr("href", "./printReciept.php?transaction='.$id.'&rep=1");
                    });
                    </script>
                    ';
            }
            ?>
          </tbody>
        </table>
      </div>
      <?= $pageCount > 1 ? '<p>Page ' . $page . ' out of ' . $pageCount . ' pages</p>' : '' ?>

    </div>

    <?= $pagination ?>

  </div>

  <!-- Modal -->
  <div class="modal fade" id="myModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">List of Items</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <table class="table" style="width:100%;">
            <thead>
              <tr>
                <th>#</th>
                <th>TRANSACTION ID</th>
                <th>PRODUCT NAME</th>
                <th>QUANTITY</th>
                <th>(₱) PRICE</th>
                <th>(₱) TOTAL</th>
                <th>SALE TYPE</th>
                <th>PROMO</th>
              </tr>
            </thead>
            <tbody id="table-items">

            </tbody>
          </table>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <a id="receiptPrintBtn" href="" class="btn btn-primary">Print</a>

        </div>
      </div>
    </div>
  </div>


  <script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
  <script>
    const ctx = document.getElementById('salesChart');

    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: <?= $dateArray ?>,
        datasets: [{
          label: 'Sales total',
          data: <?= $totalArray ?>,
          borderWidth: 1,
          backgroundColor: 'blue',
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
          }
        },
        maintainAspectRatio: false,
        responsive: true,
      }
    });
  </script>
  <script>
    const trip = document.getElementById('donut');

    new Chart(trip, {
      type: 'doughnut',
      data: {
        labels: <?= $wholesale_retail ?>,
        datasets: [{
          label: 'Total Sale',
          data: <?= $tr_totalArray ?>,
          borderWidth: 1,
          backgroundColor: ['blue', 'orange'],
        }]
      },
      options: {
        scales: {
          y: {
            display: false,
          }
        },
        
        maintainAspectRatio: false,
        responsive: true,
      }
    });
  </script>



  <script>
    $(document).ready(function() {
      $(".viewdetail").tooltip({
        title: "View Details",
        trigger: "hover",
        placement: "top"
      });
    });


  
  //clear date range
  $(document).ready(function() {
    $("#clearButton").click(function() {
      // Reset the date inputs to empty values
      $("#start_date").val('');
      $("#end_date").val('');

      // Submit the form to clear the results
      $("#filterForm").submit();
    });
  });
</script>





</body>

</html>