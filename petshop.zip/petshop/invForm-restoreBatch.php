<?php
try{
session_start();
include("./includes/connection.php");
include('./includes/log_check.php');
include ('./includes/checkRole.php');
    
date_default_timezone_set('Asia/Manila');


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $status = ($_POST["archive_status"] == 1) ? 0 : 1;
    $id = $_POST["batch_id"];
    
    $sql = "UPDATE `batch` SET archive_status = '$status' WHERE batch_id = '$id'";
    $Result = $conn->query($sql);
  
    if (!$Result) {
        die("batch result update failed: " . $conn->error);
    }
  }


    $_SESSION["message"] = "batch-restored";
    header("location: ./inv-productArchive.php");
    exit();

} catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    echo $e;
    header("location: ./inv-productArchive.php");
    exit();
}
?>