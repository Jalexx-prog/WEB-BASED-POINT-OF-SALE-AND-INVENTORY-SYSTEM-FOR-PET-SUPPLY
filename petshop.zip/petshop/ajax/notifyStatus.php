<?php
    include("../includes/connection.php");
    include("../includes/updateExpirationStatus.php");
    include("../includes/updateProductStatus.php");

    $notifList = "";
    $notifCount = 0;

    $result = $conn->query("
        SELECT * 
        FROM `products` 
        WHERE `archive_status` = 0 AND `stock_status` > 1
        ORDER BY `stock_status` DESC
    ");

    $notifCount += $result->num_rows;

    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            $status = $row["stock_status"] == 2 ? "Low stocks" : "out of stock";
            $img_status = $row["stock_status"] == 2 ? "<img src='./assets/low-stocks.png'>" : "<img src='./assets/out_of_stocks.png'>";

            $notifList .= '
                <a class="dropdown-item" href="./inv-productList.php?search='.$row["barcode"].'">
                    <p style="font-size: large;">'.$img_status.' '.$row["product_name"].' is <b>'.$status.' </b></p>
                </a>
            ';
        }
    }

    $result = $conn->query("
        SELECT `batch`.*, `products`.`barcode`, `products`.`product_name`
        FROM `batch`
            INNER JOIN `products` ON `batch`.`product_id` = `products`.`product_id`
        WHERE `batch`.`archive_status` = 0 AND `products`.`archive_status` = 0 AND `batch`.`expiration_status` > 1 AND (`batch`.`unpacked_quantity` + `batch`.`quantity`) != 0
        ORDER BY `batch`.`expiration_status` DESC
    ");

    $notifCount += $result->num_rows;

    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            $status = $row["expiration_status"] == 2 ? "Nearly Expired" : "Expired";
            $img = $row["expiration_status"] == 2 ? "<img src='./assets/expire_soon.png'>" : "<img src='./assets/expired.png'>";

            $notifList .= '
                <a class="dropdown-item" href="./inv-productList.php?search='.$row["barcode"].'">
                <p style="font-size: large;">'.$img.'
                 Batch <b>'.$row["batch_id"].'</b> of '.$row["product_name"].' is <b>'.$status.'</b></p>
                </a>
            ';
        }
    }

    $notifList .= '
        <script>
            $("#notifCount").html("'.$notifCount.'");
        </script>
    ';
    echo $notifList
?>