<?php
session_start();
date_default_timezone_set('Asia/Manila');

    include("../includes/connection.php");


    $type = $_POST["type"];

    if($type === "username-check"){
        $user = $_POST["username"];
        $usernameExist = $conn->query("SELECT * FROM user WHERE username = '$user'");
        if($usernameExist->num_rows > 0){
            $qId1 = $conn->query("SELECT security_question1 FROM user WHERE username = '$user'")->fetch_assoc()["security_question1"];
            $question1 = $conn->query("SELECT * FROM security_question WHERE id = $qId1")->fetch_assoc()["questions"];
            
            $qId2 = $conn->query("SELECT security_question2 FROM user WHERE username = '$user'")->fetch_assoc()["security_question2"];
            $question2 = $conn->query("SELECT * FROM security_question WHERE id = $qId2")->fetch_assoc()["questions"];





            $loginAttempt = $conn->query("SELECT login_attempt FROM user WHERE username = '$user'")->fetch_assoc()["login_attempt"];

            if($loginAttempt >= 3){
                $nextAttempt = date("Y-m-d H:i:s", strtotime($conn->query("SELECT next_attempt FROM user WHERE username = '$user'")->fetch_assoc()["next_attempt"]));

                if($nextAttempt <= date("Y-m-d H:i:s")){
                    $conn->query("UPDATE user SET login_attempt = 0, next_attempt = NULL WHERE username = '$user'");
                    $loginAttempt = 0;
                }
            }





            echo '
            <script>
                clearInterval(window.timeInterval);
                '.(
                    $loginAttempt >= 3 ? '
                    disableAttempt("'.$user.'", "'.$nextAttempt.'");
                    ' : '
                    enableAttempt("'.$user.'");
                    '
                ).'
                
                $("#fpass-question1").html("'.$question1.'");
                $("#fpass-question2").html("'.$question2.'");
                $("#fpass-answer1").html("");
                $("#fpass-answer2").html("");

                $("#fpass-username-error").html("");
                $("#fpass-usernameCheckModal").modal("hide");
                $("#fpass-securityQuestionModal").modal("show");
            
            </script>
            ';



        }
        else{
            echo '
                <script>
                    $("#fpass-username-error").html("No username found");
                </script>
            ';
        }
    }
    elseif($type === "answer-check"){


        
        
        $user = $_POST["username"];
        $a1 = $_POST["answer1"];
        $a2 = $_POST["answer2"];

        $answer1 = $conn->query("SELECT answer_1 FROM user WHERE username = '$user'")->fetch_assoc()["answer_1"];
        $answer2 = $conn->query("SELECT answer_2 FROM user WHERE username = '$user'")->fetch_assoc()["answer_2"];



        $a1Correct = false;
        $a2Correct = false;

        
        //run if attempt is not 3

        //check if answer 1 is correct
        if($a1 === $answer1){
            $a1Correct = true;
        }
        else{
            $a1Correct = false;

        }

        //check if answer 2 is correct
        if($a2 === $answer2){
            $a2Correct = true;
        }
        else{
            $a2Correct = false;

        }

        if($a1Correct == true and $a2Correct == true){
            echo '
                <script>
                    $("#fpass-answer1-error").html("");
                    $("#fpass-answer2-error").html("");
                    $("#fpass-securityQuestionModal").modal("hide");
                    $("#fpass-changePasswordModal").modal("show");
                </script>
            ';
        }
        else{
            
            echo '
                <script>
                    $("#fpass-answer-error").html("Incorrect Answer");
                </script>
            ';
            $loginAttempt = $conn->query("SELECT login_attempt FROM user WHERE username = '$user'")->fetch_assoc()["login_attempt"];

            if($loginAttempt >= 3){
                $conn->query("UPDATE user SET next_attempt = '".date("Y-m-d H:i:s", strtotime("+60 minutes"))."' WHERE username = '$user'");

                $nextAttempt = date("Y-m-d H:i:s", strtotime($conn->query("SELECT next_attempt FROM user WHERE username = '$user'")->fetch_assoc()["next_attempt"]));

                echo '
                    <script>
                        disableAttempt("'.$user.'", "'.$nextAttempt.'");
                    </script>
                ';
                
            }
            else{
                $conn->query("UPDATE user SET login_attempt = login_attempt + 1 WHERE username = '$user'");
            }
        }
        


    }
    elseif($type === "update-password"){
        $user = $_POST["username"];
        $newpass = $_POST["new_password"];
        $cpass = $_POST["confirm_password"];

        if($newpass === $cpass){

            $hashedPass = password_hash($newpass, PASSWORD_DEFAULT);
            $conn->query("
                UPDATE user
                SET password = '$hashedPass'
                WHERE username = '$user'
            ");
            echo '
                <script>
                    $("#fpass-cpass-error").html("");
                    $("#fpass-changePasswordModal").modal("hide");
                    $("#fpass-successMessageModal").modal("show");
                </script>
            ';
        }
        else{
            echo '
                <script>
                    $("#fpass-cpass-error").html("Password does not match");
                </script>
            ';
            
        }
    }
    elseif($type === "enableAttempt"){
        $username = $_POST["username"];
        $conn->query("UPDATE user SET login_attempt = 0, next_attempt = NULL WHERE username = '$username'");
    }
    
?>