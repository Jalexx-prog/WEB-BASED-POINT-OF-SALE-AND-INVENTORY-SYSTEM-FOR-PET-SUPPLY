<?php
    session_start();
    include("../includes/connection.php");


    $search = $_POST["search"];

    $result = $conn->query("
        SELECT 
            `products`.`product_id`, 
            `products`.`barcode`, 
            `products`.`product_name`, 
            `products`.`category_id`, 
            `category`.`category_name`,
            `products`.`repackable`,
            IFNULL(
                (SELECT SUM(`batch`.`quantity`) FROM `batch` WHERE `batch`.`product_id` = `products`.`product_id` AND `batch`.`archive_status` = 0), 
                0
            ) AS `stocks`,
            IFNULL(
                (SELECT SUM(`batch`.`unpacked_quantity`) FROM `batch` WHERE `batch`.`product_id` = `products`.`product_id` AND `batch`.`archive_status` = 0), 
                0
            ) AS `unpacked_stocks`,
            `products`.`retail_unit` AS `retail_unit_id`,
            `products`.`wholesale_unit` AS `wholesale_unit_id`,
            IFNULL((SELECT `unit_of_measurement`.`unit_name` FROM `unit_of_measurement` WHERE `unit_of_measurement`.`unit_id` = `products`.`retail_unit`), '') AS `retail_unit`,
            IFNULL((SELECT `unit_of_measurement`.`unit_name` FROM `unit_of_measurement` WHERE `unit_of_measurement`.`unit_id` = `products`.`wholesale_unit`), '') AS `wholesale_unit`,
            `products`.`cost`, 
            `products`.`price`, 
            `products`.`description`, 
            `products`.`warning_level`, 
            `products`.`wholesale_level`, 
            `products`.`stock_status`, 
            `products`.`date_created`, 
            `user`.`username` AS `created_by`,
            (SELECT COUNT(*) FROM `batch` WHERE `batch`.`product_id` = `products`.`product_id` AND `batch`.`archive_status` = 0 AND (`batch`.`unpacked_quantity` + `quantity`) != 0) AS `batch_count`,
            (SELECT MAX(`expiration_status`) FROM `batch` WHERE `batch`.`product_id` = `products`.`product_id` AND `batch`.`archive_status` = 0 AND (`batch`.`unpacked_quantity` + `quantity`) != 0) AS `expiration_status`,
            `products`.`archive_status`
        FROM `products` 
            INNER JOIN `category` ON `products`.`category_id` = `category`.`category_id`
            INNER JOIN `user` ON `products`.`created_by` = `user`.`user_id`
        WHERE `products`.`archive_status` = 0  AND `barcode` = '$search' OR `product_name` LIKE '%$search%'
    ");


    $promo = $conn->query("
        SELECT * FROM `promo` WHERE `promo_status` = 1
    ");
    
    $promoOptions = "";
    while($row = $promo->fetch_assoc()){
        $promoId = $row["promo_id"];
        $promoName = $row["promo_name"];
        $buy = $row["promo_buy"] !== "0" ? $row["promo_buy"]."," : "";
        $get = $row["promo_get"] !== "0" ? $row["promo_get"] : "";
        $discount = $row["promo_discount"] !== "0" ? $row["promo_discount"] : "";

        $promoOptions .= '
            <option value="'.$buy.$get.$discount.'">'.$promoName.'</option>
        ';
    }


    $promoProducts = $conn->query("
        SELECT prm.*, prd.product_name, btc.expiration_status
        FROM `promo_product` `prm`
            INNER JOIN products prd ON prm.product_id = prd.product_id
            INNER JOIN batch btc ON prm.batch_id = btc.batch_id
        WHERE prm.`archive_status` = 0 AND `quantity_promo` > 0 AND btc.expiration_status != 3
    ");
    
    $promoProductOptions = "";
    while($row = $promoProducts->fetch_assoc()){
        $promoProductOptions .= '
            <option value="'.$row["prd_promo_id"].'">'.$row["product_name"].'</option>
        ';
    }


    $list = "";
    $script = "";

    $id = 0;
    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            $id = $row["product_id"];
            $barcode = $row["barcode"];
            $productName = wordwrap($row["product_name"],30,"<br>\n");
            $categoryId = $row["category_id"];
            $category = $row["category_name"];
            $wholesaleLevel = $row["wholesale_level"];
            $stocks = $row["stocks"];
            $unpackedStocks = $row["unpacked_stocks"];
            $retailUnitId = $row["retail_unit_id"];
            $wholesaleUnitId = $row["wholesale_unit_id"];
            $retailUnit = $row["retail_unit"];
            $wholesaleUnit = $row["wholesale_unit"];
            $cost = $row["cost"];
            $wholesaleCost = (int)($row["cost"] * $wholesaleLevel);
            $price = $row["price"];
            $wholesalePrice = (int)(($row["price"] * $wholesaleLevel) - (5/100 * ($row["price"] * $wholesaleLevel)));
            $warningLevel = $row["warning_level"];
            
            $description = $row["description"];
            $stockStatus = $row["stock_status"];
            $expirationStatus = $row["expiration_status"];
            $dateCreated = date("M d, Y", strtotime($row["date_created"]));
            $timeCreated = date("h:i a", strtotime($row["date_created"]));
            $createdBy = $row["created_by"];
            $statusBadge = "";
            $onclickMessage = "";
            if($stockStatus == 3){
                $statusBadge = '<a href="#" class="badge badge-dark">Out of Stock</a>';
            }elseif($expirationStatus == 3){
                $statusBadge = '<a href="#" class="badge badge-danger">Expired</a>';
                $onclickMessage = '
                    $("body").prepend(`
                        <div 
                            id="alert-box"
                            class="alert alert-danger alert-dismissible fade show shadow-lg" role="alert" 
                            style="
                                position: fixed;
                                z-index: 1000;
                                width: 500px;
                                top: 30%;
                                left: 50%;
                                margin-top: -100px; /* Negative half of height. */
                                margin-left: -250px; /* Negative half of width. */
                                text-align: center;
                                animation: transitionIn-Y-over 2s;
                            ">
                            The product you are adding has an expired batch
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        `)
                        $("#alert-box").fadeTo(2000, 500).slideUp(500, function(){
                            $("#alert-box").slideUp(2000);
                        });
                ';
            }elseif($expirationStatus == 2){
                $statusBadge = '<a href="#" class="badge badge-warning">Nearly Expired</a>';
                $onclickMessage = '
                    $("body").prepend(`
                        <div 
                            id="alert-box"
                            class="alert alert-warning alert-dismissible fade show shadow-lg" role="alert" 
                            style="
                                position: fixed;
                                z-index: 1000;
                                width: 500px;
                                top: 30%;
                                left: 50%;
                                margin-top: -100px; /* Negative half of height. */
                                margin-left: -250px; /* Negative half of width. */
                                text-align: center;
                                animation: transitionIn-Y-over 2s;
                            ">
                            The product you are adding has an nearly expired batch
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        `)
                        $("#alert-box").fadeTo(2000, 500).slideUp(500, function(){
                            $("#alert-box").slideUp(2000);
                        });
                        
                ';
            }

            $repackable = $row["repackable"];
            $repackableBadge = "";
            $noRepack = false;
            if($repackable == 1 and $unpackedStocks >= $wholesaleLevel){
                $repackableBadge = '<span class="badge badge-info repack-badge">● Repack</span>';
                $noRepack = false;
            }
            elseif($repackable == 1 and $unpackedStocks < $wholesaleLevel and $stocks == 0){
                $repackableBadge = '<span class="badge badge-dark repack-badge">● No Repack</span>'; 
                $noRepack = true;
            }



            $maxWholesalePack = (int)($conn->query("
                SELECT SUM(`unpacked_quantity`) AS `count`
                FROM `batch` 
                INNER JOIN `products` ON `batch`.`product_id` = `products`.`product_id`
                WHERE `batch`.`unpacked_quantity` >= `products`.`wholesale_level` AND `batch`.`product_id` = '$id' AND `batch`.`archive_status` = 0
            ")->fetch_assoc()["count"] / $wholesaleLevel);
            $maxWholesaleNoPack = $wholesaleUnitId !== "0" ? (int)($row["stocks"] / $wholesaleLevel) : 0;
            $maxWholesale = $repackable === "1" ? $maxWholesalePack : $maxWholesaleNoPack;


            $disabledWholesale = ($wholesaleLevel === "1" or $maxWholesale == 0) ? "disabled" : "";


            $list .= '
                <input type="hidden" class="listBarcode" id="listBarcode-'.$id.'" value="'.$barcode.'">

                <button type="button" class="listProductItem list-group-item list-group-item-action" id="listProductItem-'.$id.'" '.( ($stockStatus == 3 or $noRepack) ? "disabled" : "").'>
                    <div class="row">
                        <div class="col">
                            <small class="text-muted">'.$barcode.'</small>
                        </div>
                        <div class="col">
                            '.$productName.'
                        </div>
                        <div class="col">
                            <small class="text-muted">₱ '.number_format($price, 2).'</small>
                        </div>
                        <div class="col">
                            '.$repackableBadge.' '.$statusBadge.'
                        </div>
                    </div>
                </button>

            ';

            $script .= '
                $("#listProductItem-'.$id.'").click(function(){
                    '.$onclickMessage.'
                    if($("#selectedItemRow-'.$id.'").length == 0 && "'.$stockStatus.'" !== "3"){
                        $("#productSearch").val("");
                        posProductSearchAjax("");
                        $("#selectedTable").append(`
                            <tr class="selectedItemRow" id="selectedItemRow-'.$id.'">
                                <input type="hidden" class="productId" id="productId-'.$id.'" name="productId[]" value="'.$id.'">
                                <input type="hidden" class="selectedInput" id="productName-'.$id.'" name="productName[]" value="'.$productName.'">

                                <input type="hidden" class="selectedInput" id="retailCost-'.$id.'" name="retailCost[]" value="'.$cost.'">
                                <input type="hidden" class="selectedInput" id="wholesaleCost-'.$id.'" name="wholesaleCost[]" value="'.$wholesaleCost.'">
                                <input type="hidden" class="selectedInput" id="cost-'.$id.'" name="cost[]" value="'.$cost.'">

                                <input type="hidden" class="selectedInput" id="retailPrice-'.$id.'" name="retailPrice[]" value="'.$price.'">
                                <input type="hidden" class="selectedInput" id="wholesalePrice-'.$id.'" name="wholesalePrice[]" value="'.$wholesalePrice.'">
                                <input type="hidden" class="selectedInput" id="price-'.$id.'" name="price[]" value="'.$price.'">
                                <input type="hidden" class="subtotal selectedInput" id="subtotal-'.$id.'" name="subtotal[]" value="'.$price.'">

                                <input type="hidden" class="selectedInput" id="retailUnit-'.$id.'" name="retailUnit[]" value="'.$retailUnit.'">
                                <input type="hidden" class="selectedInput" id="wholesaleUnit-'.$id.'" name="wholesaleUnit[]" value="'.$wholesaleUnit.'">

                                <input type="hidden" class="selectedInput" id="wholesaleLevel-'.$id.'" name="wholesaleLevel[]" value="'.$wholesaleLevel.'">
                                <input type="hidden" class="selectedInput" id="maxRetail-'.$id.'" name="maxRetail[]" value="'.$stocks.'">
                                <input type="hidden" class="selectedInput" id="maxWholesale-'.$id.'" name="maxWholesale[]" value="'.$maxWholesale.'">
                                
                                <input type="hidden" class="selectedInput" id="promoBuy-'.$id.'" name="promoBuy[]" value="0">
                                <input type="hidden" class="selectedInput" id="promoGet-'.$id.'" name="promoGet[]" value="0">
                                <input type="hidden" class="selectedInput" id="promoDiscount-'.$id.'" name="promoDiscount[]" value="0">

                                <input type="hidden" class="selectedInput" id="repackable-'.$id.'" name="repackable[]" value="'.$repackable.'">

                                <td id="productNameText-'.$id.'">
                                    '.$productName.'
                                </td>

                                <td><center>
                                    <div class="input-group w-50">
                                    <input type="number" class="form-control" id="quantity-'.$id.'" name="quantity[]" min="1" max="'.(($stocks == 0 and $repackable == 1) ? intdiv($unpackedStocks, $wholesaleLevel) : $stocks).'" value="1" oninput="onchangeQuantity(\''.$id.'\');" required>
                                        <div class="input-group-append">
                                            <select class="border rounded" id="quantityType-'.$id.'" name="quantityType[]" style="width: 70px; font-size: 12px" onchange="onchangeQuantityType(\''.$id.'\')">
                                                <option value="1" '.(($stocks == 0 and $repackable == 1) ? 'disabled' : '').'>'.$retailUnit.'</option>
                                                <option value="2" '.(($stocks == 0 and $repackable == 1) ? 'selected' : '').' '.$disabledWholesale.'>'.$wholesaleUnit.'</option>
                                            </select>
                                        </div>
                                    </div>
                                </center></td>

                                <td class="text-center" id="priceText-'.$id.'">
                                    ₱ '.number_format($price, 2).'
                                </td>

                                <td class="text-center" id="subtotalText-'.$id.'">
                                    ₱ '.number_format($price, 2).'
                                </td>

                                <td class="text-center">
                                    <select class="form-control" id="promo-'.$id.'" name="promo[]" onchange="onchangePromo(\''.$id.'\', \''.$price.'\', \''.$wholesalePrice.'\')">
                                        <option value="None">None</option>
                                        '.$promoOptions.'
                                    </select>
                                </td>
                                <td class="text-center promo-col">
                                    <select class="form-control" id="productPromo-'.$id.'" name="productPromo[]">
                                        '.$promoProductOptions.'
                                    </select>
                                </td>
                                <td class="text-center">
                                    <button type="button" class="removeButton btn btn-white text-danger" onclick="removeRow(\''.$id.'\');submitToggle();"><i class="fa-solid fa-xmark"></i></button>
                                </td>
                            </tr>
                        `);
                    }
                    else if($("#selectedItemRow-'.$id.'").length > 0 && "'.$stockStatus.'" !== "3"){
                        $("#productSearch").val("");
                        posProductSearchAjax("");
                        $("#quantity-'.$id.'").val(parseInt($("#quantity-'.$id.'").val()) + 1);
                        onchangeQuantity(\''.$id.'\');
                    }
                    submitToggle();
                    updateTotal();
                });



                
            ';

        }
    }
    else{
        $list .= '
            <p class="text-center m-5">No Result</p>
        ';
    }

    echo '
        <div class="list-group">
            '.$list.'
        </div>
        <script>
            '.$script.'
        </script>
        <script>
$(document).ready(function() {
    $("#promo-"'.$id.'").change(function() {
        var selectedValue = $(this).val();
        if (selectedValue === "'.$promoOptions.'") {

            $("#listProductItem-'.$id.'").find("tr").each(function() {
                $(this).append("<td>New column data</td>");
            });
        } else {
            $("#listProductItem-'.$id.'").find("tr").each(function() {
                $(this).find("td:last-child").remove();
            });
        }
    });
});
</script>
        
        
    ';

    
?>


