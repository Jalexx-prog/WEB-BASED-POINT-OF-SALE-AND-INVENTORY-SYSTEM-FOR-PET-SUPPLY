<?php
    include("../includes/connection.php");
    $username = $_POST["username"];
    echo $conn->query("UPDATE user SET login_attempt = 0, next_attempt = NULL WHERE username = '$username'");
?>