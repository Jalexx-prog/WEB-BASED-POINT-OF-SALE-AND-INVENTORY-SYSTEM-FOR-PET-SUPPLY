<?php
    include("../includes/connection.php");

    //product details
    $productId = $_POST["productId"];
    $barcode = $_POST["barcode"];
    $productName = $_POST["productName"];
    $retailUnit = $_POST["retailUnit"];
    $wholesaleUnit = $_POST["wholesaleUnit"];
    $repackable = $_POST["repackable"];
    $baseCost = $_POST["baseCost"];
    $basePrice = $_POST["basePrice"];


    //batch data
    $result = $conn->query("
        SELECT 
            `batch`.*,
            `user`.`username`
        FROM `batch`
            INNER JOIN `user` ON `batch`.`created_by` = `user`.`user_id` 
        WHERE `batch`.`product_id` = '$productId' AND `batch`.`archive_status` = 0 AND (`batch`.`unpacked_quantity` > 0 OR `batch`.`quantity` > 0)
        ORDER BY `expiration_status` DESC
    ");

    $tableRows = "";
    $actionScripts = "";
    if($result->num_rows > 0){
        $rowcount = 1;
        
        
        while($row = $result->fetch_assoc()){
            $id = $row["batch_id"];
            $unpackedQuantity = $row["unpacked_quantity"];
            $quantity = $row["quantity"];
            $cost = $row["cost"];
            $price = $row["price"];
            $expirationDate = $row["expiration_date"];
            $expirationStatus = $row["expiration_status"];
            $dateCreated = date("Y-m-d", strtotime($row["date_created"]));
            $timeCreated = date("H:i:s", strtotime($row["date_created"]));
            $createdBy = $row["username"];
            $statusBadge = "";
            if($expirationStatus == 0){
                $statusBadge = '<a href="#" class="badge badge-light">N/A</a>';
            }elseif($expirationStatus == 1){
                $statusBadge = '<a href="#" class="badge badge-success" data-toggle="tooltip" title="Good">'.$expirationDate.'</a>';
            }elseif($expirationStatus == 2){
                $statusBadge = '<a href="#" class="badge badge-warning" data-toggle="tooltip" title="Neary Expired">'.$expirationDate.'</a>';
            }elseif($expirationStatus == 3){
                $statusBadge = '<a href="#" class="badge badge-danger" data-toggle="tooltip" title="Expired">'.$expirationDate.'</a>';
            }

            $disabledRepack = $unpackedQuantity == 0 ? "disabled" : "";
            $tableRows .= '
                <tr>
                    <th class="text-center">'.$rowcount.'</th>
                    <td class="text-center">'.$id.'</td>
                    '.(
                        $repackable == 1 ? 
                        '<td class="text-center">'.$unpackedQuantity.' '.$retailUnit.'</td>
                        <td class="text-center">'.$quantity.' '.$retailUnit.'</td>' 
                        : 
                        '<td class="text-center">'.$quantity.' '.$retailUnit.'</td>'
                    ).'
                    <td class="text-center">'.number_format($cost, 2).'</td>
                    <td class="text-center">'.number_format($price, 2).'</td>
                    <td class="text-center">'.$statusBadge.'</td>
                    <td class="text-center">
                        
                        <div class="dropdown show">
                            <a class="btn btn-white text-dark dropdown" href="#" role="button" id="batchActions-'.$id.'" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fa-solid fa-ellipsis-vertical"></i>
                            </a>
                        
                            <div class="dropdown-menu" aria-labelledby="batchActions">
                                '.($repackable == 1 ? 
                                    '<button type="button" id="repack-'.$id.'" class="dropdown-item" '.$disabledRepack.' data-dismiss="modal" data-toggle="modal" data-target="#repackBatchModal">Repack</button>' 
                                    : 
                                    ''
                                ).'
                                <button type="button" id="printBarcode-'.$id.'" class="dropdown-item" data-dismiss="modal" data-toggle="modal" data-target="#printBarcodeModal">Print Barcode</button>
                                <button type="button" id="editBatch-'.$id.'" class="dropdown-item" data-dismiss="modal" data-toggle="modal" data-target="#editBatchModal">Edit Batch</button>
                                <button type="button" id="batchpromo-'.$id.'" class="dropdown-item" data-dismiss="modal" data-toggle="modal" data-target="#BatchpromoModal">Promo Batch</button>
                                <button type="button" id="batchloss-'.$id.'" class="dropdown-item" data-dismiss="modal" data-toggle="modal" data-target="#BatchlossModal">Batch Loss</button>
                                <button type="button" id="archiveBatch-'.$id.'" class="dropdown-item" data-dismiss="modal" data-toggle="modal" data-target="#archiveBatchModal">Archive Batch</button>
                            </div>
                        </div>
                    </td>
                </tr>
            ';

            //script for batch actions
            $actionScripts .= '
                <script>
                    $("#repack-'.$id.'").click(function(){
                        $("#repackBatchTitle").html("Repack Batch '.$id.'");
                        $("#repackBatch-batchId").val("'.$id.'");
                        $("#repackBatch-quantity").attr("max", '.$unpackedQuantity.');
                    });

                    $("#printBarcode-'.$id.'").click(function(){
                        $("#printBarcode-productId").val("'.$productId.'");
                        $("#printBarcode-barcode").val("'.$barcode.'");
                        $("#printBarcode-productName").val("'.$productName.'");
                        $("#printBarcode-price").val("'.$price.'");
                        $("#printBarcode-expirationDate").val("'.$expirationDate.'");
                    });

                    $("#editBatch-'.$id.'").click(function(){
                        $("#editBatchTitle").html("Edit Batch '.$id.'");
                        $("#editBatch-batchId").val("'.$id.'");
                        $("#editBatch-productName").html("'.$productName.'");
                        $("#editBatch-quantityRow").html(`
                            '.($repackable == 1 ? 
                            '
                                <div class="col">
                                    <div class="form-group">
                                        <label for="editBatch-unpackedQuantity">Unpacked</label>
                                        <input type="number" min="0" class="form-control" id="editBatch-unpackedQuantity" name="unpackedQuantity" placeholder="Enter Unpacked Quantity" required>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="form-group">
                                        <label for="editBatch-quantity">Repacked</label>
                                        <input type="number" min="0" class="form-control" id="editBatch-quantity" name="quantity" placeholder="Enter Unpacked Quantity" required>
                                    </div>
                                </div>
                            ' 
                        : 
                            '
                                <div class="col">
                                    <div class="form-group">
                                        <label for="editBatch-quantity">Quantity</label>
                                        <input type="number" min="1" class="form-control" id="editBatch-quantity" name="quantity" placeholder="Enter Retail Quantity" required>
                                    </div>
                                </div>
                                <div class="col">
                                    
                                </div>
                            ').'
                        `);

                        $("#editBatch-unpackedQuantity").val("'.$unpackedQuantity.'");
                        $("#editBatch-quantity").val("'.$quantity.'");
                        $("#editBatch-cost").val("'.$cost.'");
                        $("#editBatch-price").val("'.$price.'");
                        '.($expirationDate !== "0000-00-00" ? 
                            '
                                $("#editBatch-expirationDate").val("'.$expirationDate.'");
                                $("#editBatch-expirationDate").attr("readonly", false);
                                $("#editBatch-expirationDate").attr("required", true);
                                $("#editBatch-noExpiration").prop("checked", false);
                            ' 
                            :
                            '
                                $("#editBatch-expirationDate").val("");
                                $("#editBatch-expirationDate").attr("readonly", true);
                                $("#editBatch-expirationDate").attr("required", false);
                                $("#editBatch-noExpiration").prop("checked", true);
                            '
                        ).'
                    });

                    $("#archiveBatch-'.$id.'").click(function(){
                        $("#archiveBatch-batchId").val("'.$id.'");
                        $("#archiveBatchTitle").html("Archive Batch '.$id.'");
                    });

                    $("#batchpromo-'.$id.'").click(function(){
                        $("#batchpromo-batchId").val("'.$id.'");
                        $("#batchpromo-productId").val("'.$productId.'");
                        $("#batchpromoTitle").html("Promo Batch '.$id.'");
                        $("#batchpromo-archiveUnpacked").prop("max", '.$unpackedQuantity.');
                        $("#batchpromo-archiveUnpacked").val("'.$unpackedQuantity.'");
                        $("#batchpromo-archiveQuantity").prop("max", '.$quantity.');
                        $("#batchpromo-archiveQuantity").val("'.$quantity.'");
                    });

                    $("#batchloss-'.$id.'").click(function(){
                        $("#batchloss-batchId").val("'.$id.'");
                        $("#batchloss-productId").val("'.$productId.'");
                        $("#batchlossTitle").html("Archive Batch '.$id.'");
                        $("#batchloss-archiveUnpacked").prop("max", '.$unpackedQuantity.');
                        $("#batchloss-archiveUnpacked").val("'.$unpackedQuantity.'");
                        $("#batchloss-archiveQuantity").prop("max", '.$quantity.');
                        $("#batchloss-archiveQuantity").val("'.$quantity.'");
                    });
                </script>


            ';
            

            $rowcount++;
        }
    }
    else{
        $tableRows .= '
            <tr>
                <td colspan="8" class="text-center" style="height: 200px; vertical-align: middle">No Batch for this Product</td>
            </tr>
        ';
    }


    $quantityHeader = "";
    if($repackable == 1){
        $quantityHeader = '
            <th class="text-center">UNPACKED</th>
            <th class="text-center">REPACKED</th>
        ';
    }
    else{
        $quantityHeader = '
            <th class="text-center">QUANTITY</th>
        ';
    }
    $table = '
        <table class="table batchTable" id="batchTable">
            <thead>
                <th class="text-center">#</th>
                <th class="text-center">ID</th>
                '.$quantityHeader.'
                <th class="text-center">(₱) UNIT COST</th>
                <th class="text-center">(₱) UNIT PRICE</th>
                <th class="text-center">EXPIRATION DATE</th>
                <th class="text-center"></th>
            </thead>
            <tbody>
                '.$tableRows.'
            </tbody>
        </table>
    ';

    //script for add batch button
    echo '
        '.$table.'
        '.$actionScripts.'
        <script>
            $("#addBatchBtn").click(function(){
                $("#addBatch-productId").val("'.$productId.'");
                $("#addBatch-repackable").val("'.$repackable.'");
                $("#addBatch-productName").html("'.$productName.'");
                $("#addBatch-retailCost").val("'.$baseCost.'");
                $("#addBatch-price").val("'.$basePrice.'");
            });
        </script>
    ';
?>