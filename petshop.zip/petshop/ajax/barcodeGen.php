<?php
    include("../includes/connection.php");

    function generateEAN() {
        $date = new DateTime();
        $time = $date->getTimestamp();
    
        $code = '20' . str_pad($time, 10, '0');
        $weightflag = true;
        $sum = 0;
    
        for ($i = strlen($code) - 1; $i >= 0; $i--) {
            $sum += (int)$code[$i] * ($weightflag ? 3 : 1);
            $weightflag = !$weightflag;
        }
        $code .= (10 - ($sum % 10)) % 10;
        return $code;
    }

    function getBarcode($conn){
        $barcode = "";
        while(True){
            $code = generateEAN();
            $result = $conn->query("SELECT `barcode` FROM `products` WHERE `barcode` = '$code'");
            if($result->num_rows == 0){
                $barcode = $code;
                break;
            }
        }
        return $barcode;
    }
    
    echo getBarcode($conn);
?>