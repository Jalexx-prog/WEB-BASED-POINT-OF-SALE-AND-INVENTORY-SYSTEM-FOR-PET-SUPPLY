<?php
try{
    session_start();
    include("./includes/connection.php");
    include('./includes/log_check.php');
    
    date_default_timezone_set('Asia/Manila');
    $user = $_SESSION["user_id"];
    $date = date("Y-m-d H-i-s");

    if($_SERVER["REQUEST_METHOD"] === "POST"){
        //transaction details
        $total = $_POST["total"];
        $amountTendered = $_POST["amountTendered"];
        $change = $_POST["change"];
        $vatableSales = $_POST["vatableSales"];
        $vatAmount = $_POST["vatAmount"];
        $discount = $_POST["discount"];
    
        $conn->query("
            INSERT INTO `transactions`(
                `transaction_id`, `total`, `amount_tendered`, 
                `change_amount`, `vatable_sales`, `vat_amount`, 
                `discount`, `date_created`, `created_by`
            ) VALUES (
                '0','$total','$amountTendered',
                '$change','$vatableSales','$vatAmount',
                '$discount','$date','$user'
            )
        ");



        $transactionId = $conn->query("
            SELECT MAX(`transaction_id`) AS `transaction_id` FROM `transactions`
        ")->fetch_assoc()["transaction_id"];

        
        //transaction items (arrays)
        $productId = $_POST["productId"];
        $productName = $_POST["productName"];
        $wholesaleLevel = $_POST["wholesaleLevel"];
        $repackable = $_POST["repackable"];
        $quantity = $_POST["quantity"];
        $quantityType = $_POST["quantityType"];
        $retailUnit = $_POST["retailUnit"];
        $wholesaleUnit = $_POST["wholesaleUnit"];
        $promoBuy = $_POST["promoBuy"];
        $promoGet = $_POST["promoGet"];
        $promoDiscount = $_POST["promoDiscount"];
        $productPromo = $_POST["productPromo"];
        $cost = $_POST["cost"];
        $price = $_POST["price"];
        $subtotal = $_POST["subtotal"];

        $len =  count($productId);
        
        for($x = 0; $x < $len; $x++){
            $freebieQty = 0;
            $prmFreebie = "None";
            $unit = 0;
            
            
            if($quantityType[$x] == 1){   // if promo is BOGO
                
                if($promoBuy[$x] !== "0" and $promoGet[$x] !== "0"){
                    $freePrd = $conn->query("SELECT prd.product_name FROM promo_product prm INNER JOIN products prd ON prm.product_id = prd.product_id WHERE prd_promo_id = '".$productPromo[$x]."'")->fetch_assoc()["product_name"];
                    $prmQty = $conn->query("SELECT quantity_promo FROM promo_product WHERE prd_promo_id = '".$productPromo[$x]."'")->fetch_assoc()["quantity_promo"];
                    $freebie = intdiv($quantity[$x], $promoBuy[$x]);
                    

                    $freebieQty = ($prmQty - ($freebie * $promoGet[$x]) > 0) ? ($prmQty - ($freebie * $promoGet[$x])) : ($prmQty - ($freebie * $promoGet[$x])) + ($freebie * $promoGet[$x]);
                    $prmFreebie = $freebieQty ." ". $freePrd;
                    
                }
                else{
                    $prmFreebie = "None";
                }
                $prmDiscount = $promoDiscount[$x];
                $unit = $retailUnit[$x];
            }
            
            else{   //if quantity type is wholesale
                $prmFreebie = "None";
                $prmDiscount = 0;
                $unit = $wholesaleUnit[$x];
            }
            
            

            $conn->query("
                INSERT INTO `transaction_items`(
                    `t_item_id`, `transaction_id`, `product_id`, 
                    `wholesaleLevel`, `cost`, `quantity`, `quantity_type`,
                    `unit`, `price`, `subtotal`, 
                    `promo_freebie`, `promo_discount`
                ) VALUES (
                    '0','$transactionId','".$productId[$x]."',
                    '".$wholesaleLevel[$x]."', '".$cost[$x]."', '".$quantity[$x]."', '".$quantityType[$x]."',
                    '".$unit."', '".$price[$x]."', '".$subtotal[$x]."', '$prmFreebie', '$prmDiscount'
                )
            ");
            
            

            //deduct items from inventory
            $totalQty = 0;
            $qtyCol = $repackable[$x] === "1" ? "unpacked_quantity" : "quantity";
            $batch = $conn->query("
                SELECT `batch_id`, `unpacked_quantity`, `quantity`, (`$qtyCol` DIV ".$wholesaleLevel[$x].") AS `wholesale_quantity` 
                FROM `batch` 
                WHERE `product_id` = '".$productId[$x]."' AND `archive_status` = 0 AND (`unpacked_quantity` + `quantity`) > 0
                ORDER BY `expiration_date` ASC
            ");
            if($quantityType[$x] == 1){ //if quantity type is singles
                //$totalQty = (int)$quantity[$x] + (int)$prmFreebie;
                $totalQty = (int)$quantity[$x];
            }
            else{
                $totalQty = (int)$wholesaleLevel[$x] * (int)$quantity[$x];
            }

            
            while($row = $batch->fetch_assoc()){
                $id = $row["batch_id"];
                $qtyCol = $repackable[$x] === "1" ? "unpacked_quantity" : "quantity";
                if($quantityType[$x] == 2){
                    if($row["wholesale_quantity"] == 0){
                        continue;
                    }

                    if($quantity[$x] > $row["wholesale_quantity"]){
                        $a = $totalQty;// - ;
                        $b = (int)$row["wholesale_quantity"] * (int)$wholesaleLevel[$x];
                        $dct = $a - ($a - $b);
                        $conn->query("
                            UPDATE `batch` 
                            SET `$qtyCol`=`$qtyCol` - ($dct)
                            WHERE `batch_id` = '".$id."'
                        ");
                        $totalQty = $totalQty - $dct;
                        continue;
                    }
                    else{
                        $conn->query("
                            UPDATE `batch` 
                            SET `$qtyCol` = (`$qtyCol` - $totalQty) 
                            WHERE `batch_id` = '".$id."'
                        ");
                        break;
                    }
                }
                else{
                    if($quantity[$x] > $row["quantity"]){
                        $conn->query("
                            UPDATE `batch` 
                            SET `quantity`='0' 
                            WHERE `batch_id` = '".$id."'
                        ");

                        $totalQty = $totalQty - $row["quantity"];
                        continue;
                    }
                    else{
                        $conn->query("
                            UPDATE `batch` 
                            SET `quantity` = (`quantity` - $totalQty) 
                            WHERE `batch_id` = '".$id."'
                        ");

                        $conn->query("
                            UPDATE `promo_product` 
                            SET `quantity_promo` = (`quantity_promo` - $freebieQty) 
                            WHERE `prd_promo_id` = '".$productPromo[$x]."'
                        ");
                        break;
                    }
                }
            }

            
            
        }
        include("./includes/updateProductStatus.php");
        include("./includes/updateExpirationStatus.php");

        $_SESSION["message"] = "pos-transaction";
        header("location: ./printReciept.php?transaction=$transactionId");
        exit();
        

        
    }
    else{   //runs if there are no POST method
        $_SESSION["message"] = "error";
        header("location: ./pos-cashier.php");
        exit();


    }
}
catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    echo $e;
    header("location: ./pos-cashier.php");
    exit();
}
    
?>