<?php
try{
    session_start();
    include("./includes/connection.php");
    include('./includes/log_check.php');
    include ('./includes/checkRole.php');
    
    date_default_timezone_set('Asia/Manila');
    $user = $_SESSION["user_id"];
    $date = date("Y-m-d H-i-s");

$dcname = "";
$percent = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["dcname"]) && isset($_POST["percent"])) {
    $dcname = $_POST["dcname"];
    $percent = $_POST["percent"];

    $discountSql = "INSERT INTO `discount`(`discount_id`, `discount_name`, `percent`, `discount_status`) VALUES ('','$dcname','$percent','1')";
    $discountResult = $conn->query($discountSql);

    if (!$discountResult) {
        die("Discount insertion failed: " . $conn->error);
    }

    $dcnameId = $conn->insert_id;

    
    $_SESSION["message"] = "discount-added";
    header("location: ./discount-page.php");
    exit();


}  else{   //runs if there are no POST method
        $_SESSION["message"] = "error";
        header("location: ./discount-page.php");
        exit();

}

}
catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    header("location: ./discount-page.php");
    exit();
}
?>