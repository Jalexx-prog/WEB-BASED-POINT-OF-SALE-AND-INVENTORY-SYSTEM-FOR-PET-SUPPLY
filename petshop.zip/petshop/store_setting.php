<?php
session_start();

include('includes/connection.php');
include('./includes/log_check.php');
include ('./includes/checkRole.php');
date_default_timezone_set('Asia/Manila');

$logo = $conn->query("SELECT `logo` FROM `system`")->fetch_assoc()["logo"];


$sql = "SELECT * FROM system WHERE 1";
$result = $conn->query($sql);



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--Bootstrap-->
    <link rel="stylesheet" href="./bootstrap/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <script src="./bootstrap/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

    <!--Jquery-->
    <script src="./js/jquery_3.6.4_jquery.min.js"></script>

    <script src="./bootstrap//popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>

    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip();
        })
    </script>

    <!--Fontawesome-->
    <link rel="stylesheet" href="./fontawesome/css/all.min.css">

    <!--CSS-->
    <link rel="stylesheet" href="./css/styles.css">
    <link rel="stylesheet" href="./css/inventory.css">

    <link rel="icon" type="image/png" href="./assets/<?php echo $logo?>" />
    <title>Setting</title>
</head>

<body>
    <?php

    include("./includes/navbar.php");


    while ($row = $result->fetch_assoc()) {

    ?>

        <div class="container main-div py-4" id="main-div">
            <h3>Store Details</h3>
            <div class="row py-3">
                <div class="col-md-6">
                    <div class="border rounded p-3 text-center" style="max-height: 590px; overflow-y: auto;">
                        <img src="assets/<?php echo $row['logo']; ?>" class="img-fluid rounded-circle" style="max-width: 45%;">
                        <hr>
                        <form action="store-form-update.php" method="POST" enctype="multipart/form-data">
                            <div class="container-fluid mb-3">

                                <!--hidden color-->
                                <input type="hidden" name="current_navbar_color" value="<?php echo $row['navbar_color']; ?>">
                                <input type="hidden" name="current_sidebar_color" value="<?php echo $row['sidebar_color']; ?>">
                                <input type="hidden" name="current_hover_color" value="<?php echo $row['hover_color']; ?>">
                                <!--ONCHANGE-->
                                <label for="navbarColor" class="form-label">Navbar Color:</label>
                                <input type="color" id="navbarColor" class="form-control" style="max-width: 50%; margin-left: 110px;" value="<?php echo $row['navbar_color']; ?>" onchange="updateColorValue(this, 'current_navbar_color')">
                            </div>
                            <div class="container-fluid mb-3">
                                <label for="sidebarColor" class="form-label">Sidebar Color:</label>
                                <input type="color" id="sidebarColor" class="form-control" style="max-width: 50%; margin-left: 110px;" value="<?php echo $row['sidebar_color']; ?>" onchange="updateColorValue(this, 'current_sidebar_color')">
                            </div>
                            <div class="container-fluid mb-3">
                                <label for="sidebarColor" class="form-label">hover link Color:</label>
                                <input type="color" id="hoverColor" class="form-control" style="max-width: 50%; margin-left: 110px;" value="<?php echo $row['hover_color']; ?>" onchange="updateColorValue(this, 'current_hover_color')">
                            </div>
                    </div>
                </div>

                <div class="col-md-6 border rounded">
                    <div class="p-3">
                        <div class="row">
                            <div class="col">
                                <input type="hidden" name="id" value="<?php echo $row['system_id']; ?>">
                                <label class="form-label">Store Name</label>
                                <input type="text" class="form-control" name="store_name" value="<?php echo $row['store_name']; ?>" required>

                                <label class="form-label">Store Address</label>
                                <input type="text" class="form-control" name="store_address" value="<?php echo $row['store_address']; ?>" required>

                                <label class="form-label">TIN number</label>
                                <input type="text" class="form-control" name="tin_number" value="<?php echo $row['tin_number']; ?>" required>

                                <label class="form-label">Contact</label>
                                <input type="text" class="form-control" name="contact" value="<?php echo $row['contact']; ?>" required>

                                <!-- Assuming the database has a column named 'logo' for the file path -->
                                <label class="form-label">Logo</label>
                                <input type="file" class="form-control" name="logo">


                                <hr>
                                <button type="submit" class="btn btn-primary">Apply Changes</button>
                                </form>
                            <?php
                        }
                            ?>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
        </div>






        </div>
        <script>
            function updateColorValue(colorInput, hiddenInputName) {
                const hiddenInput = document.querySelector(`input[name="${hiddenInputName}"]`);
                hiddenInput.value = colorInput.value;
            }
        </script>

</body>

</html>