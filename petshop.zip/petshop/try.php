<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dropdown Example</title>
    <script>
        function handleDropdownChange() {
            const dropdown = document.getElementById('dropdown');
            const checkbox = document.getElementById('checkbox');
            const textbox = document.getElementById('textbox');
            
            if (dropdown.value === 'yes') {
                checkbox.checked = true;
                textbox.disabled = true;
            } else {
                checkbox.checked = false;
                textbox.disabled = false;
            }
        }
    </script>
</head>
<body>
    <label for="dropdown">Choose an option:</label>
    <select id="dropdown" onchange="handleDropdownChange()">
        <option value="no">No</option>
        <option value="yes">Yes</option>
    </select>
    <br><br>
    <input type="checkbox" id="checkbox" disabled>
    <label for="checkbox">Checkbox</label>
    <br><br>
    <input type="text" id="textbox">
    <label for="textbox">Textbox</label>
</body>
</html>