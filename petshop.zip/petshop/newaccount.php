<?php
session_start();
include('includes/connection.php');
include('./includes/log_check.php');
include ('./includes/checkRole.php');

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = $_POST['f_name'];
    $last_name = $_POST['l_name'];
    $username = $_POST['username'];
    $pass = $_POST['new_pass'];
    $role = $_POST['role'];
    $status = $_POST['status'];
    $confirm = $_POST['Confirm_pass'];
    $security_question1 = $_POST['security_question1'];
    $Answer1 = $_POST['Answer1'];
    $security_question2 = $_POST['security_question2'];
    $Answer2 = $_POST['Answer2'];


    // Check if passwords match
    if ($pass == $confirm) {
        $password = password_hash($pass, PASSWORD_DEFAULT);

        $profile_picture = 'default-pp.png';
        if ($_FILES['profile_picture']['error'] == 0) {
            $target_dir = 'uploads/';
            $profile_picture = basename($_FILES['profile_picture']['name']);
            $target_file = $target_dir . $profile_picture;

            // Move the uploaded file to the desired directory
            if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $target_file)) {
                echo 'File uploaded successfully.';
            } else {
                echo 'Error uploading file.';
            }
        }

        // Insert data into the database
        $sql = "INSERT INTO user (first_name, last_name, username, password, role, status, profile_picture, security_question1, answer_1, security_question2, answer_2) VALUES ('$first_name', '$last_name', '$username', '$password', '$role', '$status', '$profile_picture','$security_question1','$Answer1','$security_question2','$Answer2')";
        if ($conn->query($sql) === TRUE) {
            $_SESSION["message"] = "new-account";
            header("Location: manage-account.php");
            exit();
        } else {
            echo "Error inserting record: " . $conn->error;
        }
    } else {
        // Passwords do not match
        $_SESSION["message"] = "password-not-match";
        header("Location: manage-account.php");
        exit();
    }
}
