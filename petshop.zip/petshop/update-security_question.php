<?php
try{
session_start();
include("./includes/connection.php");
include('./includes/log_check.php');
    
date_default_timezone_set('Asia/Manila');


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $security1 = $_POST["security_question1"];
    $answer1 = $_POST["Answer1"];
    $security2 = $_POST["security_question2"];
    $answer2 = $_POST["Answer2"];
    $id = $_POST["id"];
    
    $sql = "UPDATE `user` SET `security_question1` = '$security1' ,`answer_1` = '$answer1', `security_question2` = '$security2', `answer_2` = '$answer2' WHERE `user_id` = $id ";
    $Result = $conn->query($sql);
  
    if (!$Result) {
        die("Security question result update failed: " . $conn->error);
    }
  }


    $_SESSION["message"] = "update-security";
    header("location: ./edit-account.php");
    exit();

} catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    echo $e;
    header("location: ./manage-account.php");
    exit();
}
?>