<?php
try{
session_start();
include('./includes/log_check.php');
include ('./includes/checkRole.php');

date_default_timezone_set('Asia/Manila');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST["id"];

    include("./includes/connection.php");


    $sql = "DELETE FROM category WHERE category_id = '$id'";
    $conn->query($sql);
    

    $_SESSION["message"] = "category-deleted";
    header("location: ./inv-category.php");
    exit;
}

}catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    header("location: ./inv-category.php");
    exit();
}
?>
