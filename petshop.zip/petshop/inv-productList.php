<?php
session_start();

date_default_timezone_set('Asia/Manila');
include("./includes/connection.php");
include('./includes/log_check.php');
include('./includes/checkRole.php');

$logo = $conn->query("SELECT `logo` FROM `system`")->fetch_assoc()["logo"];

$condition = '`archive_status` = 0';
$order = (isset($_GET["orderColumn"]) and isset($_GET["orderDirection"])) ? "ORDER BY `" . $_GET["orderColumn"] . "` " . $_GET["orderDirection"] : "ORDER BY `product_name` ASC";
$limit = 10;
$search = isset($_GET["search"]) ? $_GET["search"] : '';
$page = isset($_GET["page"]) ? $_GET["page"] : '1';



if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET["search"]) and $_GET["search"] !== "") {
        $condition .= " AND `barcode` = '$search' OR `product_name` LIKE '%$search%'";
    }


    if (isset($_GET["category-filter"]) or isset($_GET["stock-filter"])) {

        if (isset($_GET["category-filter"])) {
            $category_filter = "'" . $_GET["category-filter"] . "'";
        } else {
            $category_filter = "`products`.`category_id`";
        }

        if (isset($_GET["stock-filter"])) {
            $stock_filter = "'" . $_GET["stock-filter"] . "'";
        } else {
            $stock_filter = "`products`.`stock_status`";
        }

        $condition .= " AND `products`.`category_id` = $category_filter AND `products`.`stock_status` = $stock_filter AND `products`.`archive_status` = '0'";
    }


    //get the page of table
    if (isset($_GET["page"])) {
        $page = $_GET["page"];
    } else {
        $page = 1;
    }
}
//default page
else {
    $condition = "`archive_status` = '0'";
    $page = 1;
}



//makes a hidden form for all GET methods
//needed for pagination so that the GET value stays after switching pages
$searchForm = isset($_GET["search"]) ?
    '<input type="hidden" name="search" value="' . $_GET["search"] . '">' :
    "";

$categoryForm = isset($_GET["category-filter"]) ?
    '<input type="hidden" name="category-filter" value="' . $_GET["category-filter"] . '">' :
    "";

$stockForm = isset($_GET["stock-filter"]) ?
    '<input type="hidden" name="stock-filter" value="' . $_GET["stock-filter"] . '">' :
    "";

//concatenate all GET forms
$forms = $searchForm . $categoryForm . $stockForm;

$query = "
        SELECT 
            `products`.`product_id`, 
            `products`.`barcode`, 
            `products`.`product_name`, 
            `products`.`category_id`, 
            `category`.`category_name`,
            `products`.`repackable`,
            IFNULL(
                (SELECT (SUM(`unpacked_quantity`) + SUM(`batch`.`quantity`)) FROM `batch` WHERE `batch`.`product_id` = `products`.`product_id` AND `batch`.`archive_status` = 0), 
                0
            ) AS `stocks`,
            `products`.`retail_unit` AS `retail_unit_id`,
            `products`.`wholesale_unit` AS `wholesale_unit_id`,
            IFNULL((SELECT `unit_of_measurement`.`unit_name` FROM `unit_of_measurement` WHERE `unit_of_measurement`.`unit_id` = `products`.`retail_unit`), '') AS `retail_unit`,
            IFNULL((SELECT `unit_of_measurement`.`unit_name` FROM `unit_of_measurement` WHERE `unit_of_measurement`.`unit_id` = `products`.`wholesale_unit`), '') AS `wholesale_unit`,
            `products`.`cost`, 
            `products`.`price`, 
            `products`.`description`, 
            `products`.`warning_level`, 
            `products`.`wholesale_level`, 
            `products`.`stock_status`, 
            `products`.`date_created`, 
            `user`.`username` AS `created_by`,
            (SELECT COUNT(*) FROM `batch` WHERE `batch`.`product_id` = `products`.`product_id` AND `batch`.`archive_status` = 0) AS `batch_count`,
            (SELECT MAX(`expiration_status`) FROM `batch` WHERE `batch`.`product_id` = `products`.`product_id`) AS `expiration_status`,
            `products`.`archive_status`
        FROM `products` 
            INNER JOIN `category` ON `products`.`category_id` = `category`.`category_id`
            INNER JOIN `user` ON `products`.`created_by` = `user`.`user_id`
        WHERE $condition
    ";


$pageLocation = "./inv-productList.php";
include("./includes/pagination.php");

//execute the sql query for getting the table of products 
$result = $conn->query("
        $query
        $order
        LIMIT $limit OFFSET $offset;
    ");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--Bootstrap-->
    <link rel="stylesheet" href="./bootstrap/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <script src="./bootstrap/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

    <!--Jquery-->
    <script src="./js/jquery_3.6.4_jquery.min.js"></script>

    <script src="./bootstrap//popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <!-- <script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>-->

    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip();
        })
    </script>

    <!--Fontawesome-->
    <link rel="stylesheet" href="./fontawesome/css/all.min.css">

    <!--CSS-->
    <link rel="stylesheet" href="./css/styles.css">
    <link rel="stylesheet" href="./css/inventory.css">

    <link rel="icon" type="image/png" href="./assets/<?= $logo ?>" />
    <title>Inventory</title>
</head>

<body>
    <?php
    $module = "inventory";
    include("./includes/navbar.php");
    ?>


    <div class="container main-div py-4" id="main-div">
        <h3>List of Products (<?= $itemCount ?>)</h3>
        <!--Table section-->
        <section class="productTableSection mt-5" id="productTableSection">
            <!--Buttons row-->
            <div class="row mb-3 d-flex flex-row-reverse">
                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#addProductModal"><i class="fa-solid fa-plus"></i>&emsp;Add Product</button>
                &emsp;
                <button type="button" class="btn btn-outline-primary" id="sortTableBtn" data-toggle="modal" data-target="#sortTableModal"><i class="fa-solid fa-sort"></i></button>

                <?= (isset($_GET["search"]) or (isset($_GET["orderColumn"]) and isset($_GET["orderDirection"]))) ? '
                    &emsp;
                    <a href="./inv-productList.php" class="btn btn-outline-secondary"><i class="fa-solid fa-rotate-left"></i></a>
                ' :
                    '' ?>

            </div>
            <div class="border border-dark rounded mb-3">
                <form id="filter-form" class="filter-form" action="./inv-productList.php" method="get">
                    <div class="row bordered rounded m-1 mb-4">
                        <input type="hidden" name="this" value="inv-productList.php">
                        <div class="col-9 p-3 d-flex bg-white">
                            <select class="filter bg-blue bordered form-control ml-3 mr-3" name="category-filter" id="category-filter">
                                <option value="0" selected disabled>Select Category</option>
                                <?php

                                $category_db = "SELECT * 
                             FROM `category`
                             WHERE 1
                             ORDER BY `category_name` ASC
                         ";
                                $category_result = $conn->query($category_db);

                                while ($row = $category_result->fetch_assoc()) {
                                    echo '<option value="' . $row["category_id"] . '">' . $row["category_name"] . '</option>';
                                }


                                ?>

                            </select>
                            <select class="filter bg-blue bordered form-control ml-3 mr-3" name="stock-filter" id="stock-filter">
                                <option value="0" selected disabled>Select Stock Status</option>
                                <option value="1">In Stock</option>
                                <option value="2">Critical</option>
                                <option value="3">Out of Stock</option>
                            </select>
                        </div>
                        <div class="col d-flex flex-row-reverse p-3">
                            <button href="./inv-productList.php" id="clear-filter" class="btn btn-outline-danger">
                                <i class="fa-solid fa-xmark"></i>&emsp;Clear
                            </button>
                            <button type="submit" class="btn btn-outline-primary mr-3">
                                <i class="fa-solid fa-filter"></i>&emsp;Filter
                            </button>

                        </div>
                    </div>
                </form>
            </div>
            <!--Table row-->
            <div class="row productTableRow">
                <table class="table productTable" id="productTable">
                    <thead>
                        <th class="text-center"></th>
                        <th class="text-center">#</th>
                        <th class="text-center">BARCODE</th>
                        <th class="text-center">PRODUCT NAME</th>
                        <th class="text-center">CATEGORY</th>
                        <th class="text-center">STOCKS</th>
                        <th class="text-center">(₱) UNIT COST</th>
                        <th class="text-center">(₱) UNIT PRICE</th>
                        <th class="text-center">STATUS</th>
                        <th class="text-center"></th>

                    </thead>
                    <tbody id="tbodyProducts">
                        <?php
                        if ($result->num_rows > 0) {
                            //the row number
                            $rowcount = $offset + 1;

                            while ($row = $result->fetch_assoc()) {

                                $id = $row["product_id"];
                                $barcode = $row["barcode"];
                                $productName = wordwrap($row["product_name"], 30, "<br>\n");
                                $categoryId = $row["category_id"];
                                $category = $row["category_name"];

                                $stocks = $row["stocks"];
                                $retailUnitId = $row["retail_unit_id"];
                                $wholesaleUnitId = $row["wholesale_unit_id"];
                                $retailUnit = $row["retail_unit"];
                                $wholesaleUnit = $row["wholesale_unit"];
                                $cost = $row["cost"];
                                $price = $row["price"];
                                $warningLevel = $row["warning_level"];
                                $wholesaleLevel = $row["wholesale_level"];
                                $description = $row["description"];
                                $stockStatus = $row["stock_status"];
                                $dateCreated = date("M d, Y", strtotime($row["date_created"]));
                                $timeCreated = date("h:i a", strtotime($row["date_created"]));
                                $createdBy = $row["created_by"];
                                $statusBadge = "";
                                if ($stockStatus == 1) {
                                    $statusBadge = '<a href="#" class="badge badge-light">In Stock</a>';
                                } elseif ($stockStatus == 2) {
                                    $statusBadge = '<a href="#" class="badge badge-danger">Critical</a>';
                                } elseif ($stockStatus == 3) {
                                    $statusBadge = '<a href="#" class="badge badge-dark">Out of Stock</a>';
                                }

                                $prod_details = $description == '' ? '<a href="#" class="badge badge-light">N/A</a>' : $description;

                                $repackable = $row["repackable"];
                                $repackableBadge = "";
                                if ($repackable == 1) {
                                    $repackableBadge = '<span class="badge badge-info repack-badge">● Repack</span>';
                                }


                                echo '
                                        <tr class="main-row">
                                            <td class="text-center">
                                                <a class="text-store-brown" data-toggle="collapse" href="#inner-row-' . $id . '" role="button">
                                                    <i class="fa-solid fa-plus"></i>
                                                </a>
                                            </td>
                                            <th class="text-center">' . $rowcount . '</th>
                                            <td class="text-center">
                                                <a href="#" class="text-dark" data-toggle="tooltip" 
                                                    title="
                                                        <img class=\'bg-white px-3 py-2\' src=\'./barcode/barcode_' . $id . '.png\'?t=' . time() . '>
                                                    ">
                                                    ' . $barcode . '
                                                </a>
                                            </td>
                                            <td>' . $productName . '&emsp;' . $repackableBadge . '</td>
                                            <td class="text-center">' . $category . '</td>
                                            <td class="text-center">' . $stocks . ' ' . $retailUnit . '</td>
                                            <td class="text-center">' . number_format($cost, 2) . '</td>
                                            <td class="text-center">' . number_format($price, 2) . '</td>
                                            <td class="text-center">' . $statusBadge . '</td>
                                            <td class="text-center">
                                                <div class="dropdown show">
                                                    <a class="dropdown text-dark btn btn-white" href="#" role="button" id="productAction-' . $id . '" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="fa-solid fa-ellipsis-vertical"></i>
                                                    </a>
                                                    <a id="viewBatch-' . $id . '" class="btn btn-white" href="#" data-toggle="modal" role="button" data-target="#viewBatchModal"><i class="fas fa-box"></i></a>
                                                    
                                                
                                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                        <a id="editProduct-' . $id . '" class="dropdown-item" href="#" data-toggle="modal" data-target="#editProductModal">Edit Product Details</a>
                                                        <a id="archiveProduct-' . $id . '" class="dropdown-item" href="#" data-toggle="modal" data-target="#archiveProductModal">Archive Product</a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr class="inner-row">
                                            <td colspan="10">
                                                <div class="collapse" id="inner-row-' . $id . '">
                                                    <div class="ml-5 p-3">
                                                        <h5>Additional Details</h5>
                                                        <hr>
                                                        <div class="row">
                                                            <div class="col col-md-3">
                                                                <h6>Warning Level</h6>
                                                                <p>&emsp;● ' . $warningLevel . ' ' . $retailUnit . '</p>
                                                                <br>
                                                                <h6>Wholesale Level</h6>
                                                                <p>&emsp;● ' . ($wholesaleLevel > 1 ? $wholesaleLevel . ' ' . $retailUnit : "N/A") . '</p>
                                                                <br>
                                                                <h6>Wholesale Unit</h6>
                                                                <p>&emsp;● ' . ($wholesaleUnit !== "" ? $wholesaleUnit : "N/A") . '</p>
                                                            </div>
                                                            <div class="col col-md-4">
                                                                <h6>Barcode Image</h6>
                                                                &emsp;<img src="./barcode/barcode_' . $id . '.png?t=' . time() . '" style="height: 40px">
                                                                <br><br>
                                                                <h6>Product Description</h6>
                                                                <p>&emsp;● ' . $prod_details . '</p>
                                                                
                                                            </div>
                                                            <div class="col col-md-3">
                                                                <h6>Date Created</h6>
                                                                <p>&emsp;● ' . $dateCreated . '</p>
                                                                <br>
                                                                <h6>Time Created</h6>
                                                                <p>&emsp;● ' . $timeCreated . '</p>
                                                                <br>
                                                                <h6>Created By</h6>
                                                                <p>&emsp;● ' . $createdBy . '</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                            </td>
                                        </tr>
                                    ';

                                //script for action buttons
                                echo '
                                        <script>
                                            $("#viewBatch-' . $id . '").click(function(){
                                                $.post(
                                                    "./ajax/getBatch.php", 
                                                    {
                                                        productId: "' . $id . '",
                                                        barcode: "' . $barcode . '",
                                                        productName: "' . $productName . '",
                                                        retailUnit: "' . $retailUnit . '",
                                                        wholesaleUnit: "' . $wholesaleUnit . '",
                                                        repackable: "' . $repackable . '",
                                                        baseCost: "' . $cost . '",
                                                        basePrice: "' . $price . '"
                                                    }, 
                                                    function(result){
                                                        $("#viewBatchTitle").html("' . $productName . ' Batches");
                                                        $("#batchTableRow").html(result);
                                                    }
                                                ); 
                                            });

                                            $("#editProduct-' . $id . '").click(function(){
                                                $("#editProduct-productId").val("' . $id . '");
                                                $("#editProduct-oldBarcode").val("' . $barcode . '");
                                                $("#editProduct-barcode").val("' . $barcode . '");
                                                $("#editProduct-productName").val("' . $productName . '");
                                                $("#editProduct-category").val("' . $categoryId . '");
                                                $("#editProduct-warningLevel").val("' . $warningLevel . '");
                                                $("#editProduct-cost").val("' . $cost . '");
                                                $("#editProduct-price").val("' . $price . '");
                                                $("#editProduct-retailUnit").val("' . $retailUnitId . '");
                                                $("#editProduct-repackable").val("' . $repackable . '");
                                                $("#editProduct-desciption").val("' . $description . '");
                                                ' . (
                                    ($wholesaleLevel > 1 and $wholesaleUnitId > 0) ?
                                    '
                                                        $("#editProduct-wholesaleLevel").val("' . $wholesaleLevel . '");
                                                        $("#editProduct-wholesaleUnit").val("' . $wholesaleUnitId . '");
                                                        $("#editProduct-wholesaleLevel").attr("readonly", false);
                                                        $("#editProduct-wholesaleUnit").attr("readonly", false);
                                                        $("#editProduct-noWholesale").prop("checked", false);
                                                    '
                                    :
                                    '
                                                        $("#editProduct-wholesaleLevel").val("");
                                                        $("#editProduct-wholesaleUnit").val("");
                                                        $("#editProduct-wholesaleLevel").attr("readonly", true);
                                                        $("#editProduct-wholesaleUnit").attr("readonly", true);
                                                        $("#editProduct-noWholesale").prop("checked", true);
                                                    '
                                ) . '
                                            });

                                            $("#archiveProduct-' . $id . '").click(function(){
                                                $("#archiveProduct-productId").val("' . $id . '");
                                                $("#archiveProductTitle").html("Archive ' . $productName . '");
                                            });
                                        </script>
                                    ';


                                $rowcount++;
                            }
                        } else { //if there are no products to show
                            echo '
                                    <tr>
                                        <td colspan="10" class="text-center" style="height: 200px; vertical-align: middle">No Result</td>
                                    </tr>
                                ';
                        }
                        ?>
                    </tbody>
                </table>
                <?= $pageCount > 1 ? '<p>Page ' . $page . ' out of ' . $pageCount . ' pages</p>' : '' ?>
            </div>
        </section>

        <?= $pagination ?>
    </div>


    <!-- MODALS ARE HERE -->

    <!--View Batch Modal -->
    <div class="modal fade" id="viewBatchModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewBatchTitle">...</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">

                    <div class="row p-3 mb-2 d-flex flex-row-reverse">
                        <button class="btn btn-success" id="addBatchBtn" data-dismiss="modal" data-toggle="modal" data-target="#addBatchModal"><i class="fa-solid fa-plus"></i>&emsp;Add Batch</button>
                    </div>

                    <div class="row p-3 batchTableRow" id="batchTableRow">

                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>



    <!--Add Batch Modal -->
    <form action="./invForm-addBatch.php" method="post">

        <input type="hidden" id="addBatch-productId" name="productId">
        <input type="hidden" id="addBatch-repackable" name="repackable">

        <div class="modal fade" id="addBatchModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Add Batch</h5>
                        <button type="button" class="close" data-dismiss="modal" data-toggle="modal" data-target="#viewBatchModal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <h6>Product</h6>
                        <span class="pl-3" id="addBatch-productName">...</span>
                        <hr>

                        <!--Quantity Row-->
                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="addBatch-quantity">Quantity</label>
                                    <input type="number" min="1" class="form-control" id="addBatch-quantity" name="quantity" placeholder="Enter Retail Quantity" required>
                                </div>
                            </div>
                            <div class="col">

                            </div>
                        </div>

                        <!--Cost and Price Row-->
                        <div class="row">
                            <div class="col">
                                <label for="addBatch-cost">Cost</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <input type="number" step="0.01" min="0.01" class="form-control" id="addBatch-wholesaleCost" name="wholesaleCost" placeholder="0.00">
                                        <span class="input-group-text" id="basic-addon1">=</span>
                                        <input type="number" step="0.01" min="0.01" class="form-control" id="addBatch-retailCost" name="retailCost" placeholder="0.00" required>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col col-4">
                                        Wholesale
                                    </div>
                                    <div class="col col-2">

                                    </div>
                                    <div class="col col-5">
                                        Retail
                                    </div>
                                </div>
                            </div>
                            <div class="col">
                                <label for="addBatch-price">Retail Price</label>
                                <div class="input-group">

                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1">₱</span>
                                    </div>
                                    <input type="number" step="0.01" min="0.01" class="form-control" id="addBatch-price" name="price" placeholder="0.00" required>
                                </div>
                            </div>
                        </div>

                        <!--Expiration Date Row-->
                        <div class="row mt-3">
                            <div class="col">
                                <div class="form-group">
                                    <label for="addBatch-quantity">Expiration Date</label>
                                    <input type="date" class="form-control" id="addBatch-expirationDate" name="expirationDate" required>
                                    <input type="checkbox" id="addBatch-noExpiration" name="noExpiration" value="1">
                                    <label for="noExpiration">Check if not applicable</label>
                                </div>

                            </div>
                            <div class="col">

                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal" data-toggle="modal" data-target="#viewBatchModal">Cancel</button>
                        <button type="submit" class="btn btn-success">Add</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <!--Script for add batch-->
    <script>
        //update wholesale cost input
        $("#addBatch-quantity").on("input", function() {
            var quantity = parseInt($(this).val());
            var retailCost = parseInt($("#addBatch-retailCost").val());

            var total = retailCost * quantity;
            //round off to 2 decimals
            total = Math.round(total * 100) / 100
            $("#addBatch-wholesaleCost").val(total);
        });
        $("#addBatch-retailCost").on("input", function() {
            var retailCost = parseInt($(this).val());
            var quantity = parseInt($("#addBatch-quantity").val());

            var total = retailCost * quantity;
            //round off to 2 decimals
            total = Math.round(total * 100) / 100
            $("#addBatch-wholesaleCost").val(total);
        });

        // update retail cost when
        $("#addBatch-wholesaleCost").on("input", function() {
            var wholesaleCost = parseInt($(this).val());
            var quantity = parseInt($("#addBatch-quantity").val());

            var total = wholesaleCost / quantity;

            //round off to 2 decimals
            total = Math.round(total * 100) / 100
            $("#addBatch-retailCost").val(total);
        });


        $("#addBatch-noExpiration").click(function() {
            if ($(this).is(":checked")) {
                $("#addBatch-expirationDate").val("");
                $("#addBatch-expirationDate").attr("readonly", true);
                $("#addBatch-expirationDate").attr("required", false);
            } else {
                $("#addBatch-expirationDate").attr("readonly", false);
                $("#addBatch-expirationDate").attr("required", true);
            }
        });
    </script>



    <!-- Repack Batch Modal -->
    <form action="invForm-repackBatch.php" method="post">
        <input type="hidden" id="repackBatch-batchId" name="batchId">

        <div class="modal fade" id="repackBatchModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog  modal-sm modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="repackBatchTitle">...</h5>
                        <button type="button" class="close" data-dismiss="modal" data-toggle="modal" data-target="#viewBatchModal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="quantity">Repack Quantity</label>
                            <input type="number" class="form-control w-75" id="repackBatch-quantity" min="1" value="1" name="quantity" required>
                            <label for="quantity">Prepared by </label>
                            <select class="form-control" id="repackedprepared_by" name="prepared_by" required>
                                        <option hidden selected disabled value>Select Name</option>
                                        <?php
                                        $preparedby = $conn->query("SELECT * FROM `user` WHERE 1 ORDER BY last_name ASC;");
                                        while ($rows = $preparedby->fetch_assoc()) {
                                            echo '
                                        <option value="' . $rows["user_id"] . '">' . $rows["last_name"] .', '. $rows["first_name"].'</option>
                                    ';
                                        }
                                        ?>
                                    </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal" data-toggle="modal" data-target="#viewBatchModal">Cancel</button>
                        <button type="submit" class="btn btn-success">Repack</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <!-- Print Barcode Modal -->
    <form action="invForm-printBarcode.php" method="post">
        <input type="hidden" id="printBarcode-productId" name="productId">
        <input type="hidden" id="printBarcode-barcode" name="barcode">
        <input type="hidden" id="printBarcode-productName" name="productName">
        <input type="hidden" id="printBarcode-price" name="price">
        <input type="hidden" id="printBarcode-expirationDate" name="expirationDate">

        <div class="modal fade" id="printBarcodeModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="printBarcodeTitle">Print Barcode</h5>
                        <button type="button" class="close" data-dismiss="modal" data-toggle="modal" data-target="#viewBatchModal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="quantity">Print Count</label>
                            <input type="number" class="form-control w-75" id="printBarcode-count" min="1" value="1" name="count" required>
                        </div>
                    </div>
                    <br>
                    <div id="printBarcode-barImage">

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal" data-toggle="modal" data-target="#viewBatchModal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Print</button>
                    </div>
                </div>
            </div>
        </div>
    </form>



    <!--Edit Batch Modal -->
    <form action="./invForm-editBatch.php" method="post">

        <input type="hidden" id="editBatch-batchId" name="batchId">

        <div class="modal fade" id="editBatchModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editBatchTitle">Edit Batch</h5>
                        <button type="button" class="close" data-dismiss="modal" data-toggle="modal" data-target="#viewBatchModal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <h6>Product</h6>
                        <span class="pl-3" id="editBatch-productName">...</span>
                        <hr>

                        <!--Quantity Row-->
                        <div class="row" id="editBatch-quantityRow">

                        </div>

                        <!--Cost and Price Row-->
                        <div class="row">
                            <div class="col">
                                <label for="editBatch-cost">Cost</label>
                                <div class="input-group">

                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1">₱</span>
                                    </div>
                                    <input type="number" step="0.01" min="0.01" class="form-control" id="editBatch-cost" name="cost" placeholder="0.00" required>
                                </div>
                            </div>
                            <div class="col">
                                <label for="editBatch-price">Price</label>
                                <div class="input-group">

                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1">₱</span>
                                    </div>
                                    <input type="number" step="0.01" min="0.01" class="form-control" id="editBatch-price" name="price" placeholder="0.00" required>
                                </div>
                            </div>
                        </div>

                        <!--Expiration Date Row-->
                        <div class="row mt-3">
                            <div class="col">
                                <div class="form-group">
                                    <label for="editBatch-quantity">Expiration Date</label>
                                    <input type="date" class="form-control" id="editBatch-expirationDate" name="expirationDate" required>
                                    <input type="checkbox" id="editBatch-noExpiration" name="noExpiration" value="1">
                                    <label for="noExpiration">Check if not applicable</label>
                                </div>

                            </div>
                            <div class="col">

                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal" data-toggle="modal" data-target="#viewBatchModal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Apply Changes</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <script>
        $("#editBatch-noExpiration").click(function() {

            if ($(this).is(":checked")) {
                $("#editBatch-expirationDate").val("");
                $("#editBatch-expirationDate").attr("readonly", true);
                $("#editBatch-expirationDate").attr("required", false);
            } else {
                $("#editBatch-expirationDate").attr("readonly", false);
                $("#editBatch-expirationDate").attr("required", true);
            }
        });
    </script>

    <!-- Archive Batch Modal -->
    <form action="invForm-archiveBatch.php" method="post">
        <input type="hidden" id="archiveBatch-batchId" name="batchId">

        <div class="modal fade" id="archiveBatchModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog  modal-sm modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="archiveBatchTitle">...</h5>
                        <button type="button" class="close" data-dismiss="modal" data-toggle="modal" data-target="#viewBatchModal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <h6 class="text-center">Are you sure you want to archive this batch</h6>
                        <div class="form-group">
                            <label for="archiveBatch-archiveRemarks">Reason</label>
                            <textarea class="form-control" id="archiveBatch-archiveRemark" name="archiveRemarks" rows="3" placeholder="Enter Archive Remarks"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal" data-toggle="modal" data-target="#viewBatchModal">Cancel</button>
                        <button type="submit" class="btn btn-danger">Archive</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <!--Promo Modal--> 
    <form action="invForm-batchPromo.php" method="post">
        <input type="hidden" id="batchpromo-batchId" name="batchId">
        <input type="hidden" id="batchpromo-productId" name="productId">

        <div class="modal fade" id="BatchpromoModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog  modal-sm modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="batchpromoTitle">...</h5>
                        <button type="button" class="close" data-dismiss="modal" data-toggle="modal" data-target="#viewBatchModal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <h6 class="text-center">Are you sure you want to include this as Promotional Items ?</h6>
                        <div class="form-group">
                            <label for="batchpromo-archiveRemarks">Reason</label>
                            <select class="form-control mb-2" name="batchpromo_select" id="batchpromo_select" required>
                                <option value="" disabled selected>-Select a Reason-</option>
                                <option value="Expired">Expired</option>
                                <option value="Damaged">Damaged</option>
                                <option value="Product Loss">Product Loss</option>
                                <option value="Other">Other</option>
                            </select>
                            <div class="row mb-2">
                                <div class="col">
                                    <label for="batchpromo-archiveRemarks">Quantity</label>
                                    <input class="form-control" min="0" name="promo_quantity" type="number" id="batchpromo-archiveQuantity">
                                </div>
                            </div>
                            <textarea class="form-control" id="batchpromo-Remark" name="batchpromo" rows="3" placeholder="Other reason"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal" data-toggle="modal" data-target="#viewBatchModal">Cancel</button>
                        <button type="submit" class="btn btn-success">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <!--batch loss-->
    <form action="invForm-batchloss.php" method="post">
        <input type="hidden" id="batchloss-batchId" name="batchId">
        <input type="hidden" id="batchloss-productId" name="productId">

        <div class="modal fade" id="BatchlossModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog  modal-sm modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="batchlossTitle">...</h5>
                        <button type="button" class="close" data-dismiss="modal" data-toggle="modal" data-target="#viewBatchModal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <h6 class="text-center">Are you sure you want to include this as batch loss ?</h6>
                        <div class="form-group">
                            <label for="batchloss-archiveRemarks">Reason</label>
                            <select class="form-control mb-2" name="batchloss_select" id="batchloss_select">
                                <option value="Expired">Expired</option>
                                <option value="Damaged">Damaged</option>
                                <option value="Product Loss">Product Loss</option>
                                <option value="Other">Other</option>
                            </select>
                            <div class="row mb-2">
                                <div class="col">
                                    <label for="batchloss-archiveRemarks">Unpacked</label>
                                    <input class="form-control" min="0" name="unpacked" type="number" id="batchloss-archiveUnpacked">
                                </div>
                                <div class="col">
                                    <label for="batchloss-archiveRemarks">Quantity</label>
                                    <input class="form-control" min="0" name="quantity" type="number" id="batchloss-archiveQuantity">
                                </div>
                            </div>
                            <textarea class="form-control" id="batchloss-Remark" name="batchloss_Remarks" rows="3" placeholder="Other reason"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal" data-toggle="modal" data-target="#viewBatchModal">Cancel</button>
                        <button type="submit" class="btn btn-danger">Archive</button>
                    </div>
                </div>
            </div>
        </div>
    </form>




    <!--Add Product Modal -->
    <form action="./invForm-addProduct.php" method="post">

        <div class="modal fade" id="addProductModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addProductTitle">Add Product</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <!--Barcode and Product Name Row-->
                        <div class="row">
                            <div class="col">
                                <label for="addProduct-quantity">Barcode</label>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" id="addProduct-barcode" name="barcode" required>
                                    <div class="input-group-append">
                                        <button type="button" class="btn btn-success" id="addProduct-generateBarcode" data-toggle="tooltip" title="Generate Barcode"><i class="fa-solid fa-gear"></i></button>
                                    </div>

                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="addProduct-quantity">Product Name</label>
                                    <input type="text" class="form-control" id="addProduct-productName" name="productName" required>
                                </div>
                            </div>
                            <div class="col">
                                <label for="addProduct-cost">Cost</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <input type="number" step="0.01" min="0.01" class="form-control" id="addProduct-wholesaleCost" name="wholesaleCost" placeholder="0.00" required>
                                        <span class="input-group-text" id="basic-addon1">=</span>
                                        <input type="number" step="0.01" min="0.01" class="form-control" id="addProduct-retailCost" name="retailCost" placeholder="0.00" required>
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col col-4">
                                        Wholesale
                                    </div>
                                    <div class="col col-2">

                                    </div>
                                    <div class="col col-5">
                                        Retail
                                    </div>
                                </div>
                            </div>
                            <div class="col">
                                <label for="addProduct-price">Unit Price</label>
                                <div class="input-group">

                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1">₱</span>
                                    </div>
                                    <input type="number" step="0.01" min="0.01" class="form-control" id="addProduct-price" name="price" placeholder="0.00" required>
                                </div>
                            </div>
                        </div>


                        <!--Category and Wholesale Unit Row-->
                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="addProduct-category">Category</label>
                                    <select class="form-control" id="addProduct-category" name="category" required>
                                        <option hidden selected disabled value>Select Category</option>
                                        <?php
                                        $ctg = $conn->query("SELECT * FROM `category`");
                                        while ($row = $ctg->fetch_assoc()) {
                                            echo '
                                        <option value="' . $row["category_id"] . '">' . $row["category_name"] . '</option>
                                    ';
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="addProduct-category">Wholesale Unit</label>
                                    <select class="form-control" id="addProduct-wholesaleUnit" name="wholesaleUnit" required>
                                        <option hidden selected disabled value>Select Unit for Wholesale</option>

                                        <?php
                                        $ctg = $conn->query("SELECT * FROM `unit_of_measurement`");
                                        while ($row = $ctg->fetch_assoc()) {
                                            echo '
                                        <option value="' . $row["unit_id"] . '">' . $row["unit_name"] . '</option>
                                    ';
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="addProduct-quantity">Expiration Date</label>
                                    <input type="date" class="form-control" id="addProduct-expirationDate" name="expirationDate" required>
                                    <input type="checkbox" id="addProduct-noExpiration" name="noExpiration" value="1">
                                    <label for="noExpiration">Check if not applicable</label>
                                </div>

                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="addProduct-warningLevel">Critical Stocks</label>
                                    <input type="number" class="form-control" id="addProduct-warningLevel" name="warningLevel" required>
                                </div>
                            </div>
                        </div>

                        <!-- Quantity and Wholesale Level -->
                        <div class="row">
                            <div class="col">
                                <label for="addProduct-quantity">Retail Quantity</label>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" id="addProduct-quantity" name="quantity" required>
                                    <div class="input-group-append">
                                        <select class="form-control" id="addProduct-retailUnit" name="retailUnit" required>
                                            <?php
                                            $ctg = $conn->query("SELECT * FROM `unit_of_measurement`");
                                            while ($row = $ctg->fetch_assoc()) {
                                                echo '
                                            <option value="' . $row["unit_id"] . '">' . $row["unit_name"] . '</option>
                                        ';
                                            }
                                            ?>
                                        </select>
                                    </div>

                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="addProduct-warningLevel">Wholesale Level</label>
                                    <input type="number" class="form-control" id="addProduct-wholesaleLevel" name="wholesaleLevel" required>
                                    <input type="checkbox" id="addProduct-noWholesale" name="noWholesale" value="2">
                                    <label for="noWholesale">Check if not applicable</label>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="addProduct-quantity">Repackable</label>
                                    <select class="form-control" id="addProduct-repackable" name="repackable" required>
                                        <option value="1">Yes</option>
                                        <option value="0" selected>No</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="addProduct-description">Description</label>
                                    <textarea class="form-control" id="addProduct-description" name="description"></textarea>
                                </div>
                            </div>
                        </div>

                        <!--Cost and Price Row
            <div class="row">
                <div class="col">
                    <label for="addProduct-cost">Cost</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <input type="number" step="0.01" min="0.01" class="form-control" id="addProduct-wholesaleCost" name="wholesaleCost" placeholder="0.00" required>
                            <span class="input-group-text" id="basic-addon1">=</span>
                            <input type="number" step="0.01" min="0.01" class="form-control" id="addProduct-retailCost" name="retailCost" placeholder="0.00" required>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col col-4">
                            Wholesale
                        </div>
                        <div class="col col-2">

                        </div>
                        <div class="col col-5">
                            Retail
                        </div>
                    </div>
                </div>
                <div class="col">
                    <label for="addProduct-price">Unit Price</label>
                    <div class="input-group">
                    
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1">₱</span>
                        </div>
                        <input type="number" step="0.01" min="0.01" class="form-control" id="addProduct-price" name="price" placeholder="0.00" required>
                    </div>
                </div>
            </div>
            -->

                        <!--Expiration Date Row
            <div class="row mt-3">
                <div class="col">
                    <div class="form-group">
                        <label for="addProduct-quantity">Expiration Date</label>
                        <input type="date" class="form-control" id="addProduct-expirationDate" name="expirationDate" required>
                        <input type="checkbox" id="addProduct-noExpiration" name="noExpiration" value="1">
                        <label for="noExpiration">Check if not applicable</label>
                    </div>
                    
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="addProduct-warningLevel">Critical Stocks</label>
                        <input type="number" class="form-control" id="addProduct-warningLevel" name="warningLevel" required>
                    </div>
                </div>
            </div>
            -->

                        <!--Repackable
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label for="addProduct-quantity">Repackable</label>
                        <select class="form-control" id="addProduct-repackable" name="repackable" required>
                            <option value="1">Yes</option>
                            <option value="0" selected>No</option>
                        </select>
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label for="addProduct-description">Description</label>
                        <textarea class="form-control" id="addProduct-description" name="description"></textarea>
                    </div>
                </div>
            </div>
            -->

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Add</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <!--Script for add product-->
    <script>
        $("#addProduct-generateBarcode").click(function() {
            $("#addProduct-generateBarcode i").animate({
                rotate: "90deg"
            });
            $("#addProduct-generateBarcode i").animate({
                rotate: "-90deg"
            });

            $.post("./ajax/barcodeGen.php",
                function(data) {
                    $("#addProduct-barcode").val(data);
                });

        });

        //update wholesale cost input
        $("#addProduct-quantity").on("input", function() {
            var quantity = parseInt($(this).val());
            var retailCost = parseInt($("#addProduct-retailCost").val());

            var total = retailCost * quantity;
            //round off to 2 decimals
            total = Math.round(total * 100) / 100
            $("#addProduct-wholesaleCost").val(total);
        });
        $("#addProduct-retailCost").on("input", function() {
            var retailCost = parseInt($(this).val());
            var quantity = parseInt($("#addProduct-quantity").val());

            var total = retailCost * quantity;
            //round off to 2 decimals
            total = Math.round(total * 100) / 100
            $("#addProduct-wholesaleCost").val(total);
        });

        // update retail cost when
        $("#addProduct-wholesaleCost").on("input", function() {
            var wholesaleCost = parseInt($(this).val());
            var quantity = parseInt($("#addProduct-quantity").val());

            var total = wholesaleCost / quantity;

            //round off to 2 decimals
            total = Math.round(total * 100) / 100
            $("#addProduct-retailCost").val(total);
        });


        $("#addProduct-noWholesale").click(function() {
            if ($(this).is(":checked")) {
                $("#addProduct-wholesaleLevel").val("");
                $("#addProduct-wholesaleLevel").attr("readonly", true);
                $("#addProduct-wholesaleLevel").attr("required", false);
                $("#addProduct-wholesaleUnit").val($("#addProduct-wholesaleUnit option:first").val());
                $("#addProduct-wholesaleUnit").attr("readonly", true);
                $("#addProduct-wholesaleUnit").attr("required", false);
            } else {
                $("#addProduct-wholesaleLevel").attr("readonly", false);
                $("#addProduct-wholesaleLevel").attr("required", true);
                $("#addProduct-wholesaleUnit").attr("readonly", false);
                $("#addProduct-wholesaleUnit").attr("required", true);
            }
        });

        $("#addProduct-noExpiration").click(function() {
            if ($(this).is(":checked")) {
                $("#addProduct-expirationDate").val("");
                $("#addProduct-expirationDate").attr("readonly", true);
                $("#addProduct-expirationDate").attr("required", false);
            } else {
                $("#addProduct-expirationDate").attr("readonly", false);
                $("#addProduct-expirationDate").attr("required", true);
            }
        });
    </script>




    <!--Edit Product Modal -->
    <form action="./invForm-editProduct.php" method="post">

        <input type="hidden" id="editProduct-productId" name="productId">
        <input type="hidden" id="editProduct-oldBarcode" name="oldBarcode">

        <div class="modal fade" id="editProductModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editProductTitle">Edit Product</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <!--Barcode and Product Name Row-->
                        <div class="row">
                            <div class="col">
                                <label for="editProduct-quantity">Barcode</label>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" id="editProduct-barcode" name="barcode" required>
                                    <div class="input-group-append">
                                        <button type="button" class="btn btn-success" id="editProduct-generateBarcode" data-toggle="tooltip" title="Generate Barcode"><i class="fa-solid fa-gear"></i></button>
                                    </div>

                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="editProduct-quantity">Product Name</label>
                                    <input type="text" class="form-control" id="editProduct-productName" name="productName" required>
                                </div>
                            </div>
                            <div class="col">
                                <label for="editProduct-cost">Cost</label>
                                <div class="input-group">

                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1">₱</span>
                                    </div>
                                    <input type="number" step="0.01" min="0.01" class="form-control" id="editProduct-cost" name="cost" placeholder="0.00" required>
                                </div>
                            </div>
                            <div class="col">
                                <label for="editProduct-price">Unit Price</label>
                                <div class="input-group">

                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1">₱</span>
                                    </div>
                                    <input type="number" step="0.01" min="0.01" class="form-control" id="editProduct-price" name="price" placeholder="0.00" required>
                                </div>
                            </div>

                        </div>


                        <!--Category and Wholesale Unit Row-->
                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label for="editProduct-category">Category</label>
                                    <select class="form-control" id="editProduct-category" name="category" required>
                                        <option hidden selected disabled value>Select Category</option>
                                        <?php
                                        $ctg = $conn->query("SELECT * FROM `category`");
                                        while ($row = $ctg->fetch_assoc()) {
                                            echo '
                                        <option value="' . $row["category_id"] . '">' . $row["category_name"] . '</option>
                                    ';
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col">
                                <label for="editProduct-wholesaleUnit">Wholesale Unit</label>
                                <select class="form-control" id="editProduct-wholesaleUnit" name="wholesaleUnit" required>
                                    <option hidden selected disabled value>Select Unit for Wholesale</option>

                                    <?php
                                    $ctg = $conn->query("SELECT * FROM `unit_of_measurement`");
                                    while ($row = $ctg->fetch_assoc()) {
                                        echo '
                                    <option value="' . $row["unit_id"] . '">' . $row["unit_name"] . '</option>
                                ';
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <div class="form-group">
                                        <label for="editProduct-warningLevel">Critical Stocks</label>
                                        <input type="text" class="form-control" id="editProduct-warningLevel" name="warningLevel" required>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <!-- Unit of Measurements -->
                        <div class="row">
                            <div class="col">
                                <label for="editProduct-retailUnit">Retail Unit</label>
                                <select class="form-control" id="editProduct-retailUnit" name="retailUnit" required>
                                    <option hidden selected disabled value>Select Unit for Retail</option>
                                    <?php
                                    $uom = $conn->query("SELECT * FROM `unit_of_measurement`");
                                    while ($row = $uom->fetch_assoc()) {
                                        echo '
                                    <option value="' . $row["unit_id"] . '">' . $row["unit_name"] . '</option>
                                ';
                                    }
                                    ?>
                                </select>

                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="editProduct-quantity">Repackable</label>
                                    <select class="form-control" id="editProduct-repackable" name="repackable" required>
                                        <option value="1">Yes</option>
                                        <option value="0" selected>No</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label for="editProduct-warningLevel">Wholesale Level</label>
                                    <input type="text" class="form-control" id="editProduct-wholesaleLevel" name="wholesaleLevel" required>
                                    <input type="checkbox" id="editProduct-noWholesale" name="noWholesale" value="2">
                                    <label for="noWholesale">Check if not applicable</label>
                                </div>
                            </div>
                            <!-- Description -->
                            <div class="col">
                                <label for="editProduct-description">Description</label>
                                <textarea class="form-control" id="editProduct-description" name="description"></textarea>
                            </div>

                        </div>
                        <!--Cost and Price Row
            <div class="row">
                <div class="col">
                    <label for="editProduct-cost">Cost</label>
                    <div class="input-group">
                    
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1">₱</span>
                        </div>
                        <input type="number" step="0.01" min="0.01" class="form-control" id="editProduct-cost" name="cost" placeholder="0.00" required>
                    </div>
                </div>
                <div class="col">
                    <label for="editProduct-price">Unit Price</label>
                    <div class="input-group">
                    
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="basic-addon1">₱</span>
                        </div>
                        <input type="number" step="0.01" min="0.01" class="form-control" id="editProduct-price" name="price" placeholder="0.00" required>
                    </div>
                </div>
             </div>
             -->

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Apply Changes</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <!--Script for edit product-->
    <script>
        $("#editProduct-generateBarcode").click(function() {
            $("#editProduct-generateBarcode i").animate({
                rotate: "90deg"
            });
            $("#editProduct-generateBarcode i").animate({
                rotate: "-90deg"
            });

            $.post("./ajax/barcodeGen.php",
                function(data) {
                    $("#editProduct-barcode").val(data);
                });

        });


        $("#editProduct-noWholesale").click(function() {
            if ($(this).is(":checked")) {
                $("#editProduct-wholesaleLevel").val("");
                $("#editProduct-wholesaleLevel").attr("readonly", true);
                $("#editProduct-wholesaleLevel").attr("required", false);
                $("#editProduct-wholesaleUnit").val($("#editProduct-wholesaleUnit option:first").val());
                $("#editProduct-wholesaleUnit").attr("readonly", true);
                $("#editProduct-wholesaleUnit").attr("required", false);
            } else {
                $("#editProduct-wholesaleLevel").attr("readonly", false);
                $("#editProduct-wholesaleLevel").attr("required", true);
                $("#editProduct-wholesaleUnit").attr("readonly", false);
                $("#editProduct-wholesaleUnit").attr("required", true);
            }
        });

        $("#editProduct-noExpiration").click(function() {
            if ($(this).is(":checked")) {
                $("#editProduct-expirationDate").val("");
                $("#editProduct-expirationDate").attr("readonly", true);
                $("#editProduct-expirationDate").attr("required", false);
            } else {
                $("#editProduct-expirationDate").attr("readonly", false);
                $("#editProduct-expirationDate").attr("required", true);
            }
        });
    </script>


    <!-- Archive Product Modal -->
    <form action="invForm-archiveProduct.php" method="post">
        <input type="hidden" id="archiveProduct-productId" name="productId">

        <div class="modal fade" id="archiveProductModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog  modal-sm modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="archiveProductTitle">...</h5>
                        <button type="button" class="close" data-dismiss="modal">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <h6 class="text-center">Are you sure you want to archive this product</h6>
                        <div class="form-group">
                            <label for="archiveProduct-archiveRemarks">Reason</label>
                            <textarea class="form-control" id="archiveProduct-archiveRemark" name="archiveRemarks" rows="3" placeholder="Enter reason for archiving batch"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger">Archive</button>
                    </div>
                </div>
            </div>
        </div>
    </form>


    <!-- Sort Table Modal -->
    <form action="inv-productList.php" method="get">
        <div class="modal fade" id="sortTableModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Sort By</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <label for="sortColumn">Column</label>
                        <select class="form-control" name="orderColumn" id="sortColumn">
                            <option value="product_name" <?= (isset($_GET["orderColumn"]) and $_GET["orderColumn"] == "product_name") ? "selected" : "" ?>>Product Name</option>
                            <option value="stocks" <?= (isset($_GET["orderColumn"]) and $_GET["orderColumn"] == "stocks") ? "selected" : "" ?>>Stock</option>
                            <option value="cost" <?= (isset($_GET["orderColumn"]) and $_GET["orderColumn"] == "cost") ? "selected" : "" ?>>Cost</option>
                            <option value="price" <?= (isset($_GET["orderColumn"]) and $_GET["orderColumn"] == "price") ? "selected" : "" ?>>Price</option>
                            <option value="stock_status" <?= (isset($_GET["orderColumn"]) and $_GET["orderColumn"] == "stock_status") ? "selected" : "" ?>>Status</option>
                        </select>
                        <br>
                        <label for="sortDirection">Sort Direction</label>
                        <select class="form-control" name="orderDirection" id="sortDirection">
                            <option value="ASC" <?= (isset($_GET["orderDirection"]) and $_GET["orderDirection"] == "ASC") ? "selected" : "" ?>>Ascending</option>
                            <option value="DESC" <?= (isset($_GET["orderDirection"]) and $_GET["orderDirection"] == "DESC") ? "selected" : "" ?>>Descending</option>
                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Apply</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <!--Main Script-->
    <script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
    <script src="./js/preventKeydown.js"></script>
    <script>
        $("textarea").keydown(function(e) {
            // Enter was pressed without shift key
            if (e.keyCode == 13 && !e.shiftKey) {
                // prevent default behavior
                e.preventDefault();
            }
        });

        $("input").keydown(function(e) {
            // Enter was pressed without shift key
            if (e.keyCode == 220) {
                // prevent default behavior
                e.preventDefault();
            }
        });

        $('#tbodyProducts [data-toggle="tooltip"]').tooltip({
            animated: 'fade',
            placement: 'bottom',
            html: true
        });


        /* initializate the tooltips after ajax requests, if not already done */
        $(document).ajaxComplete(function(event, request, settings) {
            $('[data-toggle="tooltip"]').not('[data-original-title]').tooltip();
        });
    </script>
</body>

</html>