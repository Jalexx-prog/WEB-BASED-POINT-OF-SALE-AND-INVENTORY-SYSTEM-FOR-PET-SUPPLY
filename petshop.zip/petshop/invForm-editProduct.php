<?php
try{
    session_start();
    include("./includes/connection.php");
    include('./includes/log_check.php');
    include("./includes/barcodeImageGen.php");
    include ('./includes/checkRole.php');
    
    date_default_timezone_set('Asia/Manila');
    $user = $_SESSION["user_id"];
    $date = date("Y-m-d H-i-s");

    if($_SERVER["REQUEST_METHOD"] === "POST"){
        $productId = $_POST["productId"];
        $oldBarcode = $_POST["oldBarcode"];
        $barcode = $_POST["barcode"];
        $productName = $_POST["productName"];
        $category = $_POST["category"];
        $wholesaleUnit = isset($_POST["wholesaleUnit"]) ? $_POST["wholesaleUnit"] : 0;
        $retailUnit = $_POST["retailUnit"];
        $repackable = $_POST["repackable"];
        $cost = $_POST["cost"];
        $price = $_POST["price"];
        $warningLevel = $_POST["warningLevel"];
        $wholesaleLevel = $_POST["wholesaleLevel"] !== "" ? $_POST["wholesaleLevel"] : 1;
        $description = $_POST["description"];
        
        $checkBarcode = $conn->query("SELECT `barcode` FROM `products` WHERE `barcode` != '$oldBarcode' AND `barcode` = '$barcode'");
        if($checkBarcode->num_rows == 0){
            $conn->query("
                UPDATE `products` 
                SET 
                    `barcode`='$barcode',
                    `product_name`='$productName',
                    `category_id`='$category',
                    `repackable`='$repackable',
                    `retail_unit`='$retailUnit',
                    `wholesale_unit`='$wholesaleUnit',
                    `cost`='$cost',
                    `price`='$price',
                    `description`='$description',
                    `warning_level`='$warningLevel',
                    `wholesale_level`='$wholesaleLevel'
                WHERE `product_id` = '$productId'
            ");
            
            //generate image of barcode
            generateBarcodeImg($productId, $barcode);

            include("./includes/updateProductStatus.php");
            include("./includes/updateExpirationStatus.php");
            
            $_SESSION["message"] = "product-edited";
            header("location: ./inv-productList.php");
            exit();
        }
        else{   //runs if the barcode is already in use
            $_SESSION["message"] = "barcode-exist";
            header("location: ./inv-productList.php");
            exit();
        }
        


    }
    else{   //runs if there are no POST method
        $_SESSION["message"] = "error";
        header("location: ./inv-productList.php");
        exit();


    }
}
catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    echo $e;
    header("location: ./inv-productList.php");
    exit();
}
?>