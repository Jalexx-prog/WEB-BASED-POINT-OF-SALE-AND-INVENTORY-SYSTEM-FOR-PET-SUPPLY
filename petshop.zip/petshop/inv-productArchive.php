<?php
session_start();

date_default_timezone_set('Asia/Manila');
include("./includes/connection.php");
include('./includes/log_check.php');
include('./includes/checkRole.php');

$logo = $conn->query("SELECT `logo` FROM `system`")->fetch_assoc()["logo"];


$condition = '`archive_status` = 1';
$order = (isset($_GET["orderColumn"]) and isset($_GET["orderDirection"])) ? "ORDER BY `" . $_GET["orderColumn"] . "` " . $_GET["orderDirection"] : "ORDER BY `product_name` ASC";
$limit = 10;
$search = isset($_GET["search"]) ? $_GET["search"] : '';
$page = isset($_GET["page"]) ? $_GET["page"] : 1;

if (isset($_GET["search"]) and $_GET["search"] !== "") {
    $condition .= " AND `barcode` = '$search' OR `product_name` LIKE '%$search%'";
}

//makes a hidden form for all GET methods
//needed for pagination so that the GET value stays after switching pages
$searchForm = isset($_GET["search"]) ?
    '<input type="hidden" name="search" value="' . $_GET["search"] . '">' :
    "";

//concatenate all GET forms
$forms = $searchForm;

$query = "
        SELECT 
            `products`.`product_id`, 
            `products`.`barcode`, 
            `products`.`product_name`, 
            `products`.`category_id`, 
            `category`.`category_name`,
            `products`.`repackable`,
            IFNULL(
                (SELECT (SUM(`unpacked_quantity`) + SUM(`batch`.`quantity`)) FROM `batch` WHERE `batch`.`product_id` = `products`.`product_id` AND `batch`.`archive_status` = 1), 
                0
            ) AS `stocks`,
            `products`.`retail_unit` AS `retail_unit_id`,
            `products`.`wholesale_unit` AS `wholesale_unit_id`,
            IFNULL((SELECT `unit_of_measurement`.`unit_name` FROM `unit_of_measurement` WHERE `unit_of_measurement`.`unit_id` = `products`.`retail_unit`), '') AS `retail_unit`,
            IFNULL((SELECT `unit_of_measurement`.`unit_name` FROM `unit_of_measurement` WHERE `unit_of_measurement`.`unit_id` = `products`.`wholesale_unit`), '') AS `wholesale_unit`,
            `products`.`cost`, 
            `products`.`price`, 
            `products`.`description`, 
            `products`.`warning_level`, 
            `products`.`wholesale_level`,
            `products`.`archive_remarks`, 
            `products`.`stock_status`, 
            `products`.`date_archived`,
            `products`.`date_created`, 
            `user`.`username` AS `archived_by`,
            (SELECT COUNT(*) FROM `batch` WHERE `batch`.`product_id` = `products`.`product_id` AND `batch`.`archive_status` = 1) AS `batch_count`,
            (SELECT MAX(`expiration_status`) FROM `batch` WHERE `batch`.`product_id` = `products`.`product_id`) AS `expiration_status`,
            `products`.`archive_status`
        FROM `products` 
            INNER JOIN `category` ON `products`.`category_id` = `category`.`category_id`
            INNER JOIN `user` ON `products`.`archived_by` = `user`.`user_id`
        WHERE $condition
    ";

$pageLocation = "./inv-productArchive.php";
include("./includes/pagination.php");


//execute the sql query for getting the table of products 
$result = $conn->query("
        $query
        $order
        LIMIT $limit OFFSET $offset;
    ");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--Bootstrap-->
    <link rel="stylesheet" href="./bootstrap/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <script src="./bootstrap/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

    <!--Jquery-->
    <script src="./js/jquery_3.6.4_jquery.min.js"></script>

    <script src="./bootstrap//popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip();
        })
    </script>

    <!--Fontawesome-->
    <link rel="stylesheet" href="./fontawesome/css/all.min.css">

    <!--CSS-->
    <link rel="stylesheet" href="./css/styles.css">
    <link rel="stylesheet" href="./css/inventory.css">

    <link rel="icon" type="image/png" href="./assets/<?php echo $logo ?>" />
    <title>Inventory</title>
</head>

<body>
    <?php
    include("./includes/navbar.php");
    ?>


    <div class="container main-div py-4" id="main-div">
        <h3>List of Archive</h3>
        <!--Table section-->
        <section class="productTableSection mt-5" id="productTableSection">
            <!--Buttons row-->
            <div class="row mb-3 d-flex flex-row-reverse">

                <!--&emsp;
                <button type="button" class="btn btn-outline-primary"><i class="fa-solid fa-filter"></i></button>-->
                &emsp;

                <?= (isset($_GET["search"]) or (isset($_GET["orderColumn"]) and isset($_GET["orderDirection"]))) ? '
                    &emsp;
                    <a href="./inv-productArchive.php" class="btn btn-outline-secondary"><i class="fa-solid fa-rotate-left"></i></a>
                ' :
                    '' ?>

            </div>

            <!--Table row-->
            <strong>
                <p>Product Items</p>
            </strong>
            <div class="row productTableRow" style="max-height: 400px; overflow-y:auto;">
                <table class="table productTable" id="productTable">
                    <thead>
                        <th class="text-center"></th>
                        <th class="text-center">#</th>
                        <th class="text-center">BARCODE</th>
                        <th class="text-center">PRODUCT NAME</th>
                        <th class="text-center">CATEGORY</th>
                        <th class="text-center">STOCKS</th>
                        <th class="text-center">UNIT COST</th>
                        <th class="text-center">UNIT PRICE</th>
                        <th class="text-center">STATUS</th>
                        <th class="text-center"></th>

                    </thead>
                    <tbody id="tbodyProducts">
                        <?php
                        if ($result->num_rows > 0) {
                            //the row number
                            $rowcount = $offset + 1;

                            while ($row = $result->fetch_assoc()) {

                                $id = $row["product_id"];
                                $barcode = $row["barcode"];
                                $productName = wordwrap($row["product_name"], 30, "<br>\n");
                                $categoryId = $row["category_id"];
                                $category = $row["category_name"];

                                $stocks = $row["stocks"];
                                $retailUnitId = $row["retail_unit_id"];
                                $wholesaleUnitId = $row["wholesale_unit_id"];
                                $retailUnit = $row["retail_unit"];
                                $wholesaleUnit = $row["wholesale_unit"];
                                $cost = $row["cost"];
                                $price = $row["price"];
                                $warningLevel = $row["warning_level"];
                                $wholesaleLevel = $row["wholesale_level"];
                                $description = $row["description"];
                                $remarks = $row["archive_remarks"];
                                $stockStatus = $row["stock_status"];
                                $dateCreated = date("M d, Y", strtotime($row["date_created"]));
                                $timeCreated = date("h:i a", strtotime($row["date_created"]));
                                $archivedBy = $row["archived_by"];
                                $dateArchived = date("M d, Y", strtotime($row["date_archived"]));
                                $timeArchived = date("h:i a", strtotime($row["date_archived"]));

                                $statusBadge = "";

                                $prod_details = $description == '' ? '<a href="#" class="badge badge-light">N/A</a>' : $description;
                                $prod_archive = $remarks == '' ? '<a href="#" class="badge badge-light">N/A</a>' : $remarks;

                                if ($stockStatus == 1) {
                                    $statusBadge = '<a href="#" class="badge badge-light">In Stock</a>';
                                } elseif ($stockStatus == 2) {
                                    $statusBadge = '<a href="#" class="badge badge-danger">Critical</a>';
                                } elseif ($stockStatus == 3) {
                                    $statusBadge = '<a href="#" class="badge badge-dark">Out of Stock</a>';
                                }

                                $repackable = $row["repackable"];
                                $repackableBadge = "";
                                if ($repackable == 1) {
                                    $repackableBadge = '<span class="badge badge-info repack-badge">● Repack</span>';
                                }


                                echo '
                                        <tr class="main-row">
                                            <td class="text-center">
                                                <a class="text-store-brown" data-toggle="collapse" href="#inner-row-' . $id . '" role="button">
                                                    <i class="fa-solid fa-plus"></i>
                                                </a>
                                            </td>
                                            <th class="text-center">' . $rowcount . '</th>
                                            <td class="text-center">
                                                <a href="#" class="text-dark" data-toggle="tooltip" 
                                                    title="
                                                        <img class=\'bg-white px-3 py-2\' src=\'./barcode/barcode_' . $id . '.png\'?t=' . time() . '>
                                                    ">
                                                    ' . $barcode . '
                                                </a>
                                            </td>
                                            <td>' . $productName . '&emsp;' . $repackableBadge . '</td>
                                            <td class="text-center">' . $category . '</td>
                                            <td class="text-center">' . $stocks . ' ' . $retailUnit . '</td>
                                            <td class="text-center">₱ ' . number_format($cost, 2) . '</td>
                                            <td class="text-center">₱ ' . number_format($price, 2) . '</td>
                                            <td class="text-center">' . $statusBadge . '</td>
                                            <td class="text-center">
                                                <div class="dropdown show">
                                                <form action="invForm-restoreProduct.php" method="post" id="restoreProductForm-' . $id . '">
                                                <input type="hidden" name="productId" value="' . $id . '">
                                                <a href="#" class="btn btn-light restore-product-btn" data-toggle="tooltip" data-placement="top" title="Restore Product" data-product-id="' . $id . '"><i class="fa-solid fa-arrows-rotate"></i></a>
                                            </form>
                                                
                                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                        <a id="archiveProduct-' . $id . '" class="dropdown-item" href="#" data-toggle="modal" data-target="#archiveProductModal">Restore Product</a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr class="inner-row">
                                            <td colspan="10">
                                                <div class="collapse" id="inner-row-' . $id . '">
                                                    <div class="ml-5 p-3">
                                                        <h5>Additional Details</h5>
                                                        <hr>
                                                        <div class="row">
                                                            <div class="col col-md-3">
                                                                <h6>Warning Level</h6>
                                                                <p>&emsp;● ' . $warningLevel . ' ' . $retailUnit . '</p>
                                                                <br>
                                                                <h6>Wholesale Level</h6>
                                                                <p>&emsp;● ' . ($wholesaleLevel > 1 ? $wholesaleLevel . ' ' . $retailUnit : "N/A") . '</p>
                                                                <br>
                                                                <h6>Wholesale Unit</h6>
                                                                <p>&emsp;● ' . ($wholesaleUnit !== "" ? $wholesaleUnit : "N/A") . '</p>
                                                            </div>
                                                            <div class="col col-md-4">
                                                                <h6>Barcode Image</h6>
                                                                &emsp;<img src="./barcode/barcode_' . $id . '.png?t=' . time() . '" style="height: 40px">
                                                                <br><br>
                                                                <h6>Product Description</h6>
                                                                <p>&emsp;● ' . $prod_details . '</p>
                                                                <br>
                                                                <h6>Archive Remarks</h6>
                                                                <p>&emsp;● ' .  $prod_archive . '</p>
                                                                <br>
                                                                <h6>Date Archived</h6>
                                                                <p>&emsp;● ' . $dateArchived . '</p>
                                                                
                                                            </div>
                                                            <div class="col col-md-3">
                                                                <h6>Date Created</h6>
                                                                <p>&emsp;● ' . $dateCreated . '</p>
                                                                <br>
                                                                <h6>Time Created</h6>
                                                                <p>&emsp;● ' . $timeCreated . '</p>
                                                                <br>
                                                                <h6>Archived By</h6>
                                                                <p>&emsp;● ' . $archivedBy . '</p>
                                                                <br>
                                                                <h6>Time Archived</h6>
                                                                <p>&emsp;● ' . $timeArchived . '</p>
                                                            </div>
                                                            
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                            </td>
                                        </tr>
                                    ';

                                //script for action buttons
                                echo '
                                        <script>
                                            $("#viewBatch-' . $id . '").click(function(){
                                                $.post(
                                                    "./ajax/getBatch.php", 
                                                    {
                                                        productId: "' . $id . '",
                                                        barcode: "' . $barcode . '",
                                                        productName: "' . $productName . '",
                                                        retailUnit: "' . $retailUnit . '",
                                                        wholesaleUnit: "' . $wholesaleUnit . '",
                                                        repackable: "' . $repackable . '",
                                                        baseCost: "' . $cost . '",
                                                        basePrice: "' . $price . '"
                                                    }, 
                                                    function(result){
                                                        $("#viewBatchTitle").html("' . $productName . ' Batches");
                                                        $("#batchTableRow").html(result);
                                                    }
                                                ); 
                                            });

                                            $("#editProduct-' . $id . '").click(function(){
                                                $("#editProduct-productId").val("' . $id . '");
                                                $("#editProduct-oldBarcode").val("' . $barcode . '");
                                                $("#editProduct-barcode").val("' . $barcode . '");
                                                $("#editProduct-productName").val("' . $productName . '");
                                                $("#editProduct-category").val("' . $categoryId . '");
                                                $("#editProduct-warningLevel").val("' . $warningLevel . '");
                                                $("#editProduct-cost").val("' . $cost . '");
                                                $("#editProduct-price").val("' . $price . '");
                                                $("#editProduct-retailUnit").val("' . $retailUnitId . '");
                                                $("#editProduct-repackable").val("' . $repackable . '");
                                                $("#editProduct-desciption").val("' . $description . '");
                                                ' . (
                                    ($wholesaleLevel > 1 and $wholesaleUnitId > 0) ?
                                    '
                                                        $("#editProduct-wholesaleLevel").val("' . $wholesaleLevel . '");
                                                        $("#editProduct-wholesaleUnit").val("' . $wholesaleUnitId . '");
                                                        $("#editProduct-wholesaleLevel").attr("readonly", false);
                                                        $("#editProduct-wholesaleUnit").attr("readonly", false);
                                                        $("#editProduct-noWholesale").prop("checked", false);
                                                    '
                                    :
                                    '
                                                        $("#editProduct-wholesaleLevel").val("");
                                                        $("#editProduct-wholesaleUnit").val("");
                                                        $("#editProduct-wholesaleLevel").attr("readonly", true);
                                                        $("#editProduct-wholesaleUnit").attr("readonly", true);
                                                        $("#editProduct-noWholesale").prop("checked", true);
                                                    '
                                ) . '
                                            });

                                            $("#archiveProduct-' . $id . '").click(function(){
                                                $("#archiveProduct-productId").val("' . $id . '");
                                                $("#archiveProductTitle").html("Restore ' . $productName . '");
                                            });
                                        </script>
                                    ';


                                $rowcount++;
                            }
                        } else { //if there are no products to show
                            echo '
                                    <tr>
                                        <td colspan="10" class="text-center" style="height: 200px; vertical-align: middle">No Result</td>
                                    </tr>
                                ';
                        }
                        ?>
                    </tbody>
                </table>
                <?= $pageCount > 1 ? '<p>Page ' . $page . ' out of ' . $pageCount . ' pages</p>' : '' ?>
            </div>
        </section>

        <?= $pagination ?>

        <!--repacked table-->
        <section class="productTableSection mt-5" id="productTableSection">
            <strong>
                <p>Repackable batch</p>
            </strong>
            <div class="row productTableRow">
                <table class="table productTable" id="productTable">
                    <thead>
                        <th class="text-center">#</th>
                        <th class="text-center">ID</th>
                        <th class="text-center">PRODUCT NAME</th>
                        <th class="text-center">UNPACKED</th>
                        <th class="text-center">REPACKED</th>
                        <th class="text-center">(₱)UNIT COST</th>
                        <th class="text-center">(₱)UNIT PRICE</th>
                        <th class="text-center">ARCHIVE REMARKS</th>
                        <th class="text-center">DATE ARCHIVED</th>
                        <th class="text-center">ARCHIVE BY</th>
                        <th class="text-center">EXPIRATION DATE</th>
                        <th></th>
                    </thead>
                    <tbody>
                        <?php
                        $repackable_sql = "SELECT 
    products.product_id,
    products.product_name,
    batch.unpacked_quantity,
    batch.quantity,
    products.stock_status,
    products.price,
    products.repackable,
    (SELECT unit_name FROM unit_of_measurement WHERE products.retail_unit = unit_id) AS retail_unit,
    batch.unpacked_quantity,
    batch.expiration_date,
    batch.quantity,
    batch.batch_id,
    batch.archive_remarks,
    batch.cost,
    batch.expiration_status,
    batch.date_archived,
    `user`.`username` AS `archived_by`
    FROM batch
    INNER JOIN `user` ON `batch`.`archived_by` = `user`.`user_id`
    INNER JOIN products ON batch.product_id = products.product_id
    WHERE batch.archive_status = 1 AND products.repackable = 1
    GROUP BY batch.batch_id
    ORDER BY products.product_name ASC
";
                        $repackable_res = $conn->query($repackable_sql);

                        if ($repackable_res->num_rows > 0) {
                            $count = 1;

                            while ($repack_row = $repackable_res->fetch_assoc()) {
                                $expirationStatus = $repack_row["expiration_status"];
                                $expirationDate = $repack_row["expiration_date"];
                                $DateArchived = date("M d, Y", strtotime($repack_row["date_archived"]));
                                $TimeArchived = date("h:i a", strtotime($repack_row["date_archived"]));

                                if ($expirationStatus == 0) {
                                    $expBadge = '<a href="#" class="badge badge-light">N/A</a>';
                                } elseif ($expirationStatus == 1) {
                                    $expBadge = '<a href="#" class="badge badge-success" data-toggle="tooltip" title="Good">' . $expirationDate . '</a>';
                                } elseif ($expirationStatus == 2) {
                                    $expBadge = '<a href="#" class="badge badge-warning" data-toggle="tooltip" title="Neary Expired">' . $expirationDate . '</a>';
                                } elseif ($expirationStatus == 3) {
                                    $expBadge = '<a href="#" class="badge badge-danger" data-toggle="tooltip" title="Expired">' . $expirationDate . '</a>';
                                }

                                $archive_marks = $repack_row["archive_remarks"] == ''  ? '<a href="#" class="badge badge-light">N/A</a>' : $repack_row["archive_remarks"];
                                echo "
    <tr>
        <td class='text-center'>$count</td>
        <td class='text-center'>$repack_row[batch_id]</td>
        <td class='text-center'>$repack_row[product_name] <span class='badge badge-info repack-badge'>● Repack</span></td>
        <td class='text-center'>$repack_row[unpacked_quantity] $repack_row[retail_unit]</td>
        <td class='text-center'>$repack_row[quantity] $repack_row[retail_unit]</td>
        <td class='text-center'>" . number_format($repack_row["cost"], 2) . "</td>
        <td class='text-center'>" . number_format($repack_row["price"], 2) . "</td>
        <td class='text-center'>$archive_marks</td>
        <td class='text-center'>$DateArchived<br>$TimeArchived</td>
        <td class='text-center'>$repack_row[archived_by]</td>
        <td class='text-center'>$expBadge</td>
        <td class='text-center'> 
            <div class='dropdown'>
        <form action='invForm-restoreBatch.php' method='post' id='restoreBatchForm-$repack_row[batch_id]'>
            <input type='hidden' name='batchId' value='$repack_row[batch_id]'>
            <a href='#' class='btn btn-light restore-batch-btn' data-toggle='tooltip' data-placement='top' title='Restore Batch' data-batch-id='$repack_row[batch_id]'><i class='fa-solid fa-arrows-rotate'></i></a>
        </form>
 
            </div>
        </td>
    </tr>
";

                                $count++;
                            }
                        } else {
                            echo '<tr><td colspan="10" class="text-center" style="height: 200px; vertical-align: middle">No Result</td></tr>';
                        }

                        ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="productTableSection mt-5" id="productTableSection">
            <strong>
                <p>Normal batch</p>
            </strong>
        </section>
        <div class="row productTableRow">
            <table class="table productTable" id="productTable">
                <thead>
                    <th class="text-center">#</th>
                    <th class="text-center">ID</th>
                    <th class="text-center">PRODUCT NAME</th>
                    <th class="text-center">QUANTITY</th>
                    <th class="text-center">(₱)UNIT COST</th>
                    <th class="text-center">(₱)UNIT PRICE</th>
                    <th class="text-center">ARCHIVE REMARKS</th>
                    <th class="text-center">DATE ARCHIVED</th>
                    <th class="text-center">ARCHIVED BY</th>
                    <th class="text-center">EXPIRATION DATE</th>
                    <th></th>
                </thead>
                <tbody>
                    <?php
                    $retail_sql = "SELECT 
                        products.product_id,
                        products.product_name,
                        batch.unpacked_quantity,
                        batch.quantity,
                        products.stock_status,
                        products.price,
                        products.repackable,
                        (SELECT unit_name FROM unit_of_measurement WHERE products.retail_unit = unit_id) AS retail_unit,
                        batch.unpacked_quantity,
                        batch.expiration_date,
                        batch.quantity,
                        batch.batch_id,
                        batch.archive_remarks,
                        batch.cost,
                        batch.expiration_status,
                        batch.date_archived,
                        batch.archived_by,
                        `user`.`username` AS `archived_by`
                        FROM batch
                        INNER JOIN `user` ON `batch`.`archived_by` = `user`.`user_id`
                        INNER JOIN products ON batch.product_id = products.product_id
                        WHERE batch.archive_status = 1 AND products.repackable = 0
                        GROUP BY batch.batch_id
                        ORDER BY products.product_name ASC
                        ";
                    $retail_res = $conn->query($retail_sql);

                    if ($retail_res->num_rows > 0) {
                        $row_count = 1;
                        $expbadge = "";
                        while ($Normalrow = $retail_res->fetch_assoc()) {
                            $expstat = $Normalrow["expiration_status"];
                            $expdate = $Normalrow["expiration_date"];
                            $DateArchivedd = date("M d, Y", strtotime($Normalrow["date_archived"]));
                            $TimeArchivedd = date("h:i a", strtotime($Normalrow["date_archived"]));

                            $arc_remarks = $Normalrow["archive_remarks"] == '' ? '<a href="#" class="badge badge-light">N/A</a>' : $Normalrow["archive_remarks"];

                            if ($expstat == 0) {
                                $expBadge = '<a href="#" class="badge badge-light">N/A</a>';
                            } elseif ($expstat == 1) {
                                $expBadge = '<a href="#" class="badge badge-success" data-toggle="tooltip" title="Good">' . $expdate . '</a>';
                            } elseif ($expstat == 2) {
                                $expBadge = '<a href="#" class="badge badge-warning" data-toggle="tooltip" title="Neary Expired">' . $expdate . '</a>';
                            } elseif ($expstat == 3) {
                                $expBadge = '<a href="#" class="badge badge-danger" data-toggle="tooltip" title="Expired">' . $expdate . '</a>';
                            }
                            echo "
                            <tr>
                                <td class='text-center'>$row_count</td>
                                <td class='text-center'>$Normalrow[batch_id]</td>
                                <td class='text-center'>$Normalrow[product_name]</td>
                                <td class='text-center'>$Normalrow[quantity] $Normalrow[retail_unit]</td>
                                <td class='text-center'>" . number_format($Normalrow["cost"], 2) . "</td>
                                <td class='text-center'>" . number_format($Normalrow["price"], 2) . "</td>
                                <td class='text-center'>$arc_remarks</td>
                                <td class='text-center'>$DateArchivedd</br>$TimeArchivedd</td>
                                <td class='text-center'>$Normalrow[archived_by]</td>
                                <td class='text-center'>$expBadge</td>
                                <td class='text-center'>
                                     <form action='invForm-restoreBatch.php' method='post' id='restoreBatchForm-$Normalrow[batch_id]'>
                                <input type='hidden' name='batchId' value='$Normalrow[batch_id]'>
                                <a href='#' class='btn btn-light restore-batch-btn' data-toggle='tooltip' data-placement='top' title='Restore Batch' data-batch-id='$Normalrow[batch_id]'><i class='fa-solid fa-arrows-rotate'></i></a>
                                      </form>
                                    </td>
                            </tr>
                            
                            ";
                            $row_count++;
                        }
                    } else {
                        echo '<tr><td colspan="10" class="text-center" style="height: 200px; vertical-align: middle">No Result</td></tr>';
                    }

                    ?>
                </tbody>
            </table>
        </div>

        <!--promo table-->
        <section class="productTableSection mt-5" id="productTableSection">
            <strong>
                <p>Promotional Batches</p>
            </strong>
        </section>
        <div class="row productTableRow">
            <table class="table productTable" id="productTable">
                <thead>
                <th class='text-center'>#</th>
                <th class='text-center'>BATCH ID</th>
                <th class='text-center'>PRODUCT NAME</th>
                <th class='text-center'>STOCKS</th>
                <th class='text-center'>EXPIRE DATE</th>
                <th class='text-center'>REMARKS</th>
                <th class='text-center'>ACTION</th>
                </thead>
            <tbody>
                <?php

$sql2 = "SELECT
`batch`.`batch_id`,
`batch`.`expiration_status`,
`batch`.`expiration_date`,
`promo_product`.`prd_promo_id`,
`promo_product`.`quantity_promo`,
`promo_product`.`remarks`,
`products`.`product_name`,
`promo_product`.`archive_status`,
`promo_product`.`archive_date`,
SUM(`promo_product`.`quantity_promo`) AS total_batch,
(SELECT unit_name FROM unit_of_measurement WHERE products.retail_unit = unit_id) AS retail_unit,
`user`.`username` AS `archived_by`
FROM `promo_product`
INNER JOIN `user` ON `promo_product`.`archive_by` = `user`.`user_id`
INNER JOIN `products` ON `promo_product`.`product_id` = `products`.`product_id`
INNER JOIN `batch` ON `promo_product`.`batch_id` = `batch`.`batch_id`
WHERE `promo_product`.`archive_status` = 1
GROUP BY `promo_product`.`prd_promo_id`
ORDER BY `products`.`product_name` ASC
";
$result2 = $conn->query($sql2);

                $count2 = 1;
                while ($row2 = $result2->fetch_assoc()) {
                    $expirationStatus2 = $row2["expiration_status"];
                    $expirationDate2 = $row2["expiration_date"];

                    $statusBadge = "";
                    if ($expirationStatus2 == 0) {
                        $statusBadge2 = '<a href="#" class="badge badge-light">N/A</a>';
                    } elseif ($expirationStatus2 == 1) {
                        $statusBadge2 = '<a href="#" class="badge badge-success" data-toggle="tooltip" title="Good">' . $expirationDate2 . '</a>';
                    } elseif ($expirationStatus2 == 2) {
                        $statusBadge2 = '<a href="#" class="badge badge-warning" data-toggle="tooltip" title="Neary Expired">' . $expirationDate2 . '</a>';
                    } elseif ($expirationStatus2 == 3) {
                        $statusBadge2 = '<a href="#" class="badge badge-danger" data-toggle="tooltip" title="Expired">' . $expirationDate2 . '</a>';
                    }

                    //$remarks = $row["remarks"] == "" ? '<a href="#" class="badge badge-light" data-toggle="tooltip" title="Not Applicable">N/A</a>' : $row["remarks"];

                    if ($row2["remarks"] == "") {
                        $badge2 = '<a href="#" class="badge badge-light" data-toggle="tooltip" title="Not Applicable">N/A</a>';
                    } else {
                        $badge2 = $row2["remarks"];
                    }

                    echo "
                        <tr>
                        <td class='text-center'>$count2</td>
                        <td class='text-center'>$row2[batch_id]</td>
                        <td>$row2[product_name]</td>
                        <td class='text-center'>$row2[total_batch] $row2[retail_unit]</td>
                        <td class='text-center'>$statusBadge2</td>
                        <td class='text-center'>$badge2</td>
                        <td class='text-center'>

                        <form action='invForm-restoreBatch.php' method='POST' id='restorepromoForm-$row2[prd_promo_id]'>
                        <a href='#' class='btn btn-light restore-promo-btn' data-toggle='tooltip' data-placement='top' title='Restore Batch'
                        data-prd-promo='$row2[prd_promo_id]'
                        data-batch-id='$row2[batch_id]'><i class='fa-solid fa-arrows-rotate'></i></a>
                        <input type='hidden' name='promo_ID' value='$row2[prd_promo_id]'>
                        <input type='hidden' name='archive_status' value='$row2[archive_status]'> 
                        </form>
                        </td>
                        </tr>

                ";
                    $count2++;
                }
                ?>
            </tbody>
            </table>
            <?php
            if ($result2 ->num_rows > 0) {
            } else {
                echo '
    <div class="container-fluid">
    <p class="text-center mt-5">No Result</p>
      </div>';
            }
            ?>
        </div>


        <!--batch loss table-->
        <section class="productTableSection mt-5" id="productTableSection">
            <strong>
                <p>Batch Loss</p>
            </strong>
        </section>
        <div class="row productTableRow">
            <table class="table productTable" id="productTable">
                <thead>
                    <th class="text-center">#</th>
                    <th class="text-center">ID</th>
                    <th class="text-center">PRODUCT NAME</th>
                    <th class="text-center">STOCKS</th>
                    <th class="text-center">(₱)UNIT COST</th>
                    <th class="text-center">ARCHIVE REMARKS</th>
                    <th class="text-center">DATE ARCHIVED</th>
                    <th class="text-center">ARCHIVE BY</th>
                    <th class="text-center"></th>
                </thead>
                <tbody>
                    <?php
                    $batch_lossSQL = "SELECT
                        `batch`.`batch_id`,
                        `batch_loss`.`id`,
                        `batch_loss`.`unpacked_loss`,
                        `batch_loss`.`quantity_loss`,
                        `batch`.`cost`,
                        `products`.`product_name`,
                        `batch_loss`.`remarks`,
                        `batch_loss`.`archived_date`,
                        `batch_loss`.`archive_by`,
                        SUM( `batch_loss`.`unpacked_loss` + `batch_loss`.`quantity_loss`) AS total_batch,
                        (SELECT unit_name FROM unit_of_measurement WHERE products.retail_unit = unit_id) AS retail_unit,
                        `batch_loss`.`status`,
                        `user`.`username` AS `archived_by`
                    FROM `batch_loss`
                    INNER JOIN `user` ON `batch_loss`.`archive_by` = `user`.`user_id`
                    INNER JOIN `products` ON `batch_loss`.`product_id` = `products`.`product_id`
                    INNER JOIN `batch` ON `batch_loss`.`batch_id` = `batch`.`batch_id`
                    WHERE `batch_loss`.`status` = 1
                    GROUP BY `batch_loss`.`id`
                    ORDER BY `products`.`product_name` ASC
                        ";
                    $batch_loss_res = $conn->query($batch_lossSQL);

                    if ($batch_loss_res->num_rows > 0) {
                        $batch_row_count = 1;

                        while ($loss_row = $batch_loss_res->fetch_assoc()) {
                            $DateArchiveddd = date("M d, Y", strtotime($loss_row["archived_date"]));
                            $TimeArchiveddd = date("h:i a", strtotime($loss_row["archived_date"]));
                            echo "
                            <tr>
                            <td class='text-center'>$batch_row_count</td>
                            <td class='text-center'>$loss_row[batch_id]</td>
                            <td class='text-center'>$loss_row[product_name]</td>
                            <td class='text-center'>$loss_row[total_batch] $loss_row[retail_unit]</td>
                            <td class='text-center'>$loss_row[cost]</td>
                            <td class='text-center'>$loss_row[remarks]</td>
                            <td class='text-center'>$DateArchiveddd $TimeArchiveddd</td>
                            <td class='text-center'>$loss_row[archived_by]</td>
                            <td class='text-center'>
                            <form action='invForm-RestoreBatchLoss.php' method='POST' id='restoreBatchLossForm-$loss_row[id]'> 
                            <a href='#' class='btn btn-light restore-batch-lost-btn' 
                            data-toggle='tooltip' data-placement='top'
                             title='Restore Batch' 
                             data-batch-loss-id='$loss_row[id]'><i class='fa-solid fa-arrows-rotate'></i></a>
                             <input type='hidden' name='id' value='$loss_row[id]'>
                             <input type='hidden' name='batchId' value='$loss_row[batch_id]'>
                             <input type='hidden' name='unpacked' value='$loss_row[unpacked_loss]'>
                             <input type='hidden' name='quantity' value='$loss_row[quantity_loss]'>
                             </form>
                            </td>
                            </tr>
                            ";
                            $batch_row_count++;
                        }
                    } else {
                        echo '<tr><td colspan="10" class="text-center" style="height: 200px; vertical-align: middle">No Result</td></tr>';
                    }
                    ?>
                </tbody>
        </div>


        <!--Main Script-->
        <script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>


        <script>
            //to Restore products
            $(document).ready(function() {
                $(".restore-product-btn").click(function() {
                    var productId = $(this).data("product-id");
                    $("#restorepromoForm-" + productId).submit();
                });
            });
        </script>

        <script>
            // To Restore promo products
            $(document).ready(function() {
                $(".restore-promo-btn").click(function() {
                    var promo_id = $(this).data("prd-promo");
                    $("#restorepromoForm-" + promo_id).submit();
                });
            });
        </script>
        <script>
           // To restore repack batch and batch loss
    $(document).ready(function() {
        $('.restore-product-btn, .restore-batch-btn, .restore-batch-lost-btn').click(function() {
            var id = $(this).data('product-id') || $(this).data('batch-id') || $(this).data('batch-loss-id') || $(this).data('prd-promo');
            $('#restoreProductForm-' + id + ', #restoreBatchForm-' + id + ', #restoreBatchLossForm-' + id + ', #restorepromoForm-' + id).submit();
        });

        $('[data-toggle="tooltip"]').tooltip();
    });
        </script>


        <script>
            $("textarea").keydown(function(e) {
                // Enter was pressed without shift key
                if (e.keyCode == 13 && !e.shiftKey) {
                    // prevent default behavior
                    e.preventDefault();
                }
            });

            $("input").keydown(function(e) {
                // Enter was pressed without shift key
                if (e.keyCode == 220) {
                    // prevent default behavior
                    e.preventDefault();
                }
            });

            $('#tbodyProducts [data-toggle="tooltip"]').tooltip({
                animated: 'fade',
                placement: 'bottom',
                html: true
            });


            /* initializate the tooltips after ajax requests, if not already done */
            $(document).ajaxComplete(function(event, request, settings) {
                $('[data-toggle="tooltip"]').not('[data-original-title]').tooltip();
            });
        </script>
</body>

</html>