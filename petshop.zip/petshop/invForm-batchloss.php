<?php

    session_start();
    include("./includes/connection.php");
    include('./includes/log_check.php');
    include('./includes/checkRole.php');

    date_default_timezone_set('Asia/Manila');
    $user = $_SESSION["user_id"];
    $date = date("Y-m-d H-i-s");

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $batchId = $_POST["batchId"];
        $batch_select = $_POST["batchloss_select"];
        $productID = $_POST["productId"];
        $remarks = $_POST["batchloss_Remarks"];
        $unpacked = $_POST["unpacked"];
        $quantity = $_POST["quantity"];

        $conn->query("
        INSERT INTO `batch_loss`(`batch_id`, `product_id`, `unpacked_loss`, `quantity_loss`, `remarks`, `archived_date`, `archive_by`, `status`) 
        VALUES ('$batchId','$productID','$unpacked','$quantity', CONCAT('$remarks', ' ', '$batch_select'), '$date', '$user', '1')
        ");

        $conn->query("
        UPDATE `batch` SET 
        `unpacked_quantity`= (`unpacked_quantity` - $unpacked),
        `quantity`= (`quantity` - $quantity)
        WHERE batch_id = $batchId
        ");

        include("./includes/updateProductStatus.php");
        include("./includes/updateExpirationStatus.php");

        $_SESSION["message"] = "batch-loss";
        header("location: ./inv-productList.php");
        exit();
    } else {   //runs if there are no POST method
        $_SESSION["message"] = "error";
        header("location: ./inv-productList.php");
        exit();
    }

?>
