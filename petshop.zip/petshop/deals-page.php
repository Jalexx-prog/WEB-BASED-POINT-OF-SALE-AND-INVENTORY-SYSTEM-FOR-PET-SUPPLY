<?php
session_start();

date_default_timezone_set('Asia/Manila');
include("./includes/connection.php");
include('./includes/log_check.php');
include('./includes/checkRole.php');

$logo = $conn->query("SELECT `logo` FROM `system`")->fetch_assoc()["logo"];

$search = isset($_GET["search"]) ? $_GET["search"] : '';
$condition = "1";

$sql = "SELECT * FROM discount WHERE $condition 
    ORDER BY discount_name ASC";
$result = $conn->query($sql);


$promo_sql = "SELECT * FROM promo WHERE 1
  ORDER BY promo_name ASC";
$promo_result = $conn->query($promo_sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!--Bootstrap-->
  <link rel="stylesheet" href="./bootstrap/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">

  <!--Jquery-->
  <script src="./js/jquery_3.6.4_jquery.min.js"></script>
  <script src="./bootstrap//popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
  <!--<script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>-->

  <script>
    $(function() {
      $('[data-toggle="tooltip"]').tooltip();
    })
  </script>

  <!--Fontawesome-->
  <link rel="stylesheet" href="./fontawesome/css/all.min.css">

  <!--CSS-->
  <link rel="stylesheet" href="./css/styles.css">
  <link rel="stylesheet" href="./css/inventory.css">

  <link rel="icon" type="image/png" href="./assets/<?php echo $logo ?>" />


  <title>Discount</title>

</head>

<body>
  <?php
  include("./includes/navbar.php");
  ?>

  <div class="container main-div py-4" id="main-div">
    <h3>Discount Settings</h3>

    <section class="productTableSection mt-5" id="productTableSection">
      <div class="row mb-3 d-flex flex-row-reverse">
        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#addDiscountModal"><i class="fa-solid fa-plus"></i>&emsp;Add Discount</button>
      </div>

    </section>
    <div class="div_stocks row" style="height: 400px; overflow-y: auto;">
      <table class="table productTable" id="productTable">
        <thead>
          <th class='text-center'>#</th>
          <th class='text-center'>DISCOUNT NAME</th>
          <th class='text-center'>(%) PERCENTAGE</th>
          <th class='text-center'>STATUS</th>
          <th class='text-center'>ACTION</th>
        </thead>
        <tbody>
          <?php

          $rowCount = 1;
          if (!$result) {
            die("invalid query: " . $conn->connect_error);
          }

          //to read data of each row
          while ($row = $result->fetch_assoc()) {
            $status = $row["discount_status"] == 1 ? "<span class='badge badge-primary'>Active</span>" : "<span class='badge badge-danger'>Inactive</span>";
            echo "
         <tr>
         <td class='text-center'> $rowCount</td>
          <td class='text-center'>$row[discount_name]</td>
          <td class='text-center'>$row[percent]</td>
          <td class='text-center'>$status</td>
          <td class='text-center'> 
          <button type='button' class='btn btn-success btn-sm editDiscountBtn'
          data-discount-id='" . $row["discount_id"] . "'
          data-discount-name='" . $row["discount_name"] . "'
          data-percent='" . $row["percent"] . "'
          data-target='#Editdiscountmodal'
          data-toggle='modal' data-placement='top' title='Edit'>
          <i class='fa fa-pen-to-square'></i>
       </button>
          <button type='button' class='btn btn-warning btn-sm changeStatus' 
          data-status-id='" . $row["discount_id"] . "'
          data-status='" . $row["discount_status"] . "'
          data-toggle='modal' data-target='#changemodal' 
          >
          <i class='fas fa-exchange-alt'></i>
       </button>
        </td>
        </tr>
        ";

            $rowCount++;
          }
          ?>
        </tbody>
      </table>
    </div>

    <div style="margin-top: 50px;"></div>

    <!--promo table-->
    <section class="productTableSection mt-5" id="productTableSection">
      <div class="row mb-3 d-flex flex-row-reverse">
        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#addpromoModal"><i class="fa-solid fa-plus"></i>&emsp;Add Promo</button>
      </div>

    </section>
    <div class="div_stocks row" style="height: 400px; overflow-y: auto;">
      <table class="table productTable" id="productTable">
        <thead>
          <th class='text-center'>#</th>
          <th class='text-center'>PROMO NAME</th>
          <th class='text-center'>TYPE</th>
          <th class='text-center'>BUY</th>
          <th class='text-center'>GET</th>
          <th class='text-center'>(%) DISCOUNT</th>
          <th class='text-center'>STATUS</th>
          <th class='text-center'>ACTION</th>
        </thead>
        <tbody>
          <?php
          $count = 1;
          if (!$promo_result) {
            die("invalid query: " . $conn->connect_error);
          }

          while ($rows = $promo_result->fetch_assoc()) {
            $promo_status = $rows["promo_status"] == 1 ? "<span class='badge badge-primary'>Active</span>" : "<span class='badge badge-danger'>Inactive</span>";

            echo "
            <tr>
              <td class='text-center'>$count</td>
              <td class='text-center'>$rows[promo_name]</td>
              <td class='text-center'>$rows[promo_type]</td>
              <td class='text-center'>$rows[promo_buy]</td>
              <td class='text-center'>$rows[promo_get]</td>
              <td class='text-center'>$rows[promo_discount]</td>
              <td class='text-center'>$promo_status</td>
              <td class='text-center'>
              <button type='button' class='btn btn-success btn-sm editpromoBtn'
              data-promo-id='" . $rows["promo_id"] . "'
              data-promo-name='" . $rows["promo_name"] . "'
              data-promo-type='" . $rows["promo_type"] . "'
              data-promo-buy='" . $rows["promo_buy"] . "'
              data-promo-get='" . $rows["promo_get"] . "'
              data-promo-discount='" . $rows["promo_discount"] . "'
              data-toggle='modal'
              data-target='#editpromoModal'>
              <i class='fa fa-pen-to-square'></i>
              </button>
              <button type='button' class='btn btn-warning btn-sm promoStatus' 
              data-promo_id='" . $rows["promo_id"] . "'
              data-promo_status='" . $rows["promo_status"] . "'
              data-toggle='modal' data-target='#promochangemodal' 
              >
              <i class='fas fa-exchange-alt'></i>


              </td>
            </tr>
            
            ";
            $count++;
          }
          ?>


        </tbody>
      </table>
    </div>
  </div>

  <!--modal here-->

  <!-- Modal for add new -->
  <div class="modal fade" id="addDiscountModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog  modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Add Discount</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <form action="./up-addDiscount.php" method="post">
              <label class="form-label">Discount Name</label>
              <input type="text" class="form-control" name="dcname" required>
              <label class="form-label">Percentage</label>
              <input type="number" min="1" class="form-control" name="percent" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Add</button>
        </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Modal for edit -->
  <div class="modal fade" id="Editdiscountmodal" tabindex="-1" aria-labelledby="modal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modal">Edit Discount</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="./update-editdiscount.php" method="post">
            <div class="mb-3">
              <label class="form-label">Discount Name</label>
              <input type="text" class="form-control" id="editdcname-discountname" name="edit_dcname" required>
              <label class="form-label">Percentage</label>
              <input type="number" class="form-control" id="editpercent-percent" name="edit_percent" required>
              <input type="hidden" name="id" id="discount-id">
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Update</button>
        </div>
        </form>
      </div>
    </div>
  </div>


  <!-- Modal for Change Status -->
  <div class="modal fade" id="changemodal" tabindex="-1" aria-labelledby="modal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modal">Change Status</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="./update-discountStatus.php" method="post">
            <div class="mb-3">
              <center>
                <b> Are you sure you want to change the status ? </b>
                <input type="hidden" name="id" id="status-id">
                <input type="hidden" name="status" id="status">
              </center>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Change</button>
        </div>
        </form>
      </div>
    </div>
  </div>


  <!--modal for promo-->
  <!--add new promo-->
  <div class="modal fade" id="addpromoModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog  modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Add Promo</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <form action="./add-promo.php" method="post">
              <label class="form-label">Promo Name</label>
              <input type="text" class="form-control" name="promo_name" required>
              <label class="form-label">Type</label>
              <input type="text" min="1" class="form-control" name="promo_type" required>
              <div class="row">
                <div class="col">
                  <label class="form-label">Buy</label>
                  <input type="number" min="0" class="form-control" name="promo_buy">
                </div>
                <div class="col">
                  <label class="form-label">Get</label>
                  <input type="number" min="0" class="form-control" name="promo_get">
                </div>
              </div>
              <label class="form-label">Discount</label>
              <input type="number" min="0" class="form-control" name="promo_discount">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Add</button>
        </div>
        </form>
      </div>
    </div>
  </div>

  <!--edit promo-->
  <div class="modal fade" id="editpromoModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog  modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Edit Promo</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <form action="./edit-promo.php" method="post">
              <label class="form-label">Promo Name</label>
              <input type="text" class="form-control" id="p_name" name="promo_name" required>
              <label class="form-label">Type</label>
              <input type="text" min="1" class="form-control" id="p_type"  name="promo_type" required>
              <div class="row">
                <div class="col">
                  <label class="form-label">Buy</label>
                  <input type="number" min="0" class="form-control" id="p_buy"  name="promo_buy">
                </div>
                <div class="col">
                  <label class="form-label">Get</label>
                  <input type="number" min="0" class="form-control" id="p_get"  name="promo_get">
                </div>
              </div>
              <label class="form-label">Discount</label>
              <input type="number" min="0" class="form-control" id="p_discount"  name="promo_discount">
              <input type="hidden" id="p_id" name="id">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Update</button>
        </div>
        </form>
      </div>
    </div>
  </div>

  <!--change promo status-->
  <div class="modal fade" id="promochangemodal" tabindex="-1" aria-labelledby="modal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modal">Change Status</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="./update-promo-status.php" method="post">
            <div class="mb-3">
              <center>
                <b> Are you sure you want to change the status ? </b>
                <input type="hidden" name="id" id="promo_status_id">
                <input type="hidden" name="promo_status" id="promo_status">
              </center>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Change</button>
        </div>
        </form>
      </div>
    </div>
  </div>


  <script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
  <script src="./js/preventKeydown.js"></script>
  <script>
    $(document).ready(function() {
      //discount tooltip
      $(".editDiscountBtn").tooltip({
        title: "Edit",
        trigger: "hover",
        placement: "top"
      });
      $(".changeStatus").tooltip({
        title: "Change Status",
        trigger: "hover",
        placement: "top"
      });

      //promo tooltip
      $(".editpromoBtn").tooltip({
        title: "Edit",
        trigger: "hover",
        placement: "top"
      });
      $(".promoStatus").tooltip({
        title: "Change Status",
        trigger: "hover",
        placement: "top"
      });

      //discount script
      $(".editDiscountBtn").click(function() {
        // Handle modal functionality
        var discountID = $(this).data("discount-id");
        var discountName = $(this).data("discount-name");
        var percent = $(this).data("percent");
        $("#discount-id").val(discountID);
        $("#editdcname-discountname").val(discountName);
        $("#editpercent-percent").val(percent);
      });

      $(".changeStatus").click(function() {
        // Handle modal functionality
        var statusID = $(this).data("status-id");
        var changeStatus = $(this).data("status");
        $("#status-id").val(statusID);
        $("#status").val(changeStatus);
      });


      //promo script
      $(".editpromoBtn").click(function() {
        // Handle modal functionality
        var promoID = $(this).data("promo-id");
        var promo_name = $(this).data("promo-name");
        var promo_type = $(this).data("promo-type");
        var promo_buy = $(this).data("promo-buy");
        var promo_get = $(this).data("promo-get");
        var promo_discount = $(this).data("promo-discount");
        $("#p_id").val(promoID);
        $("#p_name").val(promo_name);
        $("#p_type").val(promo_type);
        $("#p_buy").val(promo_buy);
        $("#p_get").val(promo_get);
        $("#p_discount").val(promo_discount);
      });

      $(".promoStatus").click(function() {
        // Handle modal functionality
        var promoid = $(this).data("promo_id");
        var promo_status = $(this).data("promo_status");
        $("#promo_status_id").val(promoid);
        $("#promo_status").val(promo_status);
      });




    });
  </script>
</body>

</html>