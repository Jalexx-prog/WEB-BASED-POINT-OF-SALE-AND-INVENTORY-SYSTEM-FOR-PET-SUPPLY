
function formatCurrency(number) {
    const formattedValue = new Intl.NumberFormat('en-PH', {
        style: 'currency',
        currency: 'PHP'
    }).format(number);
    
    return `₱ ${formattedValue.substring(1)}`;
}


function posProductSearchAjax(value){
    if(value !== ""){
        $.post("./ajax/posProductSearch.php",
        { search: value },
        function(data){
            $("#productList").html(data);
            if($("#productList .listProductItem").length == 1 && $("#productList .listBarcode").val() == value){
                $("#productList .listProductItem").click();
            }
        });
        $("#productList").css("display", "block");
    }
    else{
        $("#productList").css("display", "none");
    }
    $("#productSearch").focus();
}

$("#productSearch").on("input", function(){
    var value = $(this).val();
    posProductSearchAjax(value);
});


function updateTotal(){
    var total = 0;
    $('.subtotal').each(function(){
        total += parseFloat($(this).val());  // Or this.innerHTML, this.innerText
    });
    var discount = parseInt($("#discount").val());
    total = total - (discount/100 * total);
    var change = $("#amountTendered").val() - total;
    var vatableSales = (total / 1.12).toFixed(2);
    var vatAmount = (total - vatableSales).toFixed(2);

    $("#total").val(total);
    $("#totalText").html(formatCurrency(roundNum(total)));
    $("#change").val(change);
    $("#changeText").html(formatCurrency(roundNum(change)));
    $("#vatableSales").val(vatableSales);
    $("#vatableSalesText").html(formatCurrency(roundNum(vatableSales)));
    $("#vatAmount").val(vatAmount);
    $("#vatAmountText").html(formatCurrency(roundNum(vatAmount)));
    $("#amountTendered").attr("min", total);

    var amountTendered = parseFloat($("#amountTendered").val());
    var change = amountTendered - total;

    // Display 0.00 as change if the user still has a balance or if the inputs are not valid numbers
    if (isNaN(change) || change < 0) {
        change = 0;
    }

    $("#change").val(change.toFixed(2));
    $("#changeText").html(formatCurrency(roundNum(change)));

    // Disable the submit button if the form cannot be submitted
    $("#submitTransaction").prop("disabled", !canSubmitForm());
    
    
}


//function for preventing applying BOGO promo when (quantity + promo) freebie exeeds the stocks on inventory
function preventBOGONegative(id){
    var qty = parseInt($(`#quantity-${id}`).val());
    var qtyType = $(`#quantityType-${id}`).val();
    if(qtyType == 1){
        var promoBuy = $(`#promoBuy-${id}`).val();
        var promoGet = $(`#promoGet-${id}`).val();
        var totalQty = 0;

        if(promoBuy > 0 && promoGet > 0){
            var promoFreebie = parseInt(Math.floor(qty / promoBuy));
            totalQty = qty + promoFreebie;
            

            if(totalQty > $(`#quantity-${id}`).attr("max")){
                $(`#promo-${id}`).val("None");
            }

        }
    }
}

function onchangeQuantity(id){
    var price = $(`#price-${id}`).val();
    var x = $(`#quantity-${id}`).val() !== '' ? $(`#quantity-${id}`).val() : 0;
    var qty = parseInt(x);
    

    var subtotal = qty * price;
    $(`#subtotal-${id}`).val(subtotal);
    $(`#subtotalText-${id}`).html("₱ " + roundNum(subtotal));

    //preventBOGONegative(id);

    updateTotal();
}

function onchangeQuantityType(id){
    var price = $(`#retailPrice-${id}`).val();
    var wholesalePrice = $(`#wholesalePrice-${id}`).val();
    var maxRetail = $(`#maxRetail-${id}`).val();
    var maxWholesale = $(`#maxWholesale-${id}`).val();

    var retailCost = $(`#retailCost-${id}`).val();
    var wholesaleCost = $(`#wholesaleCost-${id}`).val();
    
    $(`#quantity-${id}`).val(1);
    if($(`#quantityType-${id}`).val() == 1){
        $(`#price-${id}`).val(price);
        $(`#priceText-${id}`).html("₱ " + roundNum(price));
        $(`#subtotal-${id}`).val(price);
        $(`#subtotalText-${id}`).html("₱ " + roundNum(price));
        $(`#quantity-${id}`).attr("max", maxRetail);
        $(`#promo-${id}`).attr("disabled", false);
        $(`#cost-${id}`).val(retailCost);

    }
    else{
        $(`#price-${id}`).val(wholesalePrice);
        $(`#priceText-${id}`).html("₱ " + roundNum(wholesalePrice));
        $(`#subtotal-${id}`).val(wholesalePrice);
        $(`#subtotalText-${id}`).html("₱ " + roundNum(wholesalePrice));
        $(`#quantity-${id}`).attr("max", maxWholesale);
        $(`#promo-${id}`).attr("disabled", true);
        $(`#promo-${id}`).val($(`#promo-${id} option:first`).val());
        $(`#cost-${id}`).val(wholesaleCost);
        onchangePromo(id);
        
    }
    
    updateTotal();
}


function onchangePromo(id){
    var val = $(`#promo-${id}`).val();
    if(val !== "None"){
        

        val = val.split(",");
        if(val.length == 2){
            $(".promo-col").css("display", "table-cell");

            $(`#promoBuy-${id}`).val(val[0]);
            $(`#promoGet-${id}`).val(val[1]);
            $(`#promoDiscount-${id}`).val(0);
            var price = 0;
            if($(`#quantityType-${id}`).val() == 1){
                price = $(`#retailPrice-${id}`).val()
            }
            else{
                price = $(`#wholesalePrice-${id}`).val()
            }
            var qty = $(`#quantity-${id}`).val();
            $(`#price-${id}`).val(price);
            $(`#priceText-${id}`).html("₱ " + roundNum(price));
            var subtotal = qty * price;
            $(`#subtotal-${id}`).val(subtotal);
            $(`#subtotalText-${id}`).html("₱ " + roundNum(subtotal));
        }
        else{
            $(".promo-col").css("display", "none");
            
            $(`#promoBuy-${id}`).val(0);
            $(`#promoGet-${id}`).val(0);
            $(`#promoDiscount-${id}`).val(val[0]);
            var price = $(`#price-${id}`).val();
            var qty = $(`#quantity-${id}`).val();
            var disc = val[0];
            var newPrice = price - (parseFloat((disc/100) * parseFloat(price)));
            $(`#price-${id}`).val(newPrice);
            $(`#priceText-${id}`).html("₱ " + roundNum(newPrice));
            var subtotal = qty * newPrice;
            $(`#subtotal-${id}`).val(subtotal);
            $(`#subtotalText-${id}`).html("₱ " + roundNum(subtotal));
        }
    }
    else{
        $(`#promoBuy-${id}`).val(0);
        $(`#promoGet-${id}`).val(0);
        $(`#promoDiscount-${id}`).val(0);
        var price = 0;
        if($(`#quantityType-${id}`).val() == 1){
            price = $(`#retailPrice-${id}`).val()
        }
        else{
            price = $(`#wholesalePrice-${id}`).val()
        }
        var qty = $(`#quantity-${id}`).val();
        $(`#price-${id}`).val(price);
        $(`#priceText-${id}`).html("₱ " + roundNum(price));
        var subtotal = qty * price;
        $(`#subtotal-${id}`).val(subtotal);
        $(`#subtotalText-${id}`).html("₱ " + roundNum(subtotal));

        $(".promo-col").css("display", "none");
    }

    
    //preventBOGONegative(id);

    updateTotal();
}



function removeRow(id){
    $(`#selectedItemRow-${id}`).remove();
    updateTotal();
    submitToggle();
}



$("#amountTendered").on("input", function(){
    updateTotal();
});

function roundNum(num) {
    return (Math.round(parseFloat(num) * 100) / 100).toFixed(2);
}

function submitToggle() {
    var x = $(".selectedItemRow").length;
    if (x > 0) {
        $("#submitTransaction").prop("disabled", !canSubmitForm());
        $("#noItem").remove();
    }
    else {
        $("#submitTransaction").prop("disabled", true);
        $("#selectedTable tbody").html(`
            <tr id="noItem">
                <td class="text-center" colspan="5">
                    <br><br>
                    No Products Added
                </td>
            </tr>
        `);
    }
}
submitToggle();


$(document).ready(function () {
    // Function to clear the amount tendered input field
    function clearAmountTendered() {
        $('#amountTendered').val('');
        updateTotal();
        
    }
    // Attach the clearAmountTendered function to the click event of the clear button
    $('#clearAmount').click(clearAmountTendered);
});

$(".cashbtn").click(function() {
    var buttonValue = parseFloat($(this).val());
    var currentValue = parseFloat($("#amountTendered").val()) || 0;
    var newValue = currentValue + buttonValue;
    $("#amountTendered").val((newValue.toFixed(2)));
    updateTotal();
  });

 function canSubmitForm() {
    var total = parseFloat($("#total").val());
    var amountTendered = parseFloat($("#amountTendered").val());
    var rowCount = $(".selectedItemRow").length;

    return rowCount > 0 && amountTendered >= total;
}

// Add an event listener to update the submit button state when the amountTendered input changes
$("#amountTendered").on("input", function() {
    $("#submitTransaction").prop("disabled", !canSubmitForm());
});

// Add an event listener to update the submit button state when a row is removed
$(document).on("click", ".removeItem", function() {
    updateTotal();
    $("#submitTransaction").prop("disabled", !canSubmitForm());
});

// Initialize the submit button state
$("#submitTransaction").prop("disabled", !canSubmitForm());