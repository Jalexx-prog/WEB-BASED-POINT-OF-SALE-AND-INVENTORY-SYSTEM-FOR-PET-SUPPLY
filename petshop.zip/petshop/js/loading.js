window.addEventListener('load', function() {
    // Simulate a delay (e.g., 3 seconds)
    setTimeout(function() {
      // Add a class to trigger the slide-up animation
      var loadingScreen = document.querySelector('.loading-screen');
      loadingScreen.classList.add('slide-up');
  
      // Remove the loading screen after the animation is complete
      loadingScreen.addEventListener('animationend', function() {
        loadingScreen.style.display = 'none';
      });
    }, 250); // Adjust the delay time as needed (in milliseconds)
  });
  