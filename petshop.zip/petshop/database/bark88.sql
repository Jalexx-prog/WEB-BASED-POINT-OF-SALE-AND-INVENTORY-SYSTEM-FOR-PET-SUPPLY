-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 04, 2023 at 08:17 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bark88`
--

-- --------------------------------------------------------

--
-- Table structure for table `batch`
--

CREATE TABLE `batch` (
  `batch_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `unpacked_quantity` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `cost` float NOT NULL,
  `price` float NOT NULL,
  `expiration_date` date NOT NULL,
  `expiration_status` int(11) NOT NULL,
  `date_created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `archive_status` int(11) NOT NULL,
  `date_archived` datetime NOT NULL,
  `archived_by` int(11) NOT NULL,
  `archive_remarks` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batch`
--

INSERT INTO `batch` (`batch_id`, `product_id`, `unpacked_quantity`, `quantity`, `cost`, `price`, `expiration_date`, `expiration_status`, `date_created`, `created_by`, `archive_status`, `date_archived`, `archived_by`, `archive_remarks`) VALUES
(10000009, 1, 0, 2, 10, 13, '2023-09-01', 3, '2023-11-04 18:05:34', 1, 0, '0000-00-00 00:00:00', 0, ''),
(10000010, 1, 0, 3, 10, 13, '2023-12-01', 2, '2023-11-04 18:05:58', 1, 0, '0000-00-00 00:00:00', 0, ''),
(10000011, 1, 1, 10, 10, 13, '2024-09-09', 1, '2023-11-04 18:11:13', 1, 0, '0000-00-00 00:00:00', 0, ''),
(10000012, 1, 7, 5, 10, 13, '2025-09-09', 1, '2023-11-04 18:43:26', 1, 1, '2023-11-04 23:15:06', 1, 'Wala langg'),
(10000016, 5, 50, 0, 20, 25, '2025-09-10', 1, '2023-11-05 01:40:18', 1, 0, '0000-00-00 00:00:00', 0, ''),
(10000017, 6, 0, 10, 10, 15, '0000-00-00', 0, '2023-11-05 01:42:26', 1, 0, '0000-00-00 00:00:00', 0, ''),
(10000018, 7, 0, 10, 100, 120, '2024-09-01', 1, '2023-11-05 01:56:31', 1, 0, '0000-00-00 00:00:00', 0, ''),
(10000019, 8, 0, 23, 8.7, 23, '0000-00-00', 0, '2023-11-05 02:47:20', 1, 0, '0000-00-00 00:00:00', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(1, 'Dog Food');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `barcode` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `repackable` int(11) NOT NULL,
  `retail_unit` int(11) NOT NULL,
  `wholesale_unit` int(11) NOT NULL,
  `cost` float NOT NULL,
  `price` float NOT NULL,
  `description` varchar(255) NOT NULL,
  `warning_level` int(11) NOT NULL,
  `wholesale_level` int(11) NOT NULL,
  `stock_status` int(11) NOT NULL,
  `date_created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `archive_status` int(11) NOT NULL,
  `date_archived` datetime NOT NULL,
  `archived_by` int(11) NOT NULL,
  `archive_remarks` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `barcode`, `product_name`, `category_id`, `repackable`, `retail_unit`, `wholesale_unit`, `cost`, `price`, `description`, `warning_level`, `wholesale_level`, `stock_status`, `date_created`, `created_by`, `archive_status`, `date_archived`, `archived_by`, `archive_remarks`) VALUES
(1, '4800489112180', 'Asozi Dog Adults', 1, 1, 3, 3, 10, 13, '', 10, 28, 1, '2023-11-02 13:04:01', 1, 0, '0000-00-00 00:00:00', 0, 'None'),
(5, '2016991195678', 'Whiskas Adult', 1, 1, 3, 3, 20, 25, 'Sako sakong cat fods', 10, 50, 1, '2023-11-05 01:40:18', 1, 0, '0000-00-00 00:00:00', 0, ''),
(6, '2016991196866', 'Dog Toy', 1, 0, 1, 1, 10, 15, 'Toyss', 1, 1, 1, '2023-11-05 01:42:26', 1, 0, '0000-00-00 00:00:00', 0, ''),
(7, '2016991205407', 'Toy Dog', 1, 0, 1, 0, 100, 120, 'Chewable Toy', 1, 1, 1, '2023-11-05 01:56:31', 1, 0, '0000-00-00 00:00:00', 0, ''),
(8, '2016991236203', '2223', 1, 1, 1, 2, 8.7, 23, '', 23, 20, 2, '2023-11-05 02:47:20', 1, 1, '2023-11-05 03:15:25', 1, 'Wala lang');

-- --------------------------------------------------------

--
-- Table structure for table `unit_of_measurement`
--

CREATE TABLE `unit_of_measurement` (
  `unit_id` int(11) NOT NULL,
  `unit_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `unit_of_measurement`
--

INSERT INTO `unit_of_measurement` (`unit_id`, `unit_name`) VALUES
(1, 'pcs'),
(2, 'box'),
(3, 'kg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `first_name`, `last_name`, `username`, `password`, `role`, `status`) VALUES
(1, 'Gherwin', 'Pacheco', 'Niggel', '123', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `batch`
--
ALTER TABLE `batch`
  ADD PRIMARY KEY (`batch_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `unit_of_measurement`
--
ALTER TABLE `unit_of_measurement`
  ADD PRIMARY KEY (`unit_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `batch`
--
ALTER TABLE `batch`
  MODIFY `batch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10000020;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `unit_of_measurement`
--
ALTER TABLE `unit_of_measurement`
  MODIFY `unit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
