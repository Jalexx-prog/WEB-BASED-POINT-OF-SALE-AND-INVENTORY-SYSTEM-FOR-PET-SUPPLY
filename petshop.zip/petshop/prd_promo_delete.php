<?php
try{
session_start();
include ('./includes/checkRole.php');
include('./includes/log_check.php');

date_default_timezone_set('Asia/Manila');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST["del_id"];

    include("./includes/connection.php");


    $sql = "DELETE FROM `promo_product` WHERE prd_promo_id = '$id'";
    $conn->query($sql);
    

    $_SESSION["message"] = "promo-delete";
    header("location: ./promo_page.php");
    exit;
}

}catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    header("location: ./promo_page.php");
    exit();
}
?>
