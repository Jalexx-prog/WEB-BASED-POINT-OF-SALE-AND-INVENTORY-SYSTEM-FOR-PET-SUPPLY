<?php
session_start();

date_default_timezone_set('Asia/Manila');
include("./includes/connection.php");
include ('./includes/log_check.php');
include ('./includes/checkRole.php');

$logo = $conn->query("SELECT `logo` FROM `system`")->fetch_assoc()["logo"];

$search = isset($_GET["search"]) ? $_GET["search"] : '';
$condition = "1";

if (isset($_GET["search"]) and $_GET["search"] !== "") {
  $condition .= " AND `unit_name` LIKE '%$search%'";
}




$sql = "SELECT * FROM unit_of_measurement WHERE $condition
ORDER BY unit_name ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--Bootstrap-->
    <link rel="stylesheet" href="./bootstrap/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <script src="./bootstrap/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

    <!--Jquery-->
    <script src="./js/jquery_3.6.4_jquery.min.js"></script>
    <script src="./bootstrap//popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>

    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip();
        })
    </script>

    <!--Fontawesome-->
    <link rel="stylesheet" href="./fontawesome/css/all.min.css">

    <!--CSS-->
    <link rel="stylesheet" href="./css/styles.css">
    <link rel="stylesheet" href="./css/inventory.css">

    <link rel="icon" type="image/png" href="./assets/<?php echo $logo?>" />
    <title>Unit of Measurement</title>
</head>

<body>
    <?php
    $module = "unit-of-measurement";
    include("./includes/navbar.php");
    ?>

    <div class="container main-div py-4" id="main-div">
        <h3>List of Measurement (<?=$result->num_rows?>)</h3>


        <section class="productTableSection mt-5" id="productTableSection">

            <div class="row mb-3 d-flex flex-row-reverse">
                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#addnew_M"><i class="fa-solid fa-plus"></i>&emsp;Add Measurement</button>
                <?= (isset($_GET["search"]) or (isset($_GET["orderColumn"]) and isset($_GET["orderDirection"]))) ? '
                    &emsp;
                    <a href="./inv-unitofmeasurement.php" class="btn btn-outline-secondary"><i class="fa-solid fa-rotate-left"></i></a>
                ' :
          '' ?>
            </div>
            <div class="row productTableRow">
                <table class="table productTable" id="productTable">
                    <thead>
                        <th>#</th>
                        <th>BASE UNIT NAME</th>
                        <th>ACTION</th>
                    </thead>
                    <tbody>
                        <?php
                        

                        if (!$result) {
                            die("invalid query: " . $conn->connect_error);
                        }
                        $rowCount = 1;
                        //to read data of each row
                        while ($row = $result->fetch_assoc()) {
                            echo "
                            <tr>
                                <td>$rowCount</td>
                                <td>$row[unit_name]</td>
                                <td>
                                <button type='button' class='btn btn-success btn-sm unitEdit' 
                                data-unit-id='".$row["unit_id"]."'
                                data-unit-name='".$row["unit_name"]."'
                                data-toggle='modal' 
                                data-target='#editmodal'>
                                    <i class='fa fa-pen-to-square'></i>
                                </button>
                                <a class='btn btn-danger btn-sm unitDelete'
                                data-delete='".$row["unit_id"]."'
                                data-toggle='modal' 
                                data-target='#deletemodal'>
                                <i class='fa-solid fa-trash'></i></a>           
                                </td>
                            </tr>                              
                            ";
                            $rowCount++;
                        }


                        ?>
                    </tbody>
                </table>
            </div>
        </section>

    </div>

    <!-- Modal add new-->
    <div class="modal fade" id="addnew_M" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">New Unit Name</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="invForm-addmeasurement.php" method="post">
                        <label class="form-label">Unit Name</label>
                        <input type="text" class="form-control" name="newmeasurement" required>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add</button>
                </div>
                </form>
            </div>
        </div>
     </div>

        <!-- Modal Edit-->
        <div class="modal fade" id="editmodal" tabindex="-1" aria-labelledby="editmodal" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editmodalLabel">Edit Unit Name</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                    <form action="invForm-editunitmeasurement.php" method="post">
                        <label class="form-label">Unit Name</label>
                        <input type="text" class="form-control" id="editunit_name" name="edited" required>
                        <input type="hidden" name="id" id="unit_id">

                </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>

          <!-- Modal delete-->
          <div class="modal fade" id="deletemodal" tabindex="-1" aria-labelledby="editmodal" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="alLabel">Delete Unit Name</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <center>
                    <form action="invForm-deletemeasurement.php" method="post">
                      <b> Are you sure you want to delete this Unit name ? </b>
                        <input type="hidden" name="id" id="delete_unit_id">
                        </center>
                </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>



        <script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
        <script src="./js/preventKeydown.js"></script>
       <script>
            $(document).ready(function() {
                $(".unitEdit").tooltip({
                    title: "Edit",
                    trigger: "hover",
                    placement: "top"
                });
                $(".unitDelete").tooltip({
                    title: "Delete",
                    trigger: "hover",
                    placement: "top"
                });

                $(".unitEdit").click(function() {
                    var UnitID = $(this).data("unit-id");
                    var UnitName = $(this).data("unit-name");
                    $("#unit_id").val(UnitID);
                    $("#editunit_name").val(UnitName);
                });

                
                $(".unitDelete").click(function() {
                    var del_UnitID = $(this).data("delete");
                    $("#delete_unit_id").val(del_UnitID);
                });
            });
        </script>
</body>

</html>