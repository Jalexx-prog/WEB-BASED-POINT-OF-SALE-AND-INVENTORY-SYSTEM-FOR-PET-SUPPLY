<?php
require './vendor/autoload.php';


function generateBarcodeImg($id, $code){
    $color = [0, 0, 0];
    $generator = new Picqer\Barcode\BarcodeGeneratorPNG();
    file_put_contents('./barcode/barcode_'.$id.'.png', $generator->getBarcode($code, $generator::TYPE_EAN_13, 1, 50, $color));
}


?>