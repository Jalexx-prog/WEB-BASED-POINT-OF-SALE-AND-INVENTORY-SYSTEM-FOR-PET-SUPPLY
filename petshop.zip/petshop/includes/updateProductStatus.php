  <?php
    //update stock status of products
    include("connection.php");
    $conn->query("
        UPDATE `products` 
        SET `stock_status` = '1' 
        WHERE IFNULL((SELECT SUM(`unpacked_quantity`) + SUM(`quantity`) FROM `batch` WHERE `batch`.`product_id` = `products`.`product_id` AND `batch`.`archive_status` = 0), 0) > `warning_level`;
    ");
    $conn->query("
        UPDATE `products` 
        SET `stock_status` = '2' 
        WHERE IFNULL((SELECT SUM(`unpacked_quantity`) + SUM(`quantity`) FROM `batch` WHERE `batch`.`product_id` = `products`.`product_id` AND `batch`.`archive_status` = 0), 0) <= `warning_level`;
    ");
    $conn->query("
        UPDATE `products` SET `stock_status` = '3' 
        WHERE IFNULL((SELECT (SUM(`unpacked_quantity`) + SUM(`quantity`)) FROM `batch` WHERE `batch`.`product_id` = `products`.`product_id` AND `batch`.`archive_status` = 0), 0) = 0;
    ");

?>