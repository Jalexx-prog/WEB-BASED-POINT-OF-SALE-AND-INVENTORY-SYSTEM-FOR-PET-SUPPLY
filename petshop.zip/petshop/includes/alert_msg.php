<?php
  //function for showing alert box
    function alertMessage($color, $message){
        echo '
            <div 
                id="alert-box"
                class="alert alert-'.$color.' alert-dismissible fade show shadow-lg" role="alert" 
                style="
                    position: fixed;
                    z-index: 1000;
                    width: 500px;
                    top: 30%;
                    left: 50%;
                    margin-top: -100px; /* Negative half of height. */
                    margin-left: -250px; /* Negative half of width. */
                    text-align: center;
                    animation: transitionIn-Y-over 2s;
                ">
                '.$message.'
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <script>
                $("#alert-box").fadeTo(2000, 500).slideUp(500, function(){
                    $("#alert-box").slideUp(2000);
                });
            </script>
        ';
    }

    $message = isset($_SESSION["message"]) ? $_SESSION["message"] : "";
    if($message == "error"){
        alertMessage("danger", "Something went wrong while performing the activity");
    } 
     elseif($message == "failed-upload"){
     alertMessage("danger", "Something went wrong while uploading");
    }
     elseif($message == "update-security"){
     alertMessage("success", "Security updated successfully");
    }
    elseif($message == "product-added"){
    alertMessage("success", "Product has been added successfully");
    }   
    elseif($message == "product-edited"){
    alertMessage("success", "Product has been updated successfully");
    }   
    elseif($message == "product-archived"){
    alertMessage("success", "Product has been archive successfully");
    }   
    elseif($message == "product-restored"){
    alertMessage("success", "Product has been restored successfully");
    }   
    elseif($message == "category-added"){
    alertMessage("success", "Category has been added successfully");
    }
    elseif($message == "category-deleted"){
    alertMessage("success", "Category has been deleted successfully");
    }
    elseif($message == "category-edited"){
    alertMessage("success", "Category has been updated successfully");
    }
    elseif($message == "unit-added"){
    alertMessage("success", "Unit has been added successfully");
    }
    elseif($message == "unit-deleted"){
     alertMessage("success", "Unit has been deleted successfully");
    }
    elseif($message == "unit-edited"){
    alertMessage("success", "Unit name has been updated successfully");
    }
    elseif($message == "wrong-old-password"){
    alertMessage("warning", "Your old password was enetered incorrectly. Please enter it again");
    }
    elseif($message == "password-change"){
    alertMessage("success", "Your password has been changed successsfully");
    }
    elseif($message == "batch-edited"){
    alertMessage("success", "The batch has been updated successsfully");
    }
    elseif($message == "batch-added"){
    alertMessage("success", "The batch has been added successsfully");
    }
    elseif($message == "batch-repacked"){
    alertMessage("success", "The repack product has been added successsfully");
    }
    elseif($message == "batch-archived"){
    alertMessage("success", "The batch product has been archive successsfully");
    }
    elseif($message == "batch-restored"){
    alertMessage("success", "The batch product has been restored successsfully");
    }
    elseif($message == "batch-promo"){
    alertMessage("success", "The batch has been added as Promotional items successsfully");
    }
    elseif($message == "batch-loss"){
    alertMessage("success", "The batch loss has been archived successsfully");
    }
    elseif($message == "batch-loss-restore"){
    alertMessage("success", "The batch loss has been restored successsfully");
    }
    elseif($message == "discount-added"){
    alertMessage("success", "The discount has been added successsfully");
    }
    elseif($message == "discount-edited"){
    alertMessage("success", "The discount details has been updated successsfully");
    }
    elseif($message == "discount-status"){
    alertMessage("success", "The discount status has been updated successsfully");
    }
    elseif($message == "promo-added"){
    alertMessage("success", "The promo has been added successsfully");
    }
    elseif($message == "promo-edited"){
    alertMessage("success", "The promo has been updated successsfully");
    }
    elseif($message == "promo-restore"){
    alertMessage("success", "The promo has been updated successsfully");
    }
    elseif($message == "promo-delete"){
    alertMessage("success", "The promo has been deleted successsfully");
    }
    elseif($message == "promo-status"){
    alertMessage("success", "The promo status has been updated successsfully");
    }
    elseif($message == "personal-detail"){
        alertMessage("success", "Your personal detail has been changed successsfully");
    }
    elseif($message == "pos-transaction"){
        alertMessage("success", "Your Transaction has been recorded successsfully");
    }
    elseif($message == "password-not-match"){
        alertMessage("warning", "Passwords do not match. Please try again.");
    }
    elseif($message == "new-account"){
        alertMessage("success", "New Account has been added successfully");
    }
    elseif($message == "Account-role"){
        alertMessage("success", "Account role has been change successfully");
    }
    elseif($message == "Account-deleted"){
        alertMessage("success", "Account has been deleted successfully");
    }
    elseif($message == "store-details"){
        alertMessage("success", "Details of the store has been updated successfully");
    }
    elseif($message == "barcode-exist"){
        alertMessage("danger", "
            <b>Failed to add the product</b>
            <br>
            The barcode you have entered already exist.    
        ");
    }



    $message = "";
    $_SESSION["message"] = "";

    if(isset($_SESSION["error"])){
        $_SESSION["error"] = "";
    }
?>