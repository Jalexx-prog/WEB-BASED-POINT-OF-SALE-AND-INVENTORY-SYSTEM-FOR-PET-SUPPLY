<form action="inv-productArchive.php" method="get">
    <div class="input-group">
        <input type="text" name="search" class="form-control" placeholder="Search Items Using Barcode, Batch ID or Product Name" value="<?=isset($_GET["search"]) ? $_GET["search"] : ""?>" required>
        <div class="input-group-append">
            <button type="submit" class="btn bg-store-lBrown">
                <i class="fa-solid fa-magnifying-glass text-store-dark"></i>
            </button>
        </div>
    </div>
</form>