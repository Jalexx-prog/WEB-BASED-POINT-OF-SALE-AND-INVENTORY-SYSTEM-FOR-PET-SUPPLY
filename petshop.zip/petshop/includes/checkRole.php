<?php
    if($_SESSION["role"] == 0){
        header("location: landingpage-dashboard.php");
        exit();
        
    }
?>