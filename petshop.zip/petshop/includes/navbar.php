<?php

$role = $_SESSION["role"];
$last = $_SESSION["last_name"];
$first = $_SESSION["first_name"];

$user_name = $first . ' ' . $last;


$nav_sql = "SELECT * FROM `system` WHERE 1";
$nav_res = $conn->query($nav_sql);

while($row = $nav_res->fetch_assoc()){
    $logo = $row['logo'];
    $nav_color = $row['navbar_color'];
    $sidebar_color = $row['sidebar_color'];
    $hover_color = $row['hover_color'];
}
?>



<!--Navbar-->
<link rel="stylesheet" href="./css/burgermenu.css">
<style>

#sidebar .nav-link:hover {
    color: <?php echo $hover_color ?>;
  }


</style>

<nav class="navbar w-100 navbar-dark shadow" id="navbar" style="background-color: <?php echo $nav_color; ?>;">
    <div class="col col-2">
        <a class="bg-white text-white" id="sidebar-btn">
            <h1>
                <div class="menu-btn" onclick="show()">
                    <span></span>
                    <span></span>
                    <span></span>
                    <div class="menu-btn__burger"></div>
                </div>
            </h1>
        </a>
    </div>

    <div class="col col-8">
        <?php
        if (isset($module) and $module == "inventory") {
            include("navbar-invSearch.php");
        } elseif(isset($module) and $module == "manage-account"){
            include("navbar-acctSearch.php");
        } elseif(isset($module) and $module == "category"){
            include("navbar-categorySearch.php");
        }
         elseif(isset($module) and $module == "unit-of-measurement"){
            include("navbar-unitofmeasurementSearch.php");
        }
         elseif(isset($module) and $module == "archive"){
            include("navbar-archiveSearch.php");
        }

        ?>
    </div>

    <div class="col col-2 logo-div p-2 d-flex flex-row-reverse">
        <img src="./assets/<?php echo $logo; ?>" alt="">
        <i class="fas fa-user dropdown dropdown-toggle mt-3" id="user-icon" data-toggle="dropdown" aria-expanded="false">&nbsp;</i>


        <div class="dropdown-menu text-center" aria-labelledby="user-icon" style="padding: 20px;">
            <!--picture // role // full name-->
            <img src="uploads/<?= isset($_SESSION["profile_pic"]) ? $_SESSION["profile_pic"] : 'default-pp.png' ?>" class="img-fluid rounded-circle profile_image">
            <p><?= $role == 1 ? "<h6 style='text-align:center; margin-bottom: 3px;'><span class='badge badge-primary'>Admin</span></h6>" : '<h6 style="text-align:center;"><span class="badge badge-warning">Staff</span></h6>' ?>
            <p style="text-align:center;"><?php echo $user_name ?></p>

            <!--for edit and logout-->
            <li><a class="dropdown-item" href="./edit-account.php" style="font-size: medium;"><i class="fa-solid fa-id-card" style="opacity: 0.5; margin-right: 10px"></i>Edit Account</a></li>
            <li>
                <hr class="dropdown-divider">
            </li>
            <li><a class="dropdown-item" href="./logForm-logout.php" style="font-size: medium;"><i class="fa-solid fa-right-from-bracket" style="opacity: 0.5; margin-right: 10px;"></i> Log Out</a></li>
        </div>


        <!--notifaction-->
        <div class="dropdown">
            <i class="fa-solid fa-bell mt-3" data-toggle="dropdown" id="notif" style="position: relative">

            <span id="notifCount" class="bg-danger text-white" style="position: absolute; font-size: 10px; padding: 4px; bottom: 10px; border-radius: 20px">0</span>
            </i>
            

            <div id="notificationList" class="dropdown-menu dropdown-menu-right" style="padding: 20px; max-height: 500px; overflow-y: auto;">
                    <a class="dropdown-item">No Notifications</a>
                </div>

        </div>

        <script>
            function notifyStatus(){
                $.post("./ajax/notifyStatus.php", 
                    function(data){
                        $("#notificationList").html(data);
                    }
                );
            }

            notifyStatus();
            setInterval(notifyStatus, 1000);
            
        </script>


</nav>

<?php
    $hideAdminOptions = "";
    if($_SESSION["role"] == 0){
        $hideAdminOptions = "style='display: none'";
    }
?>


<!--sidebar-->
<div class="sidebar shadow form-control" id="sidebar" style="background-color: <?php echo $sidebar_color; ?>;">
    <div class="sidebar-list m-3 p-2 text-white">
        <ul class="nav flex-column">

            <li class="sidebar-item mb-0">
                <a href="./landingpage-dashboard.php" class="nav-link px-0 align-middle">
                    <i class="fa-solid fa-house mr-3"></i>Dashboard
                </a>
            </li>

            <li class="sidebar-item mb-0">
                <a href="./pos-cashier.php" class="nav-link px-0 align-middle">
                    <i class="fa-solid fa-money-bill-wave mr-3"></i>Point of Sales
                </a>
            </li>

            <li class="sidebar-item mb-1" <?=$hideAdminOptions?>>
                <a href="#submenu1" data-toggle="collapse" class="nav-link px-0 align-middle" aria-expanded="false">
                    <i class="fa-solid fa-bone mr-3"></i><span class="ms-1 d-none d-sm-inline dropdown-toggle">Inventory </span></a>
                <ul class="collapse nav flex-row ms-1 nav-pills" id="submenu1" data-parent="#sidebar">
                    <li class="mb-1">
                        <a href="./inv-productList.php" class="nav-link px-1"><span class="d-none d-sm-inline ms-5"><i class="fa-solid fa-boxes-stacked"></i> Product Items</span></a>
                    </li>
                    <li class="mb-1">
                        <a href="./inv-category.php" class="nav-link px-1"><span class="d-none d-sm-inline ms-5"><i class="fa fa-light fa-tag"></i> Category</span></a>
                    </li>
                    <li class="mb-1">
                        <a href="./inv-unitofmeasurement.php" class="nav-link px-1"><span class="d-none d-sm-inline ms-5"><i class="fa-solid fa-scale-balanced"></i> Unit of Measurement</span></a>
                    </li>
                    <li class="mb-1">
                        <a href="./inv-productArchive.php" class="nav-link px-1"><span class="d-none d-sm-inline ms-5"><i class="fa-solid fa-box-archive"></i> Archive Items</span></a>
                    </li>
                </ul>
            </li>

            <li class="sidebar-item mb-0" <?=$hideAdminOptions?>>
                <a href="#submenu2" data-toggle="collapse" class="nav-link px-0 align-middle" aria-expanded="false">
                    <i class="fa-solid fa-chart-simple mr-3"></i><span class="ms-1 d-none d-sm-inline dropdown-toggle">Reports </span> </a>
                <ul class="collapse nav flex-row ms-1 nav-pills" id="submenu2" data-parent="#sidebar">
                    <li class="mb-1">
                        <a href="./report-inventoryreport.php" class="nav-link px-1"><span class="d-none d-sm-inline ms-5"><i class="fa-solid fa-file-invoice"></i> Inventory Report</span></a>
                    </li>
                    <li class="mb-1">
                        <a href="./report-salesreport.php" class="nav-link px-1"><span class="d-none d-sm-inline ms-5"><i class="fa-solid fa-chart-pie"></i> Sales Report</span></a>
                    </li>
                </ul>
            </li>

            <li class="sidebar-item mb-0" <?=$hideAdminOptions?>>
                <a href="#submenu3" data-toggle="collapse" class="nav-link px-0 align-middle" aria-expanded="false">
                    <i class="fa-solid fa-gear mr-3"></i><span class="ms-1 d-none d-sm-inline dropdown-toggle">Configuration </span> </a>
                <ul class="collapse nav flex-row ms-1 nav-pills" id="submenu3" data-parent="#sidebar">
                    <li class="mb-1">
                        <a href="./manage-account.php" class="nav-link px-1"><span class="d-none d-sm-inline ms-5"><i class="fa-solid fa-users-gear"></i> Manage Account</span></a>
                    </li>
                    <li class="mb-1">
                        <a href="./store_setting.php" class="nav-link px-1"><span class="d-none d-sm-inline ms-5"><i class="fa-solid fa-screwdriver-wrench"></i> Store Settings</span></a>
                    </li>
                    <li class="mb-1">
                        <a href="./deals-page.php" class="nav-link px-1"><span class="d-none d-sm-inline ms-5"><i class="fa-solid fa-percent"></i> Discount Settings</span></a>
                    </li>
                    <li class="mb-1">
                        <a href="./promo_page.php" class="nav-link px-1"><span class="d-none d-sm-inline ms-5"><i class="fa-solid fa-award"></i> Promo Settings</span></a>
                    </li>
                </ul>
            </li>

    </div>
</div>

<div class="loading-screen">
    <img src="./assets/loading_dog.gif" alt="Loading...">
</div>

<?php
include("./includes/alert_msg.php");

?>

<script src="./js/loading.js"></script>
<script src="./js/main.js"></script>

