<?php
    $conn = new mysqli('localhost', 'root', '', 'bark88');
?>