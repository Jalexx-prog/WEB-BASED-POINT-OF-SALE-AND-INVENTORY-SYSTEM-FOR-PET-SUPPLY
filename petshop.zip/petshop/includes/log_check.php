<?php

if (! isset($_SESSION['username']) and ! isset($_SESSION['role'])) {
  header("Location: http://localhost//petshop/logForm-loginpage.php");
  exit();
}
?>
