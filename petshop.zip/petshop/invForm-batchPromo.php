<?php

    session_start();
    include("./includes/connection.php");
    include('./includes/log_check.php');
    include('./includes/checkRole.php');

    date_default_timezone_set('Asia/Manila');
    $user = $_SESSION["user_id"];
    $date = date("Y-m-d H-i-s");

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $batchId = $_POST["batchId"];
        $batch_select = $_POST["batchpromo_select"];
        $productID = $_POST["productId"];
        $remarks = $_POST["batchpromo"];
        $quantity = $_POST["promo_quantity"];

        $conn->query("
        INSERT INTO `promo_product`(`batch_id`, `product_id`, `quantity_promo`, `remarks`, `archive_date`, `archive_by`) 
        VALUES ('$batchId','$productID','$quantity', CONCAT('$remarks', ' ', '$batch_select'), '$date', '$user')
        ");

        $conn->query("
        UPDATE `batch` SET 
        `quantity`= (`quantity` - $quantity)
        WHERE batch_id = $batchId
        ");

        include("./includes/updateProductStatus.php");
        include("./includes/updateExpirationStatus.php");

        $_SESSION["message"] = "batch-promo";
        header("location: ./inv-productList.php");
        exit();

    } else {   //runs if there are no POST method
        $_SESSION["message"] = "error";
        header("location: ./inv-productList.php");
        exit();
    }

?>
