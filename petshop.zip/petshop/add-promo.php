<?php
try{
    session_start();
    include("./includes/connection.php");
    include('./includes/log_check.php');
    include ('./includes/checkRole.php');
    
    date_default_timezone_set('Asia/Manila');
    $user = $_SESSION["user_id"];
    $date = date("Y-m-d H-i-s");

$promo_name = "";
$promo_type = "";
$promo_buy = "";
$promo_get = "";
$promo_discount = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $promo_name = $_POST["promo_name"];
    $promo_type = $_POST["promo_type"];
    $promo_buy = $_POST["promo_buy"];
    $promo_get = $_POST["promo_get"];
    $promo_discount = $_POST["promo_discount"];

    $promoSql = "INSERT INTO `promo`(`promo_name`, `promo_type`, `promo_buy`, `promo_get`, `promo_discount`,`promo_status`)
                                VALUES ('$promo_name','$promo_type','$promo_buy ','$promo_get','$promo_discount', '1')";
    $promoResult = $conn->query($promoSql);

    if (!$promoResult) {
        die("Discount insertion failed: " . $conn->error);
    }

    $promoID= $conn->insert_id;

    
    $_SESSION["message"] = "promo-added";
    header("location: ./deals-page.php");
    exit();


}  else{   //runs if there are no POST method
        $_SESSION["message"] = "error";
        header("location: ./deals-page.php");
        exit();

}

}
catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    header("location: ./deals-page.php");
    exit();
}
?>