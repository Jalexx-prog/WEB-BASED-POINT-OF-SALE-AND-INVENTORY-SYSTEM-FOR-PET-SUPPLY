<?php
try {
    session_start();
    include("./includes/connection.php");
    include('./includes/log_check.php');
    include ('./includes/checkRole.php');


    date_default_timezone_set('Asia/Manila');
    $user = $_SESSION["user_id"];
    $date = date("Y-m-d H-i-s");

    $unit_name = "";

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST["newmeasurement"])) {
        $unit_name = $_POST["newmeasurement"];


        $sql = "INSERT INTO `unit_of_measurement`(`unit_name`) VALUES ('$unit_name')";
        $result = $conn->query($sql);

        if (!$result) {
            die("unit insertion failed: " . $conn->error);
        }

        $unitId = $conn->insert_id;


        $_SESSION["message"] = "unit-added";
        header("location: ./inv-unitofmeasurement.php");
        exit();
    } else {   //runs if there are no POST method
        $_SESSION["message"] = "error";
        header("location: ./inv-unitofmeasurement.php");
        exit();
    }
} catch (Exception $e) {    //runs if there is an error
    $_SESSION["message"] = "error";
    header("location: ./inv-productList.php");
    exit();
}
