<?php
//try{
    session_start();
    
    include("./includes/connection.php");
    include('./includes/log_check.php');
    include("./includes/barcodeImageGen.php");
    include ('./includes/checkRole.php');
    
    date_default_timezone_set('Asia/Manila');
    $user = $_SESSION["user_id"];
    $date = date("Y-m-d H-i-s");

    if($_SERVER["REQUEST_METHOD"] === "POST"){
        $barcode = $_POST["barcode"];
        $productName = $_POST["productName"];
        $category = $_POST["category"];
        $wholesaleUnit = (isset($_POST["wholesaleUnit"]) and $_POST["wholesaleUnit"] !== "") ? $_POST["wholesaleUnit"] : 0;
        $retailUnit = $_POST["retailUnit"];
        $repackable = $_POST["repackable"];
        $unpackedQuantity = $repackable == 1 ? $_POST["quantity"] : 0;
        $quantity = $repackable == 0 ? $_POST["quantity"] : 0;
        $wholesaleCost = $_POST["wholesaleCost"];
        $retailCost = $_POST["retailCost"];
        $price = $_POST["price"];
        $expirationDate = $_POST["expirationDate"] !== "" ? $_POST["expirationDate"] : "0000-00-00";
        $warningLevel = $_POST["warningLevel"];
        $wholesaleLevel = $_POST["wholesaleLevel"] !== "" ? $_POST["wholesaleLevel"] : 1;
        $description = $_POST["description"];
        
        //get the expiration status of the expiration date
        $expirationStatus = "";
        if($expirationDate === "0000-00-00"){
            $expirationStatus = "0";
        }
        elseif($date >= $expirationDate){
            $expirationStatus = "3";
        }
        elseif($date >= date("Y-m-d", strtotime("-3 months", strtotime($expirationDate))) ){
            $expirationStatus = "2";
        }
        else{
            $expirationStatus = "1";
        }

        //get the expiration status of the expiration date
        $stockStatus = "";
        if(($unpackedQuantity + $quantity) > $warningLevel){
            $stockStatus = "1";
        }
        elseif(($unpackedQuantity + $quantity) <= $warningLevel){
            $stockStatus = "2";
        }
        else{
            $stockStatus = "3";
        }

        $checkBarcode = $conn->query("SELECT `barcode` FROM `products` WHERE `barcode` = '$barcode'");
        if($checkBarcode->num_rows == 0){
            $conn->query("
                INSERT INTO `products`(
                    `product_id`, 
                    `barcode`, 
                    `product_name`, 
                    `category_id`, 
                    `repackable`, 
                    `retail_unit`, 
                    `wholesale_unit`, 
                    `cost`, 
                    `price`, 
                    `description`, 
                    `warning_level`, 
                    `wholesale_level`, 
                    `stock_status`, 
                    `date_created`, 
                    `created_by`, 
                    `archive_status`, 
                    `date_archived`, 
                    `archived_by`, 
                    `archive_remarks`
                ) VALUES (
                    '0',
                    '$barcode',
                    '$productName',
                    '$category',
                    '$repackable',
                    '$retailUnit',
                    '$wholesaleUnit',
                    '$retailCost',
                    '$price',
                    '$description',
                    '$warningLevel',
                    '$wholesaleLevel',
                    '$stockStatus',
                    '$date',
                    '$user',
                    '0',
                    '0000-00-00 00:00:00',
                    '0',
                    ''
                )
            ");

            $productId = $conn->query("SELECT MAX(`product_id`) AS `maxProduct` FROM `products`")->fetch_assoc()["maxProduct"];

            //generate image of barcode
            generateBarcodeImg($productId, $barcode);

            $conn->query("
                INSERT INTO `batch`(
                    `batch_id`, 
                    `product_id`,  
                    `unpacked_quantity`, 
                    `quantity`,
                    `cost`, 
                    `price`, 
                    `expiration_date`, 
                    `expiration_status`, 
                    `date_created`, 
                    `created_by`, 
                    `archive_status`, 
                    `date_archived`, 
                    `archived_by`, 
                    `archive_remarks`) 
                VALUES (
                    '0',
                    '$productId',
                    '$unpackedQuantity',
                    '$quantity',
                    '$retailCost',
                    '$price',
                    '$expirationDate',
                    '$expirationStatus',
                    '$date',
                    '$user',
                    '0',
                    '0000-00-00 00:00:00',
                    '0',
                    ''
                )
            ");
            
            include("./includes/updateProductStatus.php");
            include("./includes/updateExpirationStatus.php");
            
            $_SESSION["message"] = "product-added";
            header("location: ./inv-productList.php");
            exit();
        }
        else{   //runs if the barcode is already in use
            $_SESSION["message"] = "barcode-exist";
            //header("location: ./inv-productList.php");
            //exit();
        }
        


    }
    else{   //runs if there are no POST method
        $_SESSION["message"] = "error";
        //header("location: ./inv-productList.php");
        //exit();


    }
/*}
catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    echo $e;
    header("location: ./inv-productList.php");
    exit();
}*/
    
?>