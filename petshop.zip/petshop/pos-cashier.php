<?php
session_start();
include("./includes/connection.php");
include('./includes/log_check.php');

$logo = $conn->query("SELECT `logo` FROM `system`")->fetch_assoc()["logo"];

date_default_timezone_set('Asia/Manila');

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--Bootstrap-->
    <link rel="stylesheet" href="./bootstrap/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <script src="./bootstrap/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

    <!--Jquery-->
    <script src="./js/jquery_3.6.4_jquery.min.js"></script>

    <script>
        $(function() {
            $('[data-toggle="tooltip"]').tooltip();
        })
    </script>

    <!--Fontawesome-->
    <link rel="stylesheet" href="./fontawesome/css/all.min.css">

    <!--CSS-->
    <link rel="stylesheet" href="./css/styles.css">
    <link rel="stylesheet" href="./css/pos.css">

    <link rel="icon" type="image/png" href="./assets/<?php echo $logo ?>" />
    <title>POS</title>
</head>

<body>
    <?php
    $module = "POS";
    include("./includes/navbar.php");
    ?>


    <div class="container-fluid main-div px-5 py-4" id="main-div">
        <h3>Point of Sale</h3>
        <form action="./posForm-addTransaction.php" method="post">
            <section class="productSection mt-4" id="productSection">
                <div class="row">
                    <div class="col col-lg-9">
                        <div class="row">
                            <div class="col">
                                <div class="form-group w-75" style="position: relative">
                                    <label for="product">Search Product</label>
                                    <input type="text" class="form-control" id="productSearch" placeholder="Enter Barcode or Product Name" autofocus>
                                    <div class="productList border w-100 bg-white" id="productList" style="display: none; position: absolute; max-height: 390px; overflow-y: auto;"></div>
                                </div>
                            </div>
                            <!--<div class="colspan">
                            <label for="product">Quantity</label>
                           <input id="qty" name="qty" value="1" min="1" type="number" class="form-control">
                            </div>-->
                        </div>
                        <br>
                        <div class="row">
                            <table class="table" id="selectedTable">
                                <thead>
                                    <th class="text-center" style="width: 15%">PRODUCT NAME</th>
                                    <th class="text-center" style="width: 30%">QUANTITY</th>
                                    <th class="text-center" style="width: 15%">PRICE</th>
                                    <th class="text-center" style="width: 15%">SUBTOTAL</th>
                                    <th class="text-center" style="width: 12%">PROMO</th>
                                    <th class="text-center promo-col" style="width: 12%"></th>
                                    <th class="text-center" style="width: 5%"></th>
                                </thead>
                                <tbody>
                                    <!--walang laman-->
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-12 col-lg-3">
                        <div class="transactionDetailDiv border rounded m-2 py-4 px-3 px-md-5 w-100">
                            <label for="amountTendered">Amount Tendered</label>
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">₱</span>
                                </div>
                                <input type="number" class="form-control disable-increment" id="amountTendered" name="amountTendered" placeholder="0.00" step="0.01" min="0.01" required>
                                <div class="input-group-append">
                                    <button class="btn btn-outline-danger" type="button" id="clearAmount">Clear</button>
                                </div>
                            </div>

                            <div class="d-md-flex justify-content-center">
                                <div class="d-flex flex-column mx-md-1">
                                    <button type="button" class="amountBtn btn btn-dark cashbtn mb-2" value="1000">1000</button>
                                    <button type="button" class="amountBtn btn btn-dark cashbtn mb-2" value="100">100</button>
                                    <button type="button" class="amountBtn btn btn-dark cashbtn mb-2" value="10">10</button>
                                </div>
                                <div class="d-flex flex-column mx-md-1">
                                    <button type="button" class="amountBtn btn btn-dark cashbtn mb-2" value="500">500</button>
                                    <button type="button" class="amountBtn btn btn-dark cashbtn mb-2" value="50">50</button>
                                    <button type="button" class="amountBtn btn btn-dark cashbtn mb-2" value="5">5</button>
                                </div>
                                <div class="d-flex flex-column mx-md-1">
                                    <button type="button" class="amountBtn btn btn-dark cashbtn mb-2" value="200">200</button>
                                    <button type="button" class="amountBtn btn btn-dark cashbtn mb-2" value="20">20</button>
                                    <button type="button" class="amountBtn btn btn-dark cashbtn mb-2" value="1">1</button>
                                </div>
                            </div>

                            <hr>
                            <input type="hidden" id="total" name="total">
                            <input type="hidden" id="change" name="change">
                            <input type="hidden" id="vatableSales" name="vatableSales">
                            <input type="hidden" id="vatAmount" name="vatAmount">

                            <div class="row mb-2">
                                <div class="col">
                                    Total:
                                </div>
                                <div class="col" id="totalText" style="text-align: right;">
                                    ₱ 0.00
                                </div>
                            </div>

                            <div class="row mb-2">
                                <div class="col">
                                    Change:
                                </div>
                                <div class="col" id="changeText" style="text-align: right;">
                                    ₱ 0.00
                                </div>
                            </div>

                            <div class="row mb-2">
                                <div class="col">
                                    Vatable Sales:
                                </div>
                                <div class="col" id="vatableSalesText" style="text-align: right;">
                                    ₱ 0.00
                                </div>
                            </div>

                            <div class="row mb-4">
                                <div class="col">
                                    Vat Amount:
                                </div>
                                <div class="col" id="vatAmountText" style="text-align: right;">
                                    ₱ 0.00
                                </div>
                            </div>



                            <label for="discount">Discount</label>
                            <div class="row mb-2">
                                <div class="col-12 col-md-8">
                                    <select class="form-control" name="discount" id="discount" onchange="updateTotal()">
                                        <option name="discount" value="0">None</option>
                                        <?php
                                        $discount = $conn->query("SELECT * FROM `discount` WHERE `discount_Status` = 1");
                                        while ($row = $discount->fetch_assoc()) {
                                            echo '
                                <option value="' . $row["percent"] . '">' . $row["discount_name"] . ' ' . $row["percent"] . '%</option>
                            ';
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-12 col-md-4 d-flex flex-row-reverse">
                                    <button type="submit" class="btn btn-success" id="submitTransaction">Submit</button>
                                </div>
                            </div>
                        </div>
                    </div>



                </div>
    </div>
    </div>

    </section>
    </form>
    </div>


    <script src="./js/pos.js"></script>
    <script src="./js/jquery_3.6.4_jquery.min.js"></script>
    <script src="./js/preventKeydown.js"></script>
    <script src="./bootstrap//popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>

    <script>
        $("textarea").keydown(function(e) {
            // Enter was pressed without shift key
            if (e.keyCode == 13 && !e.shiftKey) {
                // prevent default behavior
                e.preventDefault();
            }
        });

        $("input").keydown(function(e) {
            // Enter was pressed without shift key
            if (e.keyCode == 220) {
                // prevent default behavior
                e.preventDefault();
            }
        });


        /* initializate the tooltips after ajax requests, if not already done */
        $(document).ajaxComplete(function(event, request, settings) {
            $('[data-toggle="tooltip"]').not('[data-original-title]').tooltip();
        });
    </script>
    <script>
        function formatNumber(input) {
            // Get the input value as a float
            let value = parseFloat(input.value);

            // Check if the value is a valid number
            if (!isNaN(value)) {
                // Format the number with two decimal places
                input.value = value.toLocaleString('en-US', {
                    maximumFractionDigits: 2
                });
            }
        }
    </script>
</body>

</html>