<?php
require 'vendor/autoload.php';

//EAN 13 Generator
function generateEAN() {
    $date = new DateTime();
    $time = $date->getTimestamp();

    $code = '20' . str_pad($time, 10, '0');
    $weightflag = true;
    $sum = 0;

    for ($i = strlen($code) - 1; $i >= 0; $i--) {
        $sum += (int)$code[$i] * ($weightflag ? 3 : 1);
        $weightflag = !$weightflag;
    }
    $code .= (10 - ($sum % 10)) % 10;
    return $code;
}

$code = generateEAN();

$black = [0, 0, 0];
$generator = new Picqer\Barcode\BarcodeGeneratorPNG();
file_put_contents('./barcode/barcode_3.png', $generator->getBarcode($code, $generator::TYPE_EAN_13, 1, 50, $black));

echo $code;
echo '<br><br>';
echo '<img src="./barcode/barcode_3.png">';
?>