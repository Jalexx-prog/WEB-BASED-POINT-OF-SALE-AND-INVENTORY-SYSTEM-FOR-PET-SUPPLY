<?php
session_start();

include('includes/connection.php');
include('./includes/log_check.php');

$_SESSION["first_name"];
$_SESSION["last_name"];
$_SESSION["role"];
$_SESSION["username"];
$_SESSION["user_id"];
$_SESSION["security_question1"];
$_SESSION["answer_1"];
$_SESSION["security_question2"];
$_SESSION["answer_2"];




?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!--Bootstrap-->
  <link rel="stylesheet" href="./bootstrap/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
  <script src="./bootstrap/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

  <!--Jquery-->
  <script src="./js/jquery_3.6.4_jquery.min.js"></script>

  <script src="./bootstrap//popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
  <script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>

  <script>
    $(function() {
      $('[data-toggle="tooltip"]').tooltip();
    })
  </script>

  <!--Fontawesome-->
  <link rel="stylesheet" href="./fontawesome/css/all.min.css">

  <!--CSS-->
  <link rel="stylesheet" href="./css/styles.css">
  <link rel="stylesheet" href="./css/inventory.css">

  <link rel="icon" type="image/png" href="./assets/logo.png" />
  <title>Edit Account</title>
</head>

<body>
  <?php

  include("./includes/navbar.php");
  ?>
  

  <div class="container main-div py-4" id="main-div">

    <div class="container">
      <h2>Edit Account</h2>
      <div class="row">
        <div class="col-md-6">
          <div class="shadow p-3">
            <br>
            <div class="text-center">
              <img src="uploads/<?= isset($_SESSION["profile_pic"]) ? $_SESSION["profile_pic"] : 'default-pp.png' ?>?t=<?= time() ?>" class="img-fluid rounded-circle" style="max-width: 35%;">
              <p><?= $role == 1 ? "<h5 style='text-align:center; margin-bottom: -1px;'><span class='badge badge-primary'>Admin</span></h5>" : '<h4 style="text-align:center;"><span class="badge badge-warning">Staff </span></h4>' ?>
              <h3 class="display-4 " id="fullname"><?php echo $_SESSION["first_name"] . " " . $_SESSION["last_name"] ?></h3>
            </div>
            <hr>

            <!--checkbox-->
            <div class="row">
              <div class="col">
                <div class="form-check text-center">
                  <input class="form-check-input" value="1" type="checkbox" id="hideSecurityQuestions" checked>
                  <label class="form-check-label" for="hideSecurityQuestions">Hide Security Questions</label>
                </div>
              </div>
            </div>

            <!--security question 1-->
            <form action="update-security_question.php" method="POST">
              <div class="row security-question" style="display: none;">
                <div class="col">
                  <label for="addProduct-quantity">Security Question 1</label>
                  <select class="form-control" name="security_question1" id="security_question1" required>
                    <option value="0" selected disabled>-Select One-</option>

                    <?php
                    $question_sql = "SELECT `security_question`.`id`,
                                                    `security_question`.`questions`
                                             FROM `security_question`
                                             WHERE 1
                                             LIMIT 5";
                    $question_result = $conn->query($question_sql);


                    $userId = $_SESSION["user_id"];

                    $userQuestion1 = $conn->query("SELECT security_question1 FROM user WHERE user_id = $userId")->fetch_assoc()["security_question1"];
                    $userAnswer1 = $conn->query("SELECT answer_1 FROM user WHERE user_id = $userId")->fetch_assoc()["answer_1"];

                    while ($rows = $question_result->fetch_assoc()) {
                      echo '
                                <option value="' . $rows["id"] . '" ' . ($userQuestion1 === $rows["id"] ? "selected" : "") . '>' . $rows["questions"] . '</option>
                                ';
                    }
                    ?>
                  </select>
                </div>
              </div>
              <input type="hidden" value="<?= $userId ?>" name="id">
              <!--security answer 1-->
              <div class="row security-question" style="display: none;">
                <div class="col">
                  <label for="addProduct-quantity">Answer Question 1</label>
                  <input type="text" class="form-control" id="Answer1" value="<?= $userAnswer1 ?>" name="Answer1" autocomplete="off">
                </div>
              </div>

              <!--security question 2-->
              <div class="row security-question" style="display: none;">
                <div class="col">
                  <label for="addProduct-quantity">Security Question 2 </label>
                  <select class="form-control" name="security_question2" id="security_question2" required>
                    <option value="0" selected disabled>-Select One-</option>
                    <?php
                    $question2_sql = "SELECT `security_question`.`id`,
                                                    `security_question`.`questions`
                                             FROM `security_question`
                                             WHERE `id` >= 6
                                             LIMIT 5";
                    $question2_result = $conn->query($question2_sql);

                    $userQuestion2 = $conn->query("SELECT security_question2 FROM user WHERE user_id = $userId")->fetch_assoc()["security_question2"];
                    $userAnswer2 = $conn->query("SELECT answer_2 FROM user WHERE user_id = $userId")->fetch_assoc()["answer_2"];

                    while ($quest_row = $question2_result->fetch_assoc()) {
                      echo '
                                <option value="' . $quest_row["id"] . '" ' . ($userQuestion2 === $quest_row["id"] ? "selected" : "") . '>' . $quest_row["questions"] . '</option>
                                ';
                    }
                    ?>
                  </select>
                </div>
              </div>
              <div class="row security-question" style="display: none;">
                <div class="col">
                  <label for="addProduct-quantity mb-3">Answer Question 2</label>
                  <input type="text" value="<?= $userAnswer2 ?>" class="form-control" id="Answer2" name="Answer2" autocomplete="off">
                </div>
              </div>
              <div class="row security-question mt-3" style="display: none;">
              <div class="col">
                <button type="submit" class="btn btn-primary">Submit</button>
                </form>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-6">
          <div class="shadow p-3">
            <form action="edit-accountProcess.php" method="POST" enctype="multipart/form-data">
              <div class="row">
                <div class="col-md-6">
                  <div class="mb-3">
                    <label class="form-label">First Name</label>
                    <input type="text" class="form-control" name="f_name" value="<?= $_SESSION["first_name"] ?>" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="mb-3">
                    <label class="form-label">Last Name</label>
                    <input type="text" class="form-control" name="l_name" value="<?= $_SESSION["last_name"] ?>" required>
                  </div>
                </div>
              </div>
              <div class="mb-3">
                <label class="form-label">User Name</label>
                <input type="text" class="form-control" name="user" value="<?= $_SESSION["username"] ?>" required>
              </div>
              <div class="mb-3">
                <label class="form-label">Profile Picture</label>
                <input type="file" class="form-control" name="pp">
              </div>
              <br>
              <hr class="solid" style="border-top: 3px solid #bbb;">

              <!--Password-->
              <div class="mb-3">
                <label class="form-label">Old Password</label>
                <input type="password" class="form-control" name="old_password">
              </div>
              <div class="mb-3">
                <label class="form-label">New Password</label>
                <input type="password" class="form-control" name="new_password">
              </div>
              <div class="mb-3">
                <label class="form-label">Confirm Password</label>
                <input type="password" class="form-control" name="confirm_password">
              </div>
              <div class="text-end">
                <button type="submit" class="btn btn-primary">Save Changes</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
    $(document).ready(function() {
      $('#hideSecurityQuestions').change(function() {
        $('.security-question').toggle(!this.checked);
      });
    });
  </script>

</body>

</html>