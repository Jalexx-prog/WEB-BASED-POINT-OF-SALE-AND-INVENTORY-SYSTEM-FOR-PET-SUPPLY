<?php
session_start();

include('includes/connection.php');
include('./includes/log_check.php');

$userId = 1;

// Fetch the user's current password
$sql = "SELECT * FROM user WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

// Assuming you have a new password that you want to set
$newPassword = "cvsu101"; // Replace this with the actual new password

// Hash the new password
$hashed = password_hash($newPassword, PASSWORD_DEFAULT);

// Update the user's password
$updateSQL = "UPDATE `user` SET `password` = ? WHERE `user_id` = ?";
$updateStmt = $conn->prepare($updateSQL);
$updateStmt->bind_param("si", $hashed, $userId); // "si" indicates a string and an integer
$updateStmt->execute();
$updateStmt->close();
?>

