<?php
try{
session_start();
include("./includes/connection.php");
include('./includes/log_check.php');
include ('./includes/checkRole.php');
    
date_default_timezone_set('Asia/Manila');


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $edited_promo_name = $_POST["promo_name"];
    $edited_promo_type = $_POST["promo_type"]; 
    $edited_promo_buy = $_POST["promo_buy"]; 
    $edited_promo_get = $_POST["promo_get"]; 
    $edited_promo_discount = $_POST["promo_discount"]; 
    $id = $_POST["id"];
  
    // Update category name in the database
    $editedpromoSql = "UPDATE `promo` SET `promo_name`='$edited_promo_name',
                                       `promo_type`='$edited_promo_type',
                                       `promo_buy`='$edited_promo_buy',
                                       `promo_get`='$edited_promo_get',
                                       `promo_discount`='$edited_promo_discount'
                                       WHERE promo_id = $id";
    $editedpromoResult = $conn->query($editedpromoSql);
  
    if (!$editedpromoResult) {
        die("edited promo update failed: " . $conn->error);
    }
  }


    $_SESSION["message"] = "promo-edited";
    header("location: ./deals-page.php");
    exit();

} catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    echo $e;
    header("location: ./deals-page.php");
    exit();
}
?>