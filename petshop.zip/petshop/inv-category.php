<?php
session_start();

date_default_timezone_set('Asia/Manila');
include("./includes/connection.php");
include('./includes/log_check.php');
include ('./includes/checkRole.php');

$logo = $conn->query("SELECT `logo` FROM `system`")->fetch_assoc()["logo"];

$search = isset($_GET["search"]) ? $_GET["search"] : '';
$condition = "1";

if (isset($_GET["search"]) and $_GET["search"] !== "") {
  $condition .= " AND `category_name` LIKE '%$search%'";
}


$sql = "SELECT * FROM category WHERE $condition 
    ORDER BY category_name ASC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!--Bootstrap-->
  <link rel="stylesheet" href="./bootstrap/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">

  <!--Jquery-->
  <script src="./js/jquery_3.6.4_jquery.min.js"></script>
  <script src="./bootstrap//popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
  <!--<script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>-->

  <script>
    $(function() {
      $('[data-toggle="tooltip"]').tooltip();
    })
  </script>

  <!--Fontawesome-->
  <link rel="stylesheet" href="./fontawesome/css/all.min.css">

  <!--CSS-->
  <link rel="stylesheet" href="./css/styles.css">
  <link rel="stylesheet" href="./css/inventory.css">

  <link rel="icon" type="image/png" href="./assets/<?php echo $logo?>" />


  <title>Category</title>

</head>

<body>
  <?php

  $module = "category";
  include("./includes/navbar.php");
  ?>

  <div class="container main-div py-4" id="main-div">
    <h3>List of Category (<?= $result->num_rows ?>)</h3>

    <section class="productTableSection mt-5" id="productTableSection">
      <div class="row mb-3 d-flex flex-row-reverse">
        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#addProductModal"><i class="fa-solid fa-plus"></i>&emsp;Add Category</button>
        <?= (isset($_GET["search"]) or (isset($_GET["orderColumn"]) and isset($_GET["orderDirection"]))) ? '
                    &emsp;
                    <a href="./inv-category.php" class="btn btn-outline-secondary"><i class="fa-solid fa-rotate-left"></i></a>
                ' :
          '' ?>
      </div>
      <div class="row productTableRow">
        <table class="table productTable" id="productTable">
          <thead>
            <th>#</th>
            <th>CATEGORY NAME</th>
            <th>EXPIRY</th>
          </thead>
          <tbody>
            <?php

            $rowCount = 1;
            if (!$result) {
              die("invalid query: " . $conn->connect_error);
            }

            //to read data of each row
            while ($row = $result->fetch_assoc()) {


              echo "
         <tr>
         <td> $rowCount</td>
          <td>$row[category_name]</td>
          <td>
          <button type='button' class='btn btn-success btn-sm editCategoryBtn' 
          data-category-id='" . $row["category_id"] . "' 
          data-category-name='" . $row["category_name"] . "'  
          data-toggle='modal' data-target='#Editcategorymodal' 
          data-toggle='tooltip' data-placement='top' title='Edit'>
          <i class='fa fa-pen-to-square'></i>
       </button>
          <a class='btn btn-danger btn-sm deletebtn'
          data-button-delete='" . $row["category_id"] . "'
          data-toggle='modal' 
          data-target='#deletemodal'>
          <i class='fa-solid fa-trash'></i></a>
        </td>
        </tr>
        ";

              $rowCount++;
            }
            ?>
          </tbody>
        </table>
    </section>
  </div>
  </div>

  <!--modal here-->

  <!-- Modal for add new -->
  <div class="modal fade" id="addProductModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog  modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Add Category</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <form action="./invForm-addcategory.php" method="post">
              <label class="form-label">Category Name</label>
              <input type="text" class="form-control" name="newcategory" required>
              <label class="form-label">Expiry</label>
              <select class="form-control" name="expiry" id="expiry">
              <option value="1">Yes</option>
              <option value="0">No</option>
              </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Add</button>
        </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Modal for edit -->
  <div class="modal fade" id="Editcategorymodal" tabindex="-1" aria-labelledby="modal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modal">Edit Category</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="./invForm-editcategory.php" method="post">
            <div class="mb-3">
              <label class="form-label">Category Name</label>
              <input type="text" class="form-control" id="editCategory-categoryName" name="edited" required>
              <input type="hidden" name="id" id="editCategory-id">

            </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Update</button>
        </div>
        </form>
      </div>
    </div>
  </div>


  <!-- Modal for delete -->
  <div class="modal fade" id="deletemodal" tabindex="-1" aria-labelledby="modal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modal">Delete Category</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="./invForm-deletecategory.php" method="post">
            <div class="mb-3">
              <center>
                <b> Are you sure you want to delete this category ? </b>
                <input type="hidden" name="id" id="del_Category-id">
              </center>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-danger">Delete</button>
        </div>
        </form>
      </div>
    </div>
  </div>


  <script src="./bootstrap/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
  <script src="./js/preventKeydown.js"></script>
  <script>
    $(document).ready(function() {
      $(".editCategoryBtn").tooltip({
        title: "Edit",
        trigger: "hover",
        placement: "top"
      });
      $(".deletebtn").tooltip({
        title: "Delete",
        trigger: "hover",
        placement: "top"
      });

      $(".editCategoryBtn").click(function() {
        // Handle modal functionality
        var categoryID = $(this).data("category-id");
        var categoryName = $(this).data("category-name");
        $("#editCategory-id").val(categoryID);
        $("#editCategory-categoryName").val(categoryName);
      });

      $(".deletebtn").click(function() {
        // Handle modal functionality
        var deletecategory = $(this).data("button-delete");
        $("#del_Category-id").val(deletecategory);
      });
    });
  </script>
</body>

</html>