<?php
try{
    session_start();
    include("./includes/connection.php");
    include('./includes/log_check.php');
    include ('./includes/checkRole.php');
    
    date_default_timezone_set('Asia/Manila');
    $user = $_SESSION["user_id"];
    $date = date("Y-m-d H-i-s");

    if($_SERVER["REQUEST_METHOD"] === "POST"){
        $productId = $_POST["productId"];
        $repackable = $_POST["repackable"];
        $unpackedQuantity = $repackable == 1 ? $_POST["quantity"] : 0;
        $quantity = $repackable == 0 ? $_POST["quantity"] : 0;
        $wholesaleCost = $_POST["wholesaleCost"];
        $retailCost = $_POST["retailCost"];
        $price = $_POST["price"];
        $expirationDate = $_POST["expirationDate"] !== "" ? $_POST["expirationDate"] : "0000-00-00";
        
        //get the expiration status of the expiration date
        $expirationStatus = "";
        if($expirationDate === "0000-00-00"){
            $expirationStatus = "0";
        }
        elseif($date >= $expirationDate){
            $expirationStatus = "3";
        }
        elseif($date >= date("Y-m-d", strtotime("-3 months", strtotime($expirationDate))) ){
            $expirationStatus = "2";
        }
        else{
            $expirationStatus = "1";
        }

        $conn->query("
            INSERT INTO `batch`(
                `batch_id`, 
                `product_id`,  
                `unpacked_quantity`, 
                `quantity`,
                `cost`, 
                `price`, 
                `expiration_date`, 
                `expiration_status`, 
                `date_created`, 
                `created_by`, 
                `archive_status`, 
                `date_archived`, 
                `archived_by`, 
                `archive_remarks`) 
            VALUES (
                '0',
                '$productId',
                '$unpackedQuantity',
                '$quantity',
                '$retailCost',
                '$price',
                '$expirationDate',
                '$expirationStatus',
                '$date',
                '$user',
                '0',
                '0000-00-00 00:00:00',
                '0',
                ''
            )
        ");
        
        include("./includes/updateProductStatus.php");
        include("./includes/updateExpirationStatus.php");
        
        $_SESSION["message"] = "batch-added";
        header("location: ./inv-productList.php");
        exit();


    }
    else{   //runs if there are no POST method
        $_SESSION["message"] = "error";
        header("location: ./inv-productList.php");
        exit();


    }
}
catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    header("location: ./inv-productList.php");
    exit();
}
    
?>