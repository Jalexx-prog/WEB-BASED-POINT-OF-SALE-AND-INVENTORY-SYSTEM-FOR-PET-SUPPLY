<?php
try{
session_start();
include("./includes/connection.php");
include('./includes/log_check.php');
include ('./includes/checkRole.php');
    
date_default_timezone_set('Asia/Manila');


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $status = ($_POST["archive_status"] == 1) ? 0 : 1;
    $id = $_POST["id"];
    
    $promosql = "UPDATE `promo_product` SET archive_status = '$status' WHERE prd_promo_id = '$id'";
    $promoResult = $conn->query($promosql);
  
    if (!$promoResult) {
        die("promo result update failed: " . $conn->error);
    }
  }


    $_SESSION["message"] = "promo-status";
    header("location: ./promo_page.php");
    exit();

} catch(Exception $e){    //runs if there is an error
    $_SESSION["message"] = "error";
    echo $e;
    header("location: ./promo_page.php");
    exit();
}
?>